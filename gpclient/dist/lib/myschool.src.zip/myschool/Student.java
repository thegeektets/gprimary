/*     */ package myschool;
/*     */ 
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.io.Serializable;
/*     */ import javax.persistence.Basic;
/*     */ import javax.persistence.Column;
/*     */ import javax.persistence.Entity;
/*     */ import javax.persistence.Id;
/*     */ import javax.persistence.Lob;
/*     */ import javax.persistence.NamedQueries;
/*     */ import javax.persistence.Table;
/*     */ import javax.persistence.Transient;
/*     */ 
/*     */ @Entity
/*     */ @Table(name="student", catalog="myschool", schema="")
/*     */ @NamedQueries({@javax.persistence.NamedQuery(name="Student.findAll", query="SELECT s FROM Student s"), @javax.persistence.NamedQuery(name="Student.findByStudentnumber", query="SELECT s FROM Student s WHERE s.studentnumber = :studentnumber"), @javax.persistence.NamedQuery(name="Student.findByStudentname", query="SELECT s FROM Student s WHERE s.studentname = :studentname"), @javax.persistence.NamedQuery(name="Student.findBySex", query="SELECT s FROM Student s WHERE s.sex = :sex"), @javax.persistence.NamedQuery(name="Student.findByStream", query="SELECT s FROM Student s WHERE s.stream = :stream"), @javax.persistence.NamedQuery(name="Student.findByHouse", query="SELECT s FROM Student s WHERE s.house = :house"), @javax.persistence.NamedQuery(name="Student.findByClass1", query="SELECT s FROM Student s WHERE s.class1 = :class1"), @javax.persistence.NamedQuery(name="Student.findByParentsId", query="SELECT s FROM Student s WHERE s.parentsId = :parentsId"), @javax.persistence.NamedQuery(name="Student.findByBcertnumber", query="SELECT s FROM Student s WHERE s.bcertnumber = :bcertnumber")})
/*     */ public class Student
/*     */   implements Serializable
/*     */ {
/*     */ 
/*     */   @Transient
/*  37 */   private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   @Id
/*     */   @Basic(optional=false)
/*     */   @Column(name="studentnumber")
/*     */   private Integer studentnumber;
/*     */ 
/*     */   @Basic(optional=false)
/*     */   @Column(name="studentname")
/*     */   private String studentname;
/*     */ 
/*     */   @Basic(optional=false)
/*     */   @Column(name="sex")
/*     */   private String sex;
/*     */ 
/*     */   @Basic(optional=false)
/*     */   @Column(name="stream")
/*     */   private String stream;
/*     */ 
/*     */   @Basic(optional=false)
/*     */   @Column(name="House")
/*     */   private String house;
/*     */ 
/*     */   @Basic(optional=false)
/*     */   @Lob
/*     */   @Column(name="DOA")
/*     */   private String doa;
/*     */ 
/*     */   @Basic(optional=false)
/*     */   @Column(name="Class")
/*     */   private int class1;
/*     */ 
/*     */   @Basic(optional=false)
/*     */   @Column(name="ParentsId")
/*     */   private int parentsId;
/*     */ 
/*     */   @Column(name="Bcertnumber")
/*     */   private Integer bcertnumber;
/*     */ 
/*     */   public Student()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Student(Integer studentnumber)
/*     */   {
/*  73 */     this.studentnumber = studentnumber;
/*     */   }
/*     */ 
/*     */   public Student(Integer studentnumber, String studentname, String sex, String stream, String house, String doa, int class1, int parentsId) {
/*  77 */     this.studentnumber = studentnumber;
/*  78 */     this.studentname = studentname;
/*  79 */     this.sex = sex;
/*  80 */     this.stream = stream;
/*  81 */     this.house = house;
/*  82 */     this.doa = doa;
/*  83 */     this.class1 = class1;
/*  84 */     this.parentsId = parentsId;
/*     */   }
/*     */ 
/*     */   public Integer getStudentnumber() {
/*  88 */     return this.studentnumber;
/*     */   }
/*     */ 
/*     */   public void setStudentnumber(Integer studentnumber) {
/*  92 */     Integer oldStudentnumber = this.studentnumber;
/*  93 */     this.studentnumber = studentnumber;
/*  94 */     this.changeSupport.firePropertyChange("studentnumber", oldStudentnumber, studentnumber);
/*     */   }
/*     */ 
/*     */   public String getStudentname() {
/*  98 */     return this.studentname;
/*     */   }
/*     */ 
/*     */   public void setStudentname(String studentname) {
/* 102 */     String oldStudentname = this.studentname;
/* 103 */     this.studentname = studentname;
/* 104 */     this.changeSupport.firePropertyChange("studentname", oldStudentname, studentname);
/*     */   }
/*     */ 
/*     */   public String getSex() {
/* 108 */     return this.sex;
/*     */   }
/*     */ 
/*     */   public void setSex(String sex) {
/* 112 */     String oldSex = this.sex;
/* 113 */     this.sex = sex;
/* 114 */     this.changeSupport.firePropertyChange("sex", oldSex, sex);
/*     */   }
/*     */ 
/*     */   public String getStream() {
/* 118 */     return this.stream;
/*     */   }
/*     */ 
/*     */   public void setStream(String stream) {
/* 122 */     String oldStream = this.stream;
/* 123 */     this.stream = stream;
/* 124 */     this.changeSupport.firePropertyChange("stream", oldStream, stream);
/*     */   }
/*     */ 
/*     */   public String getHouse() {
/* 128 */     return this.house;
/*     */   }
/*     */ 
/*     */   public void setHouse(String house) {
/* 132 */     String oldHouse = this.house;
/* 133 */     this.house = house;
/* 134 */     this.changeSupport.firePropertyChange("house", oldHouse, house);
/*     */   }
/*     */ 
/*     */   public String getDoa() {
/* 138 */     return this.doa;
/*     */   }
/*     */ 
/*     */   public void setDoa(String doa) {
/* 142 */     String oldDoa = this.doa;
/* 143 */     this.doa = doa;
/* 144 */     this.changeSupport.firePropertyChange("doa", oldDoa, doa);
/*     */   }
/*     */ 
/*     */   public int getClass1() {
/* 148 */     return this.class1;
/*     */   }
/*     */ 
/*     */   public void setClass1(int class1) {
/* 152 */     int oldClass1 = this.class1;
/* 153 */     this.class1 = class1;
/* 154 */     this.changeSupport.firePropertyChange("class1", oldClass1, class1);
/*     */   }
/*     */ 
/*     */   public int getParentsId() {
/* 158 */     return this.parentsId;
/*     */   }
/*     */ 
/*     */   public void setParentsId(int parentsId) {
/* 162 */     int oldParentsId = this.parentsId;
/* 163 */     this.parentsId = parentsId;
/* 164 */     this.changeSupport.firePropertyChange("parentsId", oldParentsId, parentsId);
/*     */   }
/*     */ 
/*     */   public Integer getBcertnumber() {
/* 168 */     return this.bcertnumber;
/*     */   }
/*     */ 
/*     */   public void setBcertnumber(Integer bcertnumber) {
/* 172 */     Integer oldBcertnumber = this.bcertnumber;
/* 173 */     this.bcertnumber = bcertnumber;
/* 174 */     this.changeSupport.firePropertyChange("bcertnumber", oldBcertnumber, bcertnumber);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 179 */     int hash = 0;
/* 180 */     hash += (this.studentnumber != null ? this.studentnumber.hashCode() : 0);
/* 181 */     return hash;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 187 */     if (!(object instanceof Student)) {
/* 188 */       return false;
/*     */     }
/* 190 */     Student other = (Student)object;
/* 191 */     if (((this.studentnumber == null) && (other.studentnumber != null)) || ((this.studentnumber != null) && (!this.studentnumber.equals(other.studentnumber)))) {
/* 192 */       return false;
/*     */     }
/* 194 */     return true;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 199 */     return "myschool.Student[ studentnumber=" + this.studentnumber + " ]";
/*     */   }
/*     */ 
/*     */   public void addPropertyChangeListener(PropertyChangeListener listener) {
/* 203 */     this.changeSupport.addPropertyChangeListener(listener);
/*     */   }
/*     */ 
/*     */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/* 207 */     this.changeSupport.removePropertyChangeListener(listener);
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.Student
 * JD-Core Version:    0.6.2
 */