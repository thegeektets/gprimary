package myschool;

public class Dbconnect
{
}

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.Dbconnect
 * JD-Core Version:    0.6.2
 */