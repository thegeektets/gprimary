-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.5.28 - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL version:             7.0.0.4053
-- Date/time:                    2013-01-05 03:38:15
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;

-- Dumping database structure for myschool
CREATE DATABASE IF NOT EXISTS `myschool` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `myschool`;


-- Dumping structure for table myschool.exam
CREATE TABLE IF NOT EXISTS `exam` (
  `examtype` varchar(50) NOT NULL,
  `class` int(11) NOT NULL,
  `stream` char(10) NOT NULL,
  `term` int(11) NOT NULL,
  `yearofadm` int(11) NOT NULL,
  `examno` int(11) NOT NULL,
  `entry` int(11) NOT NULL,
  PRIMARY KEY (`examno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table myschool.fee
CREATE TABLE IF NOT EXISTS `fee` (
  `admno` int(11) DEFAULT NULL,
  `name` text,
  `modeofpayment` text,
  `amount` text,
  `date` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table myschool.grade
CREATE TABLE IF NOT EXISTS `grade` (
  `examno` int(10) NOT NULL,
  `grade` text NOT NULL,
  `grade1` text NOT NULL,
  `grade2` text NOT NULL,
  `grade3` text NOT NULL,
  `grade4` text NOT NULL,
  `grade5` text NOT NULL,
  `grade6` text NOT NULL,
  `grade7` text NOT NULL,
  `grade8` text NOT NULL,
  `grade9` text NOT NULL,
  `grade10` text NOT NULL,
  `grade11` text NOT NULL,
  `admno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table myschool.grades
CREATE TABLE IF NOT EXISTS `grades` (
  `maximum` int(11) DEFAULT NULL,
  `minmum` int(11) DEFAULT NULL,
  `grade` char(2) NOT NULL,
  `key` int(10) NOT NULL,
  PRIMARY KEY (`grade`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table myschool.parent
CREATE TABLE IF NOT EXISTS `parent` (
  `parentname` varchar(50) NOT NULL,
  `parentid` int(11) NOT NULL,
  `sex` char(10) NOT NULL,
  `occupation` varchar(15) NOT NULL,
  `emailaddress` varchar(20) NOT NULL,
  `residence` char(20) NOT NULL,
  `maritalstatus` char(15) NOT NULL,
  `phone` int(11) DEFAULT NULL,
  PRIMARY KEY (`parentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table myschool.school
CREATE TABLE IF NOT EXISTS `school` (
  `sname` varchar(20) NOT NULL,
  `scpic` text,
  `address` text NOT NULL,
  `location` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table myschool.score
CREATE TABLE IF NOT EXISTS `score` (
  `admno` int(11) NOT NULL,
  `examno` int(11) NOT NULL,
  `exam` int(11) NOT NULL,
  `exam1` int(11) DEFAULT NULL,
  `exam2` int(11) DEFAULT NULL,
  `exam3` int(11) DEFAULT NULL,
  `exam4` int(11) DEFAULT NULL,
  `exam5` int(11) DEFAULT NULL,
  `exam6` int(11) DEFAULT NULL,
  `exam7` int(11) DEFAULT NULL,
  `exam8` int(11) DEFAULT NULL,
  `exam9` int(11) DEFAULT NULL,
  `exam10` int(11) DEFAULT NULL,
  `exam11` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table myschool.student
CREATE TABLE IF NOT EXISTS `student` (
  `studentnumber` int(50) NOT NULL DEFAULT '0',
  `studentname` varchar(50) NOT NULL,
  `sex` char(10) NOT NULL,
  `stream` varchar(15) NOT NULL,
  `House` varchar(20) NOT NULL,
  `DOA` text NOT NULL,
  `Class` int(11) NOT NULL,
  `ParentsId` int(11) NOT NULL,
  `Bcertnumber` int(11) DEFAULT NULL,
  `spic` text,
  PRIMARY KEY (`studentnumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table myschool.user
CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `credentials` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `hint` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
/*!40014 SET FOREIGN_KEY_CHECKS=1 */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
