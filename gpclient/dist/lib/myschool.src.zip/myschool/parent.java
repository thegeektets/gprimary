/*     */ package myschool;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.border.LineBorder;
/*     */ import javax.swing.event.InternalFrameEvent;
/*     */ import javax.swing.event.InternalFrameListener;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ 
/*     */ public class parent extends JInternalFrame
/*     */ {
/*     */   mymain st;
/*     */   private JButton btnnext;
/*     */   private JButton btnprevious;
/*     */   private JComboBox cmbsex;
/*     */   private JComboBox cmbstatus;
/*     */   private JButton jButton1;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel11;
/*     */   private JLabel jLabel3;
/*     */   private JLabel jLabel4;
/*     */   private JLabel jLabel5;
/*     */   private JLabel jLabel6;
/*     */   private JLabel jLabel7;
/*     */   private JLabel jLabel8;
/*     */   private JPanel jPanel1;
/*     */   private JPanel jPanel2;
/*     */   private JTable jTable;
/*     */   private JLabel lblheader;
/*     */   private JTextField nationalId;
/*     */   private JPanel pnlheader;
/*     */   private JTextField proffession;
/*     */   private JTextField residence;
/*     */   private JScrollPane tblstudent;
/*     */   private JTextField towncode;
/*     */   private JTextField txtname;
/*     */   private JTextField txtphone;
/*     */ 
/*     */   parent(mymain aThis)
/*     */   {
/*  17 */     initComponents();
/*  18 */     this.st = aThis;
/*     */   }
/*     */ 
/*     */   public void fill()
/*     */   {
/*     */     try {
/*  24 */       Class.forName("com.mysql.jdbc.Driver");
/*  25 */       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*  26 */       students s = new students(this);
/*     */ 
/*  30 */       if (students.parentid > 0) {
/*  31 */         int pr = students.parentid;
/*  32 */         String sql = "Select * From parent where parentid=" + pr;
/*     */ 
/*  36 */         Statement stm = con.createStatement();
/*     */ 
/*  38 */         ResultSet rs = stm.executeQuery(sql);
/*     */ 
/*  40 */         rs.next();
/*     */ 
/*  43 */         this.txtname.setText(rs.getString("parentname"));
/*  44 */         this.cmbsex.setSelectedItem(rs.getString("sex"));
/*  45 */         this.proffession.setText(rs.getString("occupation"));
/*  46 */         this.nationalId.setText("" + rs.getInt("parentid"));
/*     */ 
/*  48 */         this.cmbstatus.setSelectedItem(rs.getString("maritalstatus"));
/*  49 */         this.residence.setText(rs.getString("residence"));
/*  50 */         this.towncode.setText(rs.getString("emailaddress"));
/*  51 */         populate();
/*     */       }
/*     */     } catch (ClassNotFoundException ex) { Logger.getLogger(parent.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } catch (SQLException ex) {
/*  55 */       Logger.getLogger(parent.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void populate() {
/*     */     try {
/*  61 */       int no = Integer.parseInt(this.nationalId.getText());
/*     */ 
/*  63 */       Class.forName("com.mysql.jdbc.Driver");
/*  64 */       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*     */ 
/*  66 */       Statement stmnt = con.createStatement();
/*  67 */       String sql = "Select studentnumber,studentname,Class,stream From student where ParentsId=" + no;
/*  68 */       ResultSet rs = stmnt.executeQuery(sql);
/*     */ 
/*  70 */       while (rs.next()) {
/*  71 */         int r = 0;
/*  72 */         int num = rs.getInt("studentnumber");
/*     */ 
/*  74 */         this.jTable.setValueAt(Integer.valueOf(num), r, 0);
/*     */ 
/*  76 */         String name = rs.getString("studentname");
/*  77 */         this.jTable.setValueAt(name, r, 1);
/*  78 */         int cls = rs.getInt("Class");
/*  79 */         this.jTable.setValueAt(Integer.valueOf(cls), r, 2);
/*  80 */         String strm = rs.getString("stream");
/*  81 */         this.jTable.setValueAt(strm, r, 3);
/*     */ 
/*  86 */         r++;
/*     */       }
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/*  90 */       Logger.getLogger(parent.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } catch (SQLException ex) {
/*  92 */       Logger.getLogger(parent.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/* 105 */     this.pnlheader = new JPanel();
/* 106 */     this.lblheader = new JLabel();
/* 107 */     this.jPanel2 = new JPanel();
/* 108 */     this.txtname = new JTextField();
/* 109 */     this.jLabel1 = new JLabel();
/* 110 */     this.jLabel3 = new JLabel();
/* 111 */     this.nationalId = new JTextField();
/* 112 */     this.jLabel5 = new JLabel();
/* 113 */     this.cmbsex = new JComboBox();
/* 114 */     this.cmbstatus = new JComboBox();
/* 115 */     this.jLabel6 = new JLabel();
/* 116 */     this.jLabel4 = new JLabel();
/* 117 */     this.txtphone = new JTextField();
/* 118 */     this.jPanel1 = new JPanel();
/* 119 */     this.towncode = new JTextField();
/* 120 */     this.jLabel7 = new JLabel();
/* 121 */     this.jLabel8 = new JLabel();
/* 122 */     this.residence = new JTextField();
/* 123 */     this.proffession = new JTextField();
/* 124 */     this.jLabel11 = new JLabel();
/* 125 */     this.tblstudent = new JScrollPane();
/* 126 */     this.jTable = new JTable();
/* 127 */     this.jButton1 = new JButton();
/* 128 */     this.btnprevious = new JButton();
/* 129 */     this.btnnext = new JButton();
/*     */ 
/* 131 */     setClosable(true);
/* 132 */     setIconifiable(true);
/* 133 */     setMaximizable(true);
/* 134 */     setResizable(true);
/* 135 */     setTitle("Parent Details");
/* 136 */     addInternalFrameListener(new InternalFrameListener() {
/*     */       public void internalFrameActivated(InternalFrameEvent evt) {
/*     */       }
/*     */       public void internalFrameClosed(InternalFrameEvent evt) {
/*     */       }
/*     */       public void internalFrameClosing(InternalFrameEvent evt) {
/* 142 */         parent.this.formInternalFrameClosing(evt);
/*     */       }
/*     */ 
/*     */       public void internalFrameDeactivated(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameDeiconified(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameIconified(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameOpened(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */     });
/* 154 */     this.pnlheader.setBackground(new Color(204, 204, 255));
/* 155 */     this.pnlheader.setBorder(BorderFactory.createBevelBorder(0));
/* 156 */     this.pnlheader.setName("headerpanel");
/* 157 */     this.pnlheader.setRequestFocusEnabled(false);
/*     */ 
/* 159 */     this.lblheader.setFont(new Font("Traditional Arabic", 0, 24));
/* 160 */     this.lblheader.setHorizontalAlignment(0);
/* 161 */     this.lblheader.setText("Parents Details Data Entry Form");
/* 162 */     this.lblheader.setToolTipText("");
/* 163 */     this.lblheader.setVerticalAlignment(1);
/* 164 */     this.lblheader.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
/* 165 */     this.lblheader.setEnabled(false);
/* 166 */     this.lblheader.setName("lblheader");
/*     */ 
/* 168 */     GroupLayout pnlheaderLayout = new GroupLayout(this.pnlheader);
/* 169 */     this.pnlheader.setLayout(pnlheaderLayout);
/* 170 */     pnlheaderLayout.setHorizontalGroup(pnlheaderLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(pnlheaderLayout.createSequentialGroup().addContainerGap().addComponent(this.lblheader, -1, 729, 32767).addContainerGap()));
/*     */ 
/* 177 */     pnlheaderLayout.setVerticalGroup(pnlheaderLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(pnlheaderLayout.createSequentialGroup().addContainerGap().addComponent(this.lblheader, -2, 27, -2).addContainerGap(21, 32767)));
/*     */ 
/* 185 */     this.jPanel2.setBorder(BorderFactory.createTitledBorder(null, "Personal Details", 0, 0, new Font("Traditional Arabic", 0, 18)));
/*     */ 
/* 187 */     this.jLabel1.setFont(new Font("Traditional Arabic", 0, 18));
/* 188 */     this.jLabel1.setText("Full Name");
/* 189 */     this.jLabel1.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 191 */     this.jLabel3.setFont(new Font("Traditional Arabic", 0, 18));
/* 192 */     this.jLabel3.setText("NationalID");
/* 193 */     this.jLabel3.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 195 */     this.jLabel5.setFont(new Font("Traditional Arabic", 0, 18));
/* 196 */     this.jLabel5.setText("Gender");
/* 197 */     this.jLabel5.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 199 */     this.cmbsex.setModel(new DefaultComboBoxModel(new String[] { "Male", "Female" }));
/*     */ 
/* 201 */     this.cmbstatus.setModel(new DefaultComboBoxModel(new String[] { "married", "single" }));
/*     */ 
/* 203 */     this.jLabel6.setFont(new Font("Traditional Arabic", 0, 18));
/* 204 */     this.jLabel6.setText("Marital Status");
/* 205 */     this.jLabel6.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 207 */     this.jLabel4.setFont(new Font("Traditional Arabic", 0, 18));
/* 208 */     this.jLabel4.setText("Phone number");
/* 209 */     this.jLabel4.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 211 */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/* 212 */     this.jPanel2.setLayout(jPanel2Layout);
/* 213 */     jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel5, GroupLayout.Alignment.TRAILING, -1, -1, 32767).addComponent(this.jLabel4, GroupLayout.Alignment.TRAILING, -1, -1, 32767).addComponent(this.jLabel3, GroupLayout.Alignment.TRAILING, -1, -1, 32767).addComponent(this.jLabel6, -1, -1, 32767).addComponent(this.jLabel1, -2, 178, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.nationalId, GroupLayout.Alignment.LEADING).addComponent(this.cmbsex, GroupLayout.Alignment.LEADING, 0, -1, 32767).addComponent(this.txtphone, GroupLayout.Alignment.LEADING).addComponent(this.cmbstatus, GroupLayout.Alignment.LEADING, 0, 136, 32767).addComponent(this.txtname)).addGap(570, 570, 570)));
/*     */ 
/* 232 */     jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtname, -2, -1, -2).addComponent(this.jLabel1, -2, 20, -2)).addGap(44, 44, 44).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel3, -2, 20, -2).addComponent(this.nationalId, -2, -1, -2)).addGap(18, 18, 18).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.cmbsex, -2, -1, -2).addComponent(this.jLabel5, -2, 20, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 39, 32767).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtphone, -2, -1, -2).addComponent(this.jLabel4)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.cmbstatus, -2, -1, -2).addComponent(this.jLabel6)).addContainerGap()));
/*     */ 
/* 258 */     this.jPanel1.setBorder(BorderFactory.createTitledBorder(null, "Other Details", 0, 0, new Font("Traditional Arabic", 0, 18)));
/*     */ 
/* 260 */     this.jLabel7.setFont(new Font("Traditional Arabic", 0, 18));
/* 261 */     this.jLabel7.setText("Email Address");
/* 262 */     this.jLabel7.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 264 */     this.jLabel8.setFont(new Font("Times New Roman", 0, 18));
/* 265 */     this.jLabel8.setText("Residence");
/* 266 */     this.jLabel8.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 268 */     this.jLabel11.setFont(new Font("Traditional Arabic", 0, 18));
/* 269 */     this.jLabel11.setText("Proffession");
/* 270 */     this.jLabel11.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 272 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/* 273 */     this.jPanel1.setLayout(jPanel1Layout);
/* 274 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.jLabel11, -1, -1, 32767).addComponent(this.jLabel7, -1, 146, 32767).addComponent(this.jLabel8, -1, -1, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 42, 32767).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.proffession, -1, 154, 32767).addComponent(this.towncode).addComponent(this.residence)).addGap(27, 27, 27)));
/*     */ 
/* 289 */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.towncode, -2, -1, -2).addComponent(this.jLabel7)).addGap(41, 41, 41).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.residence, -2, -1, -2).addComponent(this.jLabel8)).addGap(18, 18, 18).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel11).addComponent(this.proffession, -2, -1, -2)).addGap(19, 19, 19)));
/*     */ 
/* 306 */     this.jTable.setModel(new DefaultTableModel(new Object[][] { { null, null, null, null }, { null, null, null, null }, { null, null, null, null }, { null, null, null, null }, { null, null, null, null }, { null, null, null, null } }, new String[] { "Adm No", "Student Name", "Class", "Stream" }));
/*     */ 
/* 319 */     this.tblstudent.setViewportView(this.jTable);
/*     */ 
/* 321 */     this.jButton1.setText("Save");
/* 322 */     this.jButton1.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 324 */         parent.this.jButton1ActionPerformed(evt);
/*     */       }
/*     */     });
/* 328 */     this.btnprevious.setText("Previous");
/* 329 */     this.btnprevious.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 331 */         parent.this.btnpreviousActionPerformed(evt);
/*     */       }
/*     */     });
/* 335 */     this.btnnext.setText("Next");
/* 336 */     this.btnnext.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 338 */         parent.this.btnnextActionPerformed(evt);
/*     */       }
/*     */     });
/* 342 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 343 */     getContentPane().setLayout(layout);
/* 344 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.pnlheader, -1, -1, 32767).addGroup(layout.createSequentialGroup().addComponent(this.jPanel2, -2, 346, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel1, -1, -1, 32767).addContainerGap()).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.tblstudent, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 110, 32767).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.btnnext, -2, 171, -2).addComponent(this.jButton1, -2, 171, -2).addComponent(this.btnprevious, -2, 171, -2)).addContainerGap()));
/*     */ 
/* 362 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.pnlheader, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel2, -2, -1, -2).addComponent(this.jPanel1, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.tblstudent, -1, 123, 32767).addGroup(layout.createSequentialGroup().addComponent(this.jButton1, -2, 30, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.btnnext, -2, 30, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 22, 32767).addComponent(this.btnprevious, -2, 30, -2))).addContainerGap()));
/*     */ 
/* 382 */     pack();
/*     */   }
/*     */ 
/*     */   private void jButton1ActionPerformed(ActionEvent evt) {
/*     */     try {
/* 387 */       String host = "jdbc:mysql://localhost:3306/myschool";
/* 388 */       String user = "root";
/* 389 */       String password = "muteti";
/* 390 */       Connection con = DriverManager.getConnection(host, user, password);
/* 391 */       String married = (String)this.cmbstatus.getSelectedItem();
/* 392 */       String gender = (String)this.cmbstatus.getSelectedItem();
/*     */ 
/* 395 */       PreparedStatement stmt = con.prepareStatement("INSERT INTO PARENT VALUES(?,?,?,?,?,?,?,?)");
/*     */ 
/* 397 */       stmt.setInt(2, Integer.parseInt(this.nationalId.getText()));
/* 398 */       stmt.setString(1, this.txtname.getText());
/*     */ 
/* 400 */       stmt.setInt(8, Integer.parseInt(this.txtphone.getText()));
/* 401 */       stmt.setString(6, this.residence.getText());
/* 402 */       stmt.setString(4, this.proffession.getText());
/*     */ 
/* 404 */       stmt.setString(5, this.towncode.getText());
/*     */ 
/* 406 */       stmt.setString(7, married);
/*     */ 
/* 408 */       stmt.setString(3, gender);
/*     */ 
/* 410 */       stmt.executeUpdate();
/* 411 */       JOptionPane.showMessageDialog(null, "Save Operation successful");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 418 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void btnpreviousActionPerformed(ActionEvent evt) {
/*     */     try {
/* 424 */       Class.forName("com.mysql.jdbc.Driver");
/* 425 */       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*     */ 
/* 427 */       Statement stmnt = con.createStatement();
/* 428 */       String sql = "Select * From parent";
/* 429 */       ResultSet rs = stmnt.executeQuery(sql);
/*     */ 
/* 431 */       if (rs.previous())
/*     */       {
/* 434 */         this.txtname.setText(rs.getString("parentname"));
/* 435 */         this.cmbsex.setSelectedItem(rs.getString("sex"));
/* 436 */         this.proffession.setText(rs.getString("occupation"));
/* 437 */         this.nationalId.setText("" + rs.getInt("parentid"));
/* 438 */         this.txtphone.setText("" + rs.getInt("phone"));
/*     */ 
/* 440 */         this.cmbstatus.setSelectedItem(rs.getString("maritalstatus"));
/* 441 */         this.residence.setText(rs.getString("residence"));
/* 442 */         this.towncode.setText(rs.getString("emailaddress"));
/*     */       } else {
/* 444 */         rs.previous();
/*     */       }
/*     */ 
/* 447 */       JOptionPane.showMessageDialog(null, "This is the first record");
/*     */ 
/* 449 */       populate(); } catch (ClassNotFoundException ex) {
/* 450 */       Logger.getLogger(parent.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } catch (SQLException ex) {
/* 452 */       Logger.getLogger(parent.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void btnnextActionPerformed(ActionEvent evt)
/*     */   {
/*     */     try {
/* 459 */       Class.forName("com.mysql.jdbc.Driver");
/* 460 */       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*     */ 
/* 462 */       Statement stmnt = con.createStatement();
/* 463 */       String sql = "Select * From parent";
/* 464 */       ResultSet rs = stmnt.executeQuery(sql);
/* 465 */       while (rs.next()) {
/* 466 */         if (rs.next())
/*     */         {
/* 469 */           this.txtname.setText(rs.getString("parentname"));
/* 470 */           this.cmbsex.setSelectedItem(rs.getString("sex"));
/* 471 */           this.proffession.setText(rs.getString("occupation"));
/* 472 */           this.nationalId.setText("" + rs.getInt("parentid"));
/*     */ 
/* 474 */           this.cmbstatus.setSelectedItem(rs.getString("maritalstatus"));
/* 475 */           this.residence.setText(rs.getString("residence"));
/* 476 */           this.towncode.setText(rs.getString("emailaddress"));
/*     */         } else {
/* 478 */           rs.previous();
/*     */         }
/*     */ 
/* 481 */         JOptionPane.showMessageDialog(null, "This is the last record");
/*     */       }
/*     */ 
/* 484 */       populate();
/*     */     } catch (ClassNotFoundException ex) {
/* 486 */       Logger.getLogger(parent.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } catch (SQLException ex) {
/* 488 */       Logger.getLogger(parent.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void formInternalFrameClosing(InternalFrameEvent evt) {
/* 493 */     this.st.reg();
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.parent
 * JD-Core Version:    0.6.2
 */