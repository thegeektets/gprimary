/*     */ package myschool;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.Image;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.awt.event.WindowListener;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.event.InternalFrameEvent;
/*     */ import javax.swing.event.InternalFrameListener;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ 
/*     */ public class results extends JInternalFrame
/*     */ {
/*  28 */   public static String host = "jdbc:mysql://localhost:3306/myschool";
/*  29 */   public static String user = "root";
/*  30 */   public static String password = "muteti";
/*     */   public static Connection con;
/*     */   public static Statement stmt;
/*     */   mymain mf;
/*     */   private JButton btnbyadm;
/*     */   private JButton btnbyexam;
/*     */   private JButton btnbyyear;
/*     */   private static JComboBox btngenm;
/*     */   private static JButton btngenr;
/*     */   private JButton jButton4;
/*     */   private JButton jButton5;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel2;
/*     */   private JLabel jLabel3;
/*     */   private JLabel jLabel4;
/*     */   private JLabel jLabel5;
/*     */   private JLabel jLabel6;
/*     */   private JLabel jLabel7;
/*     */   private JPanel jPanel2;
/*     */   private JPanel jPanel3;
/*     */   private JPopupMenu jPopupMenu1;
/*     */   private JPopupMenu jPopupMenu2;
/*     */   public static JLabel lblpic;
/*     */   private JTextField txtadmno;
/*     */   private JTextField txtadmno1;
/*     */   private JTextField txtcls;
/*     */   private JTextField txtexamno;
/*     */   private JTextField txtparentid;
/*     */   private JTextField txttrm;
/*     */   private JTextField txtyear;
/*     */ 
/*     */   public results(mymain my)
/*     */   {
/*  39 */     initComponents();
/*  40 */     this.mf = my;
/*  41 */     hideb();
/*     */   }
/*     */ 
/*     */   public static void showb()
/*     */   {
/*  46 */     btngenr.show();
/*  47 */     btngenm.show();
/*     */   }
/*     */   public static void hideb() {
/*  50 */     btngenr.hide();
/*  51 */     btngenm.hide();
/*     */   }
/*     */ 
/*     */   public static void popolate(int s, JTable tbale, ResultSet rs)
/*     */     throws SQLException
/*     */   {
/*  58 */     con = DriverManager.getConnection(host, user, password);
/*  59 */     stmt = con.createStatement();
/*     */ 
/*  61 */     rs.last();
/*  62 */     int rows = rs.getRow();
/*  63 */     rs.first();
/*  64 */     for (int a = 0; a < rows; a++) {
/*  65 */       for (int b = 0; b < s; b++) {
/*     */         try {
/*  67 */           tbale.setValueAt(rs.getString(b + 1), a, b);
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*  71 */           tbale.setValueAt(Integer.valueOf(rs.getInt(a)), a, b);
/*     */         }
/*     */       }
/*     */ 
/*  75 */       rs.next();
/*     */     }
/*     */   }
/*  78 */   public static void create(int s, ResultSet rs, String[] heads) throws SQLException { con = DriverManager.getConnection(host, user, password);
/*  79 */     stmt = con.createStatement();
/*     */     try
/*     */     {
/*  82 */       DefaultTableModel model = new DefaultTableModel();
/*  83 */       JTable table = new JTable(model);
/*  84 */       int a = 0;
/*  85 */       while (a < s) {
/*  86 */         model.addColumn(heads[a]);
/*  87 */         a++;
/*     */       }
/*     */ 
/*  90 */       while (rs.next()) {
/*  91 */         model.addRow(new Object[0]);
/*     */       }
/*     */ 
/*  97 */       JFrame f = new JFrame("Search Results");
/*  98 */       f.setSize(1000, 500);
/*  99 */       f.add(new JScrollPane(table));
/* 100 */       f.setVisible(true);
/* 101 */       popolate(s, table, rs);
/* 102 */       f.setLocation(400, 20);
/* 103 */       f.addWindowListener(new WindowListener() {
/*     */         public void windowDisposing(WindowEvent e) {
/* 105 */           results.hideb();
/*     */         }
/*     */ 
/*     */         public void windowOpened(WindowEvent e)
/*     */         {
/*     */         }
/*     */ 
/*     */         public void windowClosed(WindowEvent e)
/*     */         {
/* 115 */           results.hideb();
/*     */         }
/*     */ 
/*     */         public void windowIconified(WindowEvent e)
/*     */         {
/*     */         }
/*     */ 
/*     */         public void windowDeiconified(WindowEvent e)
/*     */         {
/*     */         }
/*     */ 
/*     */         public void windowActivated(WindowEvent e)
/*     */         {
/*     */         }
/*     */ 
/*     */         public void windowDeactivated(WindowEvent e)
/*     */         {
/*     */         }
/*     */ 
/*     */         public void windowClosing(WindowEvent e)
/*     */         {
/* 140 */           results.hideb();
/*     */         }
/*     */       });
/* 144 */       f.setDefaultCloseOperation(2);
/*     */     } catch (SQLException ex) {
/* 146 */       Logger.getLogger(results.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } }
/*     */ 
/*     */   public static void searchstd(int adm) throws SQLException {
/* 150 */     con = DriverManager.getConnection(host, user, password);
/* 151 */     stmt = con.createStatement();
/*     */     try
/*     */     {
/* 154 */       ResultSet rs = stmt.executeQuery("Select studentnumber,studentname,class,stream,house,parentsid ,spic from student where studentnumber=" + adm);
/* 155 */       int s = 6;
/* 156 */       create(s, rs, new String[] { "Admno", "Name", "Class", "Stream", "House", "Parents Idno" });
/*     */ 
/* 158 */       rs.first();
/*     */ 
/* 160 */       ImageIcon spic = new ImageIcon(rs.getString("spic"));
/* 161 */       Image sp = spic.getImage();
/* 162 */       Image resizedImage = sp.getScaledInstance(lblpic.getWidth(), lblpic.getHeight(), 0);
/* 163 */       ImageIcon rim = new ImageIcon(resizedImage);
/* 164 */       lblpic.setIcon(rim);
/*     */     } catch (SQLException ex) {
/* 166 */       JOptionPane.showMessageDialog(null, "Record not found" + ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void searchpr(int adm) throws SQLException
/*     */   {
/* 172 */     con = DriverManager.getConnection(host, user, password);
/* 173 */     stmt = con.createStatement();
/*     */     try
/*     */     {
/* 176 */       ResultSet rs = stmt.executeQuery("Select parentid,parentname,parent.sex,phone,occupation,residence,spic from parent,student where parentsid=parentid and studentnumber=" + adm);
/* 177 */       int s = 6;
/* 178 */       create(s, rs, new String[] { "Parent Id", "Fullname", "Sex", "Phone", "Occupation", "Residence" });
/*     */ 
/* 180 */       rs.first();
/* 181 */       ImageIcon spic = new ImageIcon(rs.getString("spic"));
/* 182 */       Image sp = spic.getImage();
/* 183 */       Image resizedImage = sp.getScaledInstance(lblpic.getWidth(), lblpic.getHeight(), 0);
/* 184 */       ImageIcon rim = new ImageIcon(resizedImage);
/* 185 */       lblpic.setIcon(rim);
/*     */     } catch (SQLException ex) {
/* 187 */       JOptionPane.showMessageDialog(null, "Record not found" + ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/* 191 */   public static void searchpar(int parid) throws SQLException { con = DriverManager.getConnection(host, user, password);
/* 192 */     stmt = con.createStatement();
/*     */     try
/*     */     {
/* 195 */       ResultSet rs = stmt.executeQuery("Select studentnumber,parentid,parentname,parent.sex,phone,occupation,residence from parent,student where parlientsid=parentid and parentid=" + parid);
/* 196 */       int s = 6;
/* 197 */       create(s, rs, new String[] { "Parent Id", "Fullname", "Sex", "Phone", "Occupation", "Residence" });
/*     */ 
/* 199 */       rs.first();
/*     */     } catch (SQLException ex) {
/* 201 */       JOptionPane.showMessageDialog(null, "Record not found" + ex.getMessage());
/*     */     } }
/*     */ 
/*     */   public static void searchexmbyadm(int adm) throws SQLException {
/* 205 */     con = DriverManager.getConnection(host, user, password);
/* 206 */     stmt = con.createStatement();
/*     */     try
/*     */     {
/* 209 */       ResultSet rs = stmt.executeQuery("Select exam.examno,yearofadm,exam.class,term,examtype,studentnumber,studentname,exam,exam1,exam2,exam3,exam4,exam5,exam6,exam7,exam8,exam9,exam10,exam11,spic from exam,student,score where admno=studentnumber and exam.examno=score.examno and studentnumber=" + adm);
/*     */ 
/* 213 */       int s = 19;
/* 214 */       create(s, rs, new String[] { "Exam no", "Year", "Form", "Term", "Exam Type", "Admno", "Fullname", "Eng", "Kiswa", "Maths", "Bio", "Chem", "Phyc", "Histo", "Cre", "Geog", "B/Studies", "Comp", "Agric" });
/*     */ 
/* 216 */       rs.first();
/*     */       try {
/* 218 */         ImageIcon spic = new ImageIcon(rs.getString("spic"));
/* 219 */         Image sp = spic.getImage();
/* 220 */         Image resizedImage = sp.getScaledInstance(lblpic.getWidth(), lblpic.getHeight(), 0);
/* 221 */         ImageIcon rim = new ImageIcon(resizedImage);
/* 222 */         lblpic.setIcon(rim);
/*     */       }
/*     */       catch (Exception e) {
/* 225 */         JOptionPane.showMessageDialog(null, "Image not found");
/*     */       }
/*     */     }
/*     */     catch (SQLException ex)
/*     */     {
/* 230 */       JOptionPane.showMessageDialog(null, "Record not found" + ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/* 234 */   public static void searchexmbyexmno(int exmno) throws SQLException { con = DriverManager.getConnection(host, user, password);
/* 235 */     stmt = con.createStatement();
/*     */     try
/*     */     {
/* 238 */       ResultSet rs = stmt.executeQuery("Select exam.examno,yearofadm,exam.class,term,examtype,studentnumber,studentname,exam,exam1,exam2,exam3,exam4,exam5,exam6,exam7,exam8,exam9,exam10,exam11 from exam,student,score where admno=studentnumber and exam.examno=score.examno and exam.examno=" + exmno);
/*     */ 
/* 242 */       int s = 19;
/* 243 */       create(s, rs, new String[] { "Exam no", "Year", "Form", "Term", "Exam Type", "Admno", "Fullname", "Eng", "Kiswa", "Maths", "Bio", "Chem", "Phyc", "Histo", "Cre", "Geog", "B/Studies", "Comp", "Agric" });
/*     */     }
/*     */     catch (SQLException ex)
/*     */     {
/* 247 */       JOptionPane.showMessageDialog(null, "Record not found" + ex.getMessage());
/*     */     } }
/*     */ 
/*     */   public static void searchexmbyyr(int yr, int cls, int trm) throws SQLException {
/* 251 */     con = DriverManager.getConnection(host, user, password);
/* 252 */     stmt = con.createStatement();
/*     */     try
/*     */     {
/* 255 */       ResultSet rs = stmt.executeQuery("Select exam.examno,yearofadm,exam.class,term,examtype,studentnumber,studentname,exam,exam1,exam2,exam3,exam4,exam5,exam6,exam7,exam8,exam9,exam10,exam11 from exam,student,score where admno=studentnumber and exam.examno=score.examno and yearofadm='" + yr + "'" + "and exam.class='" + cls + "'" + "and term=" + trm);
/*     */ 
/* 259 */       int s = 19;
/* 260 */       create(s, rs, new String[] { "Exam no", "Year", "Form", "Term", "Exam Type", "Admno", "Fullname", "Eng", "Kiswa", "Maths", "Bio", "Chem", "Phyc", "Histo", "Cre", "Geog", "B/Studies", "Comp", "Agric" });
/*     */     }
/*     */     catch (SQLException ex)
/*     */     {
/* 264 */       JOptionPane.showMessageDialog(null, "Record not found" + ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/* 271 */     this.jPopupMenu1 = new JPopupMenu();
/* 272 */     this.jPopupMenu2 = new JPopupMenu();
/* 273 */     this.btnbyyear = new JButton();
/* 274 */     this.btnbyadm = new JButton();
/* 275 */     this.jPanel3 = new JPanel();
/* 276 */     this.txtexamno = new JTextField();
/* 277 */     this.jLabel3 = new JLabel();
/* 278 */     this.txtadmno1 = new JTextField();
/* 279 */     this.jLabel4 = new JLabel();
/* 280 */     this.txtcls = new JTextField();
/* 281 */     this.jLabel5 = new JLabel();
/* 282 */     this.txtyear = new JTextField();
/* 283 */     this.jLabel6 = new JLabel();
/* 284 */     this.jLabel7 = new JLabel();
/* 285 */     this.txttrm = new JTextField();
/* 286 */     this.jPanel2 = new JPanel();
/* 287 */     this.txtadmno = new JTextField();
/* 288 */     this.txtparentid = new JTextField();
/* 289 */     this.jLabel1 = new JLabel();
/* 290 */     this.jLabel2 = new JLabel();
/* 291 */     this.jButton4 = new JButton();
/* 292 */     this.jButton5 = new JButton();
/* 293 */     lblpic = new JLabel();
/* 294 */     this.btnbyexam = new JButton();
/* 295 */     btngenr = new JButton();
/* 296 */     btngenm = new JComboBox();
/*     */ 
/* 298 */     setClosable(true);
/* 299 */     setForeground(Color.lightGray);
/* 300 */     setIconifiable(true);
/* 301 */     setMaximizable(true);
/* 302 */     setResizable(true);
/* 303 */     setTitle("Search ");
/* 304 */     addInternalFrameListener(new InternalFrameListener() {
/*     */       public void internalFrameActivated(InternalFrameEvent evt) {
/*     */       }
/*     */       public void internalFrameClosed(InternalFrameEvent evt) {
/*     */       }
/*     */       public void internalFrameClosing(InternalFrameEvent evt) {
/* 310 */         results.this.formInternalFrameClosing(evt);
/*     */       }
/*     */ 
/*     */       public void internalFrameDeactivated(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameDeiconified(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameIconified(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameOpened(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */     });
/* 322 */     this.btnbyyear.setText("Search Exam by Year...");
/* 323 */     this.btnbyyear.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 325 */         results.this.btnbyyearActionPerformed(evt);
/*     */       }
/*     */     });
/* 329 */     this.btnbyadm.setText("Search Exam By Admno");
/* 330 */     this.btnbyadm.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 332 */         results.this.btnbyadmActionPerformed(evt);
/*     */       }
/*     */     });
/* 336 */     this.jPanel3.setBorder(BorderFactory.createTitledBorder(null, "Search exam/results", 0, 0, new Font("Traditional Arabic", 0, 18)));
/*     */ 
/* 338 */     this.txtexamno.setFont(new Font("Traditional Arabic", 0, 18));
/*     */ 
/* 340 */     this.jLabel3.setFont(new Font("Traditional Arabic", 0, 18));
/* 341 */     this.jLabel3.setText("Student Admno");
/* 342 */     this.jLabel3.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 344 */     this.txtadmno1.setFont(new Font("Traditional Arabic", 0, 18));
/* 345 */     this.txtadmno1.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 347 */         results.this.txtadmno1ActionPerformed(evt);
/*     */       }
/*     */     });
/* 351 */     this.jLabel4.setFont(new Font("Traditional Arabic", 0, 18));
/* 352 */     this.jLabel4.setText("Exam Number");
/* 353 */     this.jLabel4.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 355 */     this.txtcls.setFont(new Font("Traditional Arabic", 0, 18));
/*     */ 
/* 357 */     this.jLabel5.setFont(new Font("Traditional Arabic", 0, 18));
/* 358 */     this.jLabel5.setText("Year");
/* 359 */     this.jLabel5.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 361 */     this.txtyear.setFont(new Font("Traditional Arabic", 0, 18));
/* 362 */     this.txtyear.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 364 */         results.this.txtyearActionPerformed(evt);
/*     */       }
/*     */     });
/* 368 */     this.jLabel6.setFont(new Font("Traditional Arabic", 0, 18));
/* 369 */     this.jLabel6.setText("Class");
/* 370 */     this.jLabel6.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 372 */     this.jLabel7.setFont(new Font("Traditional Arabic", 0, 18));
/* 373 */     this.jLabel7.setText("Term");
/* 374 */     this.jLabel7.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 376 */     this.txttrm.setFont(new Font("Traditional Arabic", 0, 18));
/* 377 */     this.txttrm.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 379 */         results.this.txttrmActionPerformed(evt);
/*     */       }
/*     */     });
/* 383 */     GroupLayout jPanel3Layout = new GroupLayout(this.jPanel3);
/* 384 */     this.jPanel3.setLayout(jPanel3Layout);
/* 385 */     jPanel3Layout.setHorizontalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addContainerGap().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel3, -1, 222, 32767).addGap(10, 10, 10).addComponent(this.txtadmno1, -2, 165, -2)).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel4, -1, 222, 32767).addGap(10, 10, 10).addComponent(this.txtexamno, -2, 165, -2)).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel5, -1, 222, 32767).addGap(10, 10, 10).addComponent(this.txtyear, -2, 165, -2)).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel6, -1, 222, 32767).addGap(10, 10, 10).addComponent(this.txtcls, -2, 165, -2)).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel7, -1, 222, 32767).addGap(10, 10, 10).addComponent(this.txttrm, -2, 165, -2))).addContainerGap()));
/*     */ 
/* 412 */     jPanel3Layout.setVerticalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel3, -1, -1, 32767).addComponent(this.txtadmno1, -2, 29, 32767)).addGap(18, 18, 18).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel4, -1, 29, 32767).addComponent(this.txtexamno, -2, 29, -2)).addGap(18, 18, 18).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel5, -1, -1, 32767).addComponent(this.txtyear, -2, 29, -2)).addGap(18, 18, 18).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel6, -1, 29, 32767).addComponent(this.txtcls, -2, 29, -2)).addGap(14, 14, 14).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel7, -1, -1, 32767).addComponent(this.txttrm, -2, 29, -2)).addContainerGap()));
/*     */ 
/* 437 */     this.jPanel2.setBorder(BorderFactory.createTitledBorder(null, "Search student/parent", 0, 0, new Font("Traditional Arabic", 0, 18)));
/*     */ 
/* 439 */     this.txtadmno.setFont(new Font("Traditional Arabic", 0, 18));
/* 440 */     this.txtadmno.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 442 */         results.this.txtadmnoActionPerformed(evt);
/*     */       }
/*     */     });
/* 446 */     this.txtparentid.setFont(new Font("Traditional Arabic", 0, 18));
/*     */ 
/* 448 */     this.jLabel1.setFont(new Font("Traditional Arabic", 0, 18));
/* 449 */     this.jLabel1.setText("Student Admno");
/* 450 */     this.jLabel1.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 452 */     this.jLabel2.setFont(new Font("Traditional Arabic", 0, 18));
/* 453 */     this.jLabel2.setText("Parent Idno");
/* 454 */     this.jLabel2.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 456 */     this.jButton4.setText("Search Student");
/* 457 */     this.jButton4.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 459 */         results.this.jButton4ActionPerformed(evt);
/*     */       }
/*     */     });
/* 463 */     this.jButton5.setText("Search Parent");
/* 464 */     this.jButton5.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 466 */         results.this.jButton5ActionPerformed(evt);
/*     */       }
/*     */     });
/* 470 */     lblpic.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 472 */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/* 473 */     this.jPanel2.setLayout(jPanel2Layout);
/* 474 */     jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.jLabel2, -1, 192, 32767).addComponent(this.jLabel1, -1, 192, 32767).addComponent(lblpic, GroupLayout.Alignment.LEADING, -2, 192, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.txtadmno, GroupLayout.Alignment.TRAILING, -2, 165, -2).addComponent(this.txtparentid, GroupLayout.Alignment.TRAILING, -2, 165, -2).addComponent(this.jButton5, GroupLayout.Alignment.TRAILING, -2, 197, -2).addComponent(this.jButton4, GroupLayout.Alignment.TRAILING, -2, 197, -2)).addContainerGap()));
/*     */ 
/* 490 */     jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel1, -1, -1, 32767).addComponent(this.txtadmno, -2, 29, 32767)).addGap(18, 18, 18).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel2, -1, 29, 32767).addComponent(this.txtparentid, -2, 29, -2)).addGap(18, 18, 18).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.jButton4, -2, 48, -2).addGap(34, 34, 34).addComponent(this.jButton5, -2, 48, -2)).addComponent(lblpic, -2, 171, -2)).addContainerGap()));
/*     */ 
/* 510 */     this.btnbyexam.setText("Search Exam by Examno");
/* 511 */     this.btnbyexam.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 513 */         results.this.btnbyexamActionPerformed(evt);
/*     */       }
/*     */     });
/* 517 */     btngenr.setFont(new Font("Traditional Arabic", 0, 18));
/* 518 */     btngenr.setText("Generate Report Cards");
/* 519 */     btngenr.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 521 */         results.this.btngenrActionPerformed(evt);
/*     */       }
/*     */     });
/* 525 */     btngenm.setFont(new Font("Traditional Arabic", 0, 18));
/* 526 */     btngenm.setModel(new DefaultComboBoxModel(new String[] { "Generate Marksheets:", "By Class", "By Form", " " }));
/*     */ 
/* 528 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 529 */     getContentPane().setLayout(layout);
/* 530 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.jPanel2, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel3, -1, -1, 32767).addGap(14, 14, 14)).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.btnbyexam, -2, 197, -2).addComponent(btngenm, -2, 254, -2)).addGap(40, 40, 40).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.btnbyyear, -2, 197, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 163, 32767).addComponent(this.btnbyadm, -2, 197, -2).addGap(23, 23, 23)).addGroup(layout.createSequentialGroup().addComponent(btngenr, -2, 276, -2).addContainerGap()))))));
/*     */ 
/* 555 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jPanel3, -1, -1, 32767).addComponent(this.jPanel2, -1, -1, 32767)).addGap(10, 10, 10).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.btnbyexam, -1, 46, 32767).addComponent(this.btnbyadm, -2, 44, -2).addComponent(this.btnbyyear, -2, 44, -2)).addGap(18, 18, 18).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(btngenm).addComponent(btngenr, -1, 50, 32767)).addGap(12, 12, 12)));
/*     */ 
/* 573 */     pack();
/*     */   }
/*     */ 
/*     */   private void btnbyyearActionPerformed(ActionEvent evt) {
/*     */     try {
/* 578 */       con = DriverManager.getConnection(host, user, password);
/* 579 */       stmt = con.createStatement();
/*     */ 
/* 581 */       String adm = this.txtyear.getText();
/* 582 */       String cls = this.txtcls.getText();
/* 583 */       String trm = this.txttrm.getText();
/* 584 */       if ((adm.isEmpty()) || (cls.isEmpty()) || (trm.isEmpty())) {
/* 585 */         JOptionPane.showMessageDialog(null, "Please input the Year,Class,Term of the exam before you can proceed");
/*     */       }
/*     */       else
/*     */       {
/* 589 */         int ad = Integer.parseInt(adm);
/* 590 */         int cl = Integer.parseInt(cls);
/* 591 */         int tr = Integer.parseInt(trm);
/* 592 */         searchexmbyyr(ad, cl, tr);
/*     */       }
/*     */ 
/* 596 */       showb();
/*     */     } catch (SQLException ex) {
/* 598 */       JOptionPane.showMessageDialog(null, "Record not found");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void btnbyadmActionPerformed(ActionEvent evt)
/*     */   {
/*     */     try {
/* 605 */       con = DriverManager.getConnection(host, user, password);
/* 606 */       stmt = con.createStatement();
/*     */ 
/* 608 */       String adm = this.txtadmno1.getText();
/* 609 */       if (adm.isEmpty())
/* 610 */         JOptionPane.showMessageDialog(null, "Please input the admission number of the student before you proceed");
/*     */       else {
/*     */         try
/*     */         {
/* 614 */           int ad = Integer.parseInt(adm);
/* 615 */           searchexmbyadm(ad);
/*     */         } catch (SQLException ex) {
/* 617 */           JOptionPane.showMessageDialog(null, "Record not found");
/*     */         }
/*     */       }
/*     */ 
/* 621 */       showb();
/*     */     } catch (SQLException ex) {
/* 623 */       JOptionPane.showMessageDialog(null, "Record not found");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void txtadmno1ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtyearActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txttrmActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtadmnoActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void jButton4ActionPerformed(ActionEvent evt) {
/*     */     try {
/* 645 */       con = DriverManager.getConnection(host, user, password);
/* 646 */       stmt = con.createStatement();
/*     */ 
/* 648 */       String adm = this.txtadmno.getText();
/* 649 */       if (adm.isEmpty()) {
/* 650 */         JOptionPane.showMessageDialog(null, "Please input the admission number of the student before you proceed");
/*     */       }
/*     */       else
/*     */       {
/* 654 */         int ad = Integer.parseInt(adm);
/* 655 */         searchstd(ad);
/* 656 */         showb();
/*     */       }
/*     */     }
/*     */     catch (SQLException ex)
/*     */     {
/* 661 */       Logger.getLogger(results.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void jButton5ActionPerformed(ActionEvent evt) {
/*     */     try {
/* 667 */       con = DriverManager.getConnection(host, user, password);
/* 668 */       stmt = con.createStatement();
/*     */ 
/* 670 */       String adm = this.txtadmno.getText();
/* 671 */       String pr = this.txtparentid.getText();
/* 672 */       if ((adm.isEmpty()) && (pr.isEmpty())) {
/* 673 */         JOptionPane.showMessageDialog(null, "Please input the admission number of the student or the parent id before you proceed");
/*     */       }
/* 675 */       else if (adm.isEmpty())
/*     */       {
/* 677 */         int ad = Integer.parseInt(pr);
/* 678 */         searchpar(ad);
/*     */       }
/*     */       else
/*     */       {
/* 682 */         int ad = Integer.parseInt(adm);
/* 683 */         searchpr(ad);
/*     */       }
/*     */     } catch (SQLException ex) {
/* 686 */       Logger.getLogger(results.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void btnbyexamActionPerformed(ActionEvent evt) {
/*     */     try {
/* 692 */       con = DriverManager.getConnection(host, user, password);
/* 693 */       stmt = con.createStatement();
/*     */ 
/* 695 */       String adm = this.txtexamno.getText();
/* 696 */       if (adm.isEmpty()) {
/* 697 */         JOptionPane.showMessageDialog(null, "Please input the exam number of the Exam before you proceed");
/*     */       }
/*     */       else
/*     */       {
/* 701 */         int ad = Integer.parseInt(adm);
/* 702 */         searchexmbyexmno(ad);
/*     */       }
/*     */ 
/* 706 */       showb();
/*     */     } catch (SQLException ex) {
/* 708 */       Logger.getLogger(results.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void formInternalFrameClosing(InternalFrameEvent evt) {
/* 713 */     this.mf.add();
/* 714 */     dispose();
/*     */   }
/*     */ 
/*     */   private void btngenrActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.results
 * JD-Core Version:    0.6.2
 */