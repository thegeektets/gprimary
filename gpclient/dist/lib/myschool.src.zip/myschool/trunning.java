/*     */ package myschool;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JLayeredPane;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPasswordField;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.UIManager.LookAndFeelInfo;
/*     */ import javax.swing.UnsupportedLookAndFeelException;
/*     */ 
/*     */ public class trunning extends JFrame
/*     */ {
/*     */   private JButton jButton2;
/*     */   private JButton jButton3;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel2;
/*     */   private JLabel jLabel3;
/*     */   private JLabel jLabel4;
/*     */   private JLabel jLabel5;
/*     */   private JLayeredPane jLayeredPane1;
/*     */   private JPanel jPanel1;
/*     */   private JPanel jPanel2;
/*     */   private JScrollPane jScrollPane1;
/*     */   private JTextArea jTextArea1;
/*     */   private JPasswordField txtbr;
/*     */   private JPasswordField txtky;
/*     */   private JPasswordField txtpr;
/*     */   private JPasswordField txtyr;
/*     */ 
/*     */   public trunning()
/*     */   {
/*  17 */     initComponents();
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  24 */     this.jPanel2 = new JPanel();
/*  25 */     this.jLayeredPane1 = new JLayeredPane();
/*  26 */     this.jLabel3 = new JLabel();
/*  27 */     this.jLabel1 = new JLabel();
/*  28 */     this.jLabel4 = new JLabel();
/*  29 */     this.jLabel2 = new JLabel();
/*  30 */     this.jPanel1 = new JPanel();
/*  31 */     this.jScrollPane1 = new JScrollPane();
/*  32 */     this.jTextArea1 = new JTextArea();
/*  33 */     this.txtpr = new JPasswordField();
/*  34 */     this.txtyr = new JPasswordField();
/*  35 */     this.txtky = new JPasswordField();
/*  36 */     this.txtbr = new JPasswordField();
/*  37 */     this.jLabel5 = new JLabel();
/*  38 */     this.jButton2 = new JButton();
/*  39 */     this.jButton3 = new JButton();
/*     */ 
/*  41 */     setDefaultCloseOperation(3);
/*  42 */     setTitle("Running for the first time");
/*  43 */     setAlwaysOnTop(true);
/*  44 */     setBackground(new Color(204, 204, 204));
/*     */ 
/*  46 */     this.jPanel2.setBackground(new Color(102, 102, 255));
/*  47 */     this.jPanel2.setBorder(BorderFactory.createBevelBorder(0));
/*     */ 
/*  49 */     this.jLabel3.setIcon(new ImageIcon(getClass().getResource("/myschool/imagesd.jpg")));
/*  50 */     this.jLabel3.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*  51 */     this.jLabel3.setBounds(10, 10, 50, 120);
/*  52 */     this.jLayeredPane1.add(this.jLabel3, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/*  54 */     this.jLabel1.setIcon(new ImageIcon(getClass().getResource("/myschool/14797023-illustration-of-an-asian-schoolboy-carrying-a-backpack.jpg")));
/*  55 */     this.jLabel1.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*  56 */     this.jLabel1.setBounds(150, 0, 100, 170);
/*  57 */     this.jLayeredPane1.add(this.jLabel1, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/*  59 */     this.jLabel4.setFont(new Font("Monotype Corsiva", 0, 14));
/*  60 */     this.jLabel4.setText("The high school manager 2013");
/*  61 */     this.jLabel4.setBounds(100, 170, 150, 14);
/*  62 */     this.jLayeredPane1.add(this.jLabel4, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/*  64 */     this.jLabel2.setIcon(new ImageIcon(getClass().getResource("/myschool/imagesddd.jpg")));
/*  65 */     this.jLabel2.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*  66 */     this.jLabel2.setBounds(50, 30, 120, 110);
/*  67 */     this.jLayeredPane1.add(this.jLabel2, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/*  69 */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/*  70 */     this.jPanel2.setLayout(jPanel2Layout);
/*  71 */     jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap(-1, 32767).addComponent(this.jLayeredPane1, -2, 256, -2)));
/*     */ 
/*  77 */     jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup().addComponent(this.jLayeredPane1, -2, 191, -2).addContainerGap(-1, 32767)));
/*     */ 
/*  84 */     this.jPanel1.setBackground(new Color(51, 51, 51));
/*  85 */     this.jPanel1.setBorder(BorderFactory.createEtchedBorder(0));
/*     */ 
/*  87 */     this.jTextArea1.setBackground(new Color(102, 102, 255));
/*  88 */     this.jTextArea1.setColumns(20);
/*  89 */     this.jTextArea1.setFont(new Font("Traditional Arabic", 0, 18));
/*  90 */     this.jTextArea1.setRows(5);
/*  91 */     this.jTextArea1.setText("Please provide you correct installation key below in order  to proceed :\nEach box should contain 4 chars");
/*  92 */     this.jTextArea1.setFocusable(false);
/*  93 */     this.jScrollPane1.setViewportView(this.jTextArea1);
/*     */ 
/*  95 */     this.txtpr.setFont(new Font("Traditional Arabic", 0, 24));
/*  96 */     this.txtpr.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  98 */         trunning.this.txtprActionPerformed(evt);
/*     */       }
/*     */     });
/* 102 */     this.txtyr.setFont(new Font("Traditional Arabic", 0, 24));
/* 103 */     this.txtyr.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 105 */         trunning.this.txtyrActionPerformed(evt);
/*     */       }
/*     */     });
/* 109 */     this.txtky.setFont(new Font("Traditional Arabic", 0, 24));
/* 110 */     this.txtky.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 112 */         trunning.this.txtkyActionPerformed(evt);
/*     */       }
/*     */     });
/* 116 */     this.txtbr.setFont(new Font("Traditional Arabic", 0, 24));
/* 117 */     this.txtbr.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 119 */         trunning.this.txtbrActionPerformed(evt);
/*     */       }
/*     */     });
/* 123 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/* 124 */     this.jPanel1.setLayout(jPanel1Layout);
/* 125 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.jScrollPane1, -1, 646, 32767).addContainerGap()).addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup().addComponent(this.txtyr, -2, 105, -2).addGap(18, 18, 18).addComponent(this.txtpr, -2, 105, -2).addGap(18, 18, 18).addComponent(this.txtbr, -2, 105, -2).addGap(18, 18, 18).addComponent(this.txtky, -2, 105, -2).addGap(89, 89, 89)))));
/*     */ 
/* 143 */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtky, -1, 47, 32767).addComponent(this.txtbr, -1, 47, 32767).addComponent(this.txtpr, -1, 47, 32767).addComponent(this.txtyr, -1, 47, 32767)).addGap(18, 18, 18).addComponent(this.jScrollPane1, -2, -1, -2)));
/*     */ 
/* 156 */     this.jLabel5.setFont(new Font("Goudy Stout", 0, 14));
/* 157 */     this.jLabel5.setText("Installation Key:");
/*     */ 
/* 159 */     this.jButton2.setIcon(new ImageIcon(getClass().getResource("/myschool/Close-2-icon.png")));
/* 160 */     this.jButton2.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 162 */         trunning.this.jButton2ActionPerformed(evt);
/*     */       }
/*     */     });
/* 166 */     this.jButton3.setIcon(new ImageIcon(getClass().getResource("/myschool/Actions-go-next-icon.png")));
/* 167 */     this.jButton3.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 169 */         trunning.this.jButton3ActionPerformed(evt);
/*     */       }
/*     */     });
/* 173 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 174 */     getContentPane().setLayout(layout);
/* 175 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel1, -2, -1, -2).addGroup(layout.createSequentialGroup().addComponent(this.jPanel2, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel5, -1, 396, 32767).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addComponent(this.jButton2, -2, 109, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jButton3, -2, 109, -2))))).addContainerGap()));
/*     */ 
/* 192 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addGroup(layout.createSequentialGroup().addGap(53, 53, 53).addComponent(this.jLabel5, -2, 61, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 39, 32767).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.jButton3, -2, 53, -2).addComponent(this.jButton2, -2, 53, -2))).addComponent(this.jPanel2, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel1, -1, -1, 32767)));
/*     */ 
/* 208 */     pack();
/*     */   }
/*     */ 
/*     */   private void jButton2ActionPerformed(ActionEvent evt) {
/* 212 */     String[] options = new String[2];
/* 213 */     options[0] = "Yes";
/* 214 */     options[1] = "No";
/*     */ 
/* 216 */     int val = JOptionPane.showOptionDialog(this.rootPane, "You must complete the setup procedure to use the system\n Are you sure you want to cancel??", "Exit", 0, 1, null, options, Integer.valueOf(0));
/* 217 */     if (val == 0) {
/* 218 */       JOptionPane.showMessageDialog(this.rootPane, "Setup cancelled by user");
/* 219 */       dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void txtprActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtyrActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtkyActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtbrActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void jButton3ActionPerformed(ActionEvent evt)
/*     */   {
/* 241 */     if (("1320".equals(this.txtyr.getText())) && ("griff".equals(this.txtpr.getText())) && ("4991".equals(this.txtbr.getText())) && ("@tet".equals(this.txtky.getText())))
/*     */     {
/* 243 */       JOptionPane.showMessageDialog(this.rootPane, "Correct key");
/* 244 */       rrunning r = new rrunning();
/* 245 */       r.setLocation(360, 100);
/* 246 */       r.setVisible(true);
/* 247 */       dispose();
/*     */     }
/*     */     else {
/* 250 */       JOptionPane.showMessageDialog(this.rootPane, "Wrong user installation key please try again");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 258 */     for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
/* 259 */       if ("Nimbus".equals(info.getName())) {
/*     */         try {
/* 261 */           UIManager.setLookAndFeel(info.getClassName());
/*     */         }
/*     */         catch (ClassNotFoundException ex) {
/* 264 */           Logger.getLogger(trunning.class.getName()).log(Level.SEVERE, null, ex);
/*     */         } catch (InstantiationException ex) {
/* 266 */           Logger.getLogger(trunning.class.getName()).log(Level.SEVERE, null, ex);
/*     */         } catch (IllegalAccessException ex) {
/* 268 */           Logger.getLogger(trunning.class.getName()).log(Level.SEVERE, null, ex);
/*     */         } catch (UnsupportedLookAndFeelException ex) {
/* 270 */           Logger.getLogger(trunning.class.getName()).log(Level.SEVERE, null, ex);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 275 */     EventQueue.invokeLater(new Runnable()
/*     */     {
/*     */       public void run() {
/* 278 */         new trunning().setVisible(true);
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.trunning
 * JD-Core Version:    0.6.2
 */