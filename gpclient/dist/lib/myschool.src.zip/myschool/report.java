/*     */ package myschool;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.event.InternalFrameEvent;
/*     */ import javax.swing.event.InternalFrameListener;
/*     */ import net.sf.jasperreports.engine.JRException;
/*     */ import net.sf.jasperreports.engine.JasperFillManager;
/*     */ import net.sf.jasperreports.engine.JasperPrint;
/*     */ import net.sf.jasperreports.engine.JasperReport;
/*     */ import net.sf.jasperreports.engine.util.JRLoader;
/*     */ import net.sf.jasperreports.swing.JRViewer;
/*     */ 
/*     */ public class report extends JInternalFrame
/*     */ {
/*     */   mymain mf;
/*     */   private static JComboBox btngenm;
/*     */   private static JComboBox btngenm1;
/*     */   private JButton jButton1;
/*     */   private JLabel jLabel3;
/*     */   private JLabel jLabel4;
/*     */   private JLabel jLabel5;
/*     */   private JLabel jLabel6;
/*     */   private JLabel jLabel7;
/*     */   private JLabel jLabel8;
/*     */   private JPanel jPanel3;
/*     */   private JLabel lblstatus;
/*     */   private JTextField txtadmno;
/*     */   private JTextField txtcls;
/*     */   private JTextField txtexamno;
/*     */   private JTextField txttrm;
/*     */   private static JComboBox txttype;
/*     */   private JTextField txtyear;
/*     */ 
/*     */   public report(mymain aThis)
/*     */   {
/*  30 */     initComponents();
/*  31 */     this.mf = aThis;
/*     */   }
/*     */ 
/*     */   public void views() {
/*     */     try {
/*  36 */       int ex = Integer.parseInt(this.txtexamno.getText());
/*  37 */       int ad = Integer.parseInt(this.txtadmno.getText());
/*     */       try
/*     */       {
/*  40 */         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*  41 */         Map parameters = new HashMap();
/*  42 */         parameters.put("Admission", Integer.valueOf(ad));
/*  43 */         parameters.put("Examno", Integer.valueOf(ex));
/*  44 */         JasperReport report = (JasperReport)JRLoader.loadObject("C:/Users/Griffin M/Documents/NetBeansProjects/myschool/src/myschool/markshet.jasper");
/*  45 */         JasperPrint jasperPrint = JasperFillManager.fillReport(report, parameters, con);
/*  46 */         JFrame frame = new JFrame("Student Report Card");
/*  47 */         frame.setSize(450, 550);
/*  48 */         frame.getContentPane().add(new JRViewer(jasperPrint));
/*  49 */         frame.pack();
/*  50 */         frame.setVisible(true);
/*     */       } catch (SQLException e) {
/*     */       } catch (JRException ed) {
/*     */       }
/*     */     } catch (Exception exr) {
/*  55 */       JOptionPane.showMessageDialog(null, "You must input the examno of the exam and the admno of the student to perform this action");
/*     */     }
/*     */   }
/*     */   public void views2() {
/*     */     try { int ex = Integer.parseInt(this.txtcls.getText());
/*  60 */       int ad = Integer.parseInt(this.txtyear.getText());
/*  61 */       int tr = Integer.parseInt(this.txttrm.getText());
/*  62 */       String type = (String)txttype.getSelectedItem();
/*     */       try
/*     */       {
/*  66 */         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*  67 */         Map parameters = new HashMap();
/*  68 */         parameters.put("class", Integer.valueOf(ex));
/*  69 */         parameters.put("year", Integer.valueOf(ad));
/*  70 */         parameters.put("Term", Integer.valueOf(tr));
/*  71 */         parameters.put("Type", type);
/*  72 */         JasperReport report = (JasperReport)JRLoader.loadObject("C:/Users/Griffin M/Documents/NetBeansProjects/myschool/src/myschool/markshet2.jasper");
/*  73 */         JasperPrint jasperPrint = JasperFillManager.fillReport(report, parameters, con);
/*  74 */         JFrame frame = new JFrame("Student Report Card");
/*  75 */         frame.setSize(450, 550);
/*  76 */         frame.getContentPane().add(new JRViewer(jasperPrint));
/*  77 */         frame.getPreferredSize();
/*  78 */         frame.pack();
/*  79 */         frame.setVisible(true);
/*     */       } catch (SQLException e) {
/*     */       } catch (JRException ed) {
/*     */       }
/*     */     } catch (Exception exr) {
/*  84 */       JOptionPane.showMessageDialog(null, "You must input the Year,Term of the examination and the Class of the students to perform this action");
/*     */     }
/*     */   }
/*     */   public void views3() {
/*     */     try { int ex = Integer.parseInt(this.txtexamno.getText());
/*     */       try
/*     */       {
/*  93 */         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*  94 */         Map parameters = new HashMap();
/*  95 */         parameters.put("Examno", Integer.valueOf(ex));
/*     */ 
/*  97 */         JasperReport report = (JasperReport)JRLoader.loadObject("C:/Users/Griffin M/Documents/NetBeansProjects/myschool/src/myschool/markshet_3.jasper");
/*  98 */         JasperPrint jasperPrint = JasperFillManager.fillReport(report, parameters, con);
/*  99 */         JFrame frame = new JFrame("Exam Marksheet");
/* 100 */         frame.setSize(450, 550);
/* 101 */         frame.getContentPane().add(new JRViewer(jasperPrint));
/* 102 */         frame.getPreferredSize();
/* 103 */         frame.pack();
/* 104 */         frame.setVisible(true);
/*     */       } catch (SQLException e) {
/*     */       } catch (JRException ed) {
/*     */       }
/*     */     } catch (Exception exr) {
/* 109 */       JOptionPane.showMessageDialog(null, "You must input the Examno to perform this action");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void views4() {
/*     */     try { int ex = Integer.parseInt(this.txtcls.getText());
/* 115 */       int ad = Integer.parseInt(this.txtyear.getText());
/* 116 */       int tr = Integer.parseInt(this.txttrm.getText());
/* 117 */       String type = (String)txttype.getSelectedItem();
/*     */       try
/*     */       {
/* 122 */         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/* 123 */         Map parameters = new HashMap();
/* 124 */         parameters.put("year", Integer.valueOf(ad));
/* 125 */         parameters.put("Class", Integer.valueOf(ex));
/* 126 */         parameters.put("Type", type);
/* 127 */         parameters.put("Term", Integer.valueOf(tr));
/*     */ 
/* 129 */         JasperReport report = (JasperReport)JRLoader.loadObject("C:/Users/Griffin M/Documents/NetBeansProjects/myschool/src/myschool/markshet22.jasper");
/* 130 */         JasperPrint jasperPrint = JasperFillManager.fillReport(report, parameters, con);
/* 131 */         JFrame frame = new JFrame("Exam Marksheet");
/* 132 */         frame.getContentPane().add(new JRViewer(jasperPrint));
/* 133 */         frame.setSize(450, 550);
/* 134 */         frame.getPreferredSize();
/* 135 */         frame.pack();
/* 136 */         frame.setVisible(true);
/*     */       } catch (SQLException e) {
/*     */       } catch (JRException ed) {
/*     */       }
/*     */     } catch (Exception exr) {
/* 141 */       JOptionPane.showMessageDialog(null, "You must input the Year,Term of the examination,Class of the students and the Exam type to perform this action");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/* 148 */     btngenm1 = new JComboBox();
/* 149 */     this.jPanel3 = new JPanel();
/* 150 */     this.txtexamno = new JTextField();
/* 151 */     this.jLabel3 = new JLabel();
/* 152 */     this.txtadmno = new JTextField();
/* 153 */     this.jLabel4 = new JLabel();
/* 154 */     this.txtcls = new JTextField();
/* 155 */     this.jLabel5 = new JLabel();
/* 156 */     this.txtyear = new JTextField();
/* 157 */     this.jLabel6 = new JLabel();
/* 158 */     this.jLabel7 = new JLabel();
/* 159 */     this.txttrm = new JTextField();
/* 160 */     this.jLabel8 = new JLabel();
/* 161 */     txttype = new JComboBox();
/* 162 */     btngenm = new JComboBox();
/* 163 */     this.jButton1 = new JButton();
/* 164 */     this.lblstatus = new JLabel();
/*     */ 
/* 166 */     setClosable(true);
/* 167 */     setIconifiable(true);
/* 168 */     setMaximizable(true);
/* 169 */     setResizable(true);
/* 170 */     setTitle("Reports");
/* 171 */     addInternalFrameListener(new InternalFrameListener() {
/*     */       public void internalFrameActivated(InternalFrameEvent evt) {
/*     */       }
/*     */       public void internalFrameClosed(InternalFrameEvent evt) {
/*     */       }
/*     */       public void internalFrameClosing(InternalFrameEvent evt) {
/* 177 */         report.this.formInternalFrameClosing(evt);
/*     */       }
/*     */ 
/*     */       public void internalFrameDeactivated(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameDeiconified(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameIconified(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameOpened(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */     });
/* 189 */     btngenm1.setFont(new Font("Traditional Arabic", 0, 18));
/* 190 */     btngenm1.setModel(new DefaultComboBoxModel(new String[] { "Generate Marksheets:", "By Class", "By Form", " " }));
/* 191 */     btngenm1.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 193 */         report.this.btngenm1ActionPerformed(evt);
/*     */       }
/*     */     });
/* 197 */     this.jPanel3.setBorder(BorderFactory.createTitledBorder(null, "Search a Report", 0, 0, new Font("Traditional Arabic", 0, 18)));
/*     */ 
/* 199 */     this.txtexamno.setFont(new Font("Traditional Arabic", 0, 18));
/*     */ 
/* 201 */     this.jLabel3.setFont(new Font("Traditional Arabic", 0, 18));
/* 202 */     this.jLabel3.setText("Student Admno");
/* 203 */     this.jLabel3.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 205 */     this.txtadmno.setFont(new Font("Traditional Arabic", 0, 18));
/* 206 */     this.txtadmno.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 208 */         report.this.txtadmnoActionPerformed(evt);
/*     */       }
/*     */     });
/* 212 */     this.jLabel4.setFont(new Font("Traditional Arabic", 0, 18));
/* 213 */     this.jLabel4.setText("Exam Number");
/* 214 */     this.jLabel4.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 216 */     this.txtcls.setFont(new Font("Traditional Arabic", 0, 18));
/*     */ 
/* 218 */     this.jLabel5.setFont(new Font("Traditional Arabic", 0, 18));
/* 219 */     this.jLabel5.setText("Year");
/* 220 */     this.jLabel5.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 222 */     this.txtyear.setFont(new Font("Traditional Arabic", 0, 18));
/* 223 */     this.txtyear.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 225 */         report.this.txtyearActionPerformed(evt);
/*     */       }
/*     */     });
/* 229 */     this.jLabel6.setFont(new Font("Traditional Arabic", 0, 18));
/* 230 */     this.jLabel6.setText("Class");
/* 231 */     this.jLabel6.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 233 */     this.jLabel7.setFont(new Font("Traditional Arabic", 0, 18));
/* 234 */     this.jLabel7.setText("Term");
/* 235 */     this.jLabel7.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 237 */     this.txttrm.setFont(new Font("Traditional Arabic", 0, 18));
/* 238 */     this.txttrm.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 240 */         report.this.txttrmActionPerformed(evt);
/*     */       }
/*     */     });
/* 244 */     this.jLabel8.setFont(new Font("Traditional Arabic", 0, 18));
/* 245 */     this.jLabel8.setText("Exam Type");
/* 246 */     this.jLabel8.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 248 */     txttype.setEditable(true);
/* 249 */     txttype.setFont(new Font("Traditional Arabic", 0, 18));
/* 250 */     txttype.setModel(new DefaultComboBoxModel(new String[] { " ", "Opener Exam", "Midterm Exam", "Endterm Exam", " " }));
/* 251 */     txttype.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 253 */         report.this.txttypeActionPerformed(evt);
/*     */       }
/*     */     });
/* 257 */     GroupLayout jPanel3Layout = new GroupLayout(this.jPanel3);
/* 258 */     this.jPanel3.setLayout(jPanel3Layout);
/* 259 */     jPanel3Layout.setHorizontalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addContainerGap().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup().addComponent(this.jLabel5, -1, 113, 32767).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.txtyear, -2, 165, -2)).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel6, -1, 113, 32767).addGap(10, 10, 10).addComponent(this.txtcls, -2, 165, -2)).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel4, -1, 113, 32767).addGap(10, 10, 10).addComponent(this.txtexamno, -2, 165, -2)).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel3, -1, -1, 32767).addGap(10, 10, 10).addComponent(this.txtadmno, -2, 165, -2)).addGroup(GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel8, -1, 113, 32767).addComponent(this.jLabel7, GroupLayout.Alignment.TRAILING, -1, 113, 32767)).addGap(10, 10, 10).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(txttype, GroupLayout.Alignment.TRAILING, 0, 0, 32767).addComponent(this.txttrm, GroupLayout.Alignment.TRAILING, -1, 165, 32767)))).addContainerGap()));
/*     */ 
/* 290 */     jPanel3Layout.setVerticalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel4, -1, 29, 32767).addComponent(this.txtexamno, -2, 29, -2)).addGap(18, 18, 18).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel3, -1, -1, 32767).addComponent(this.txtadmno, -2, 29, -2)).addGap(18, 18, 18).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel5, -2, 33, -2).addComponent(this.txtyear, -2, 29, -2)).addGap(18, 18, 18).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel6, -1, 29, 32767).addComponent(this.txtcls, -2, 29, -2)).addGap(14, 14, 14).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel7, -1, -1, 32767).addComponent(this.txttrm, -2, 29, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel8, -1, -1, 32767).addComponent(txttype, -2, -1, -2)).addGap(38, 38, 38)));
/*     */ 
/* 319 */     btngenm.setFont(new Font("Traditional Arabic", 0, 18));
/* 320 */     btngenm.setModel(new DefaultComboBoxModel(new String[] { "Generate Reportcards:", "By Admno", "By Class", " " }));
/* 321 */     btngenm.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 323 */         report.this.btngenmActionPerformed(evt);
/*     */       }
/*     */     });
/* 327 */     this.jButton1.setFont(new Font("Traditional Arabic", 0, 18));
/* 328 */     this.jButton1.setText("Exam Analysis");
/* 329 */     this.jButton1.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 331 */         report.this.jButton1ActionPerformed(evt);
/*     */       }
/*     */     });
/* 335 */     this.lblstatus.setFont(new Font("Monotype Corsiva", 0, 11));
/*     */ 
/* 337 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 338 */     getContentPane().setLayout(layout);
/* 339 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGap(10, 10, 10).addComponent(this.jPanel3, -1, -1, 32767).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jButton1, -1, 197, 32767).addGroup(GroupLayout.Alignment.TRAILING, layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(btngenm, GroupLayout.Alignment.TRAILING, 0, -1, 32767).addComponent(btngenm1, -2, -1, -2)).addComponent(this.lblstatus, GroupLayout.Alignment.TRAILING, -1, 197, 32767)).addContainerGap()));
/*     */ 
/* 353 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addComponent(btngenm1, -2, 41, -2).addGap(39, 39, 39).addComponent(btngenm, -2, 41, -2).addGap(32, 32, 32).addComponent(this.jButton1, -2, 38, -2).addGap(49, 49, 49).addComponent(this.lblstatus, -2, 32, -2).addContainerGap()).addComponent(this.jPanel3, GroupLayout.Alignment.TRAILING, -1, -1, 32767))));
/*     */ 
/* 370 */     pack();
/*     */   }
/*     */ 
/*     */   private void btngenm1ActionPerformed(ActionEvent evt) {
/* 374 */     this.lblstatus.setText("Please wait while report loads.......");
/* 375 */     int index = btngenm1.getSelectedIndex();
/*     */ 
/* 377 */     if (index == 1)
/* 378 */       views3();
/* 379 */     else if (index == 2)
/* 380 */       views4();
/* 381 */     this.lblstatus.setText("");
/*     */   }
/*     */ 
/*     */   private void txtadmnoActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtyearActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txttrmActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txttypeActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void btngenmActionPerformed(ActionEvent evt) {
/* 401 */     this.lblstatus.setText("Please wait while report loads........");
/* 402 */     int ind = btngenm.getSelectedIndex();
/*     */ 
/* 420 */     if (ind == 1)
/* 421 */       views();
/* 422 */     else if (ind == 2) {
/* 423 */       views2();
/*     */     }
/* 425 */     this.lblstatus.setText("");
/*     */   }
/*     */ 
/*     */   private void formInternalFrameClosing(InternalFrameEvent evt) {
/* 429 */     dispose();
/* 430 */     this.mf.add();
/*     */   }
/*     */ 
/*     */   private void jButton1ActionPerformed(ActionEvent evt) {
/* 434 */     this.lblstatus.setText("Please wait while report loads.......");
/* 435 */     analyse en = new analyse();
/* 436 */     analyse.analyse();
/* 437 */     this.lblstatus.setText("");
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.report
 * JD-Core Version:    0.6.2
 */