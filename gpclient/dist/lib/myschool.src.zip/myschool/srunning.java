/*     */ package myschool;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JLayeredPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.UIManager.LookAndFeelInfo;
/*     */ import javax.swing.UnsupportedLookAndFeelException;
/*     */ 
/*     */ public class srunning extends JFrame
/*     */ {
/*     */   private JButton jButton2;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel2;
/*     */   private JLabel jLabel3;
/*     */   private JLabel jLabel4;
/*     */   private JLabel jLabel5;
/*     */   private JLayeredPane jLayeredPane1;
/*     */   private JPanel jPanel1;
/*     */   private JPanel jPanel2;
/*     */   private JScrollPane jScrollPane1;
/*     */   private JTextArea jTextArea1;
/*     */ 
/*     */   public srunning()
/*     */   {
/*  16 */     initComponents();
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  23 */     this.jPanel2 = new JPanel();
/*  24 */     this.jLayeredPane1 = new JLayeredPane();
/*  25 */     this.jLabel3 = new JLabel();
/*  26 */     this.jLabel1 = new JLabel();
/*  27 */     this.jLabel4 = new JLabel();
/*  28 */     this.jLabel2 = new JLabel();
/*  29 */     this.jPanel1 = new JPanel();
/*  30 */     this.jScrollPane1 = new JScrollPane();
/*  31 */     this.jTextArea1 = new JTextArea();
/*  32 */     this.jLabel5 = new JLabel();
/*  33 */     this.jButton2 = new JButton();
/*     */ 
/*  35 */     setDefaultCloseOperation(3);
/*  36 */     setTitle("Running for the first time");
/*  37 */     setAlwaysOnTop(true);
/*  38 */     setBackground(new Color(204, 204, 204));
/*     */ 
/*  40 */     this.jPanel2.setBackground(new Color(102, 102, 255));
/*  41 */     this.jPanel2.setBorder(BorderFactory.createBevelBorder(0));
/*     */ 
/*  43 */     this.jLabel3.setIcon(new ImageIcon(getClass().getResource("/myschool/imagesd.jpg")));
/*  44 */     this.jLabel3.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*  45 */     this.jLabel3.setBounds(10, 10, 50, 120);
/*  46 */     this.jLayeredPane1.add(this.jLabel3, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/*  48 */     this.jLabel1.setIcon(new ImageIcon(getClass().getResource("/myschool/14797023-illustration-of-an-asian-schoolboy-carrying-a-backpack.jpg")));
/*  49 */     this.jLabel1.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*  50 */     this.jLabel1.setBounds(150, 0, 100, 170);
/*  51 */     this.jLayeredPane1.add(this.jLabel1, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/*  53 */     this.jLabel4.setFont(new Font("Monotype Corsiva", 0, 14));
/*  54 */     this.jLabel4.setText("The high school manager 2013");
/*  55 */     this.jLabel4.setBounds(100, 170, 150, 14);
/*  56 */     this.jLayeredPane1.add(this.jLabel4, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/*  58 */     this.jLabel2.setIcon(new ImageIcon(getClass().getResource("/myschool/imagesddd.jpg")));
/*  59 */     this.jLabel2.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*  60 */     this.jLabel2.setBounds(50, 30, 120, 110);
/*  61 */     this.jLayeredPane1.add(this.jLabel2, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/*  63 */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/*  64 */     this.jPanel2.setLayout(jPanel2Layout);
/*  65 */     jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap(-1, 32767).addComponent(this.jLayeredPane1, -2, 256, -2)));
/*     */ 
/*  71 */     jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup().addComponent(this.jLayeredPane1, -2, 191, -2).addContainerGap(-1, 32767)));
/*     */ 
/*  78 */     this.jPanel1.setBackground(new Color(51, 51, 51));
/*  79 */     this.jPanel1.setBorder(BorderFactory.createEtchedBorder(0));
/*     */ 
/*  81 */     this.jTextArea1.setBackground(new Color(102, 102, 255));
/*  82 */     this.jTextArea1.setColumns(20);
/*  83 */     this.jTextArea1.setFont(new Font("Vijaya", 0, 24));
/*  84 */     this.jTextArea1.setRows(5);
/*  85 */     this.jTextArea1.setText("Please Read and Make sure you do the following:\nthe username of your mysql  database installed\nis \"root \" and password is\" muteti\":\nIf not try to add another account with the above credintials \nor re install the mysql package\nAfter that is done continue with your installation");
/*  86 */     this.jTextArea1.setFocusable(false);
/*  87 */     this.jScrollPane1.setViewportView(this.jTextArea1);
/*     */ 
/*  89 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/*  90 */     this.jPanel1.setLayout(jPanel1Layout);
/*  91 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(this.jScrollPane1, -1, 646, 32767).addContainerGap()));
/*     */ 
/*  98 */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(this.jScrollPane1, -2, 195, -2).addContainerGap(-1, 32767)));
/*     */ 
/* 106 */     this.jLabel5.setFont(new Font("Goudy Stout", 0, 14));
/* 107 */     this.jLabel5.setText("To continue :");
/*     */ 
/* 109 */     this.jButton2.setIcon(new ImageIcon(getClass().getResource("/myschool/Actions-go-next-icon.png")));
/* 110 */     this.jButton2.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 112 */         srunning.this.jButton2ActionPerformed(evt);
/*     */       }
/*     */     });
/* 116 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 117 */     getContentPane().setLayout(layout);
/* 118 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel1, -2, -1, -2).addGroup(layout.createSequentialGroup().addComponent(this.jPanel2, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.jLabel5, -1, 396, 32767).addComponent(this.jButton2, -2, 109, -2)))).addContainerGap()));
/*     */ 
/* 132 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel2, -2, -1, -2).addGroup(layout.createSequentialGroup().addGap(53, 53, 53).addComponent(this.jLabel5, -2, 61, -2).addGap(31, 31, 31).addComponent(this.jButton2, -2, 53, -2))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel1, -1, -1, 32767).addContainerGap()));
/*     */ 
/* 147 */     pack();
/*     */   }
/*     */ 
/*     */   private void jButton2ActionPerformed(ActionEvent evt) {
/* 151 */     trunning tr = new trunning();
/* 152 */     tr.setVisible(true);
/* 153 */     tr.setLocation(360, 100);
/* 154 */     dispose();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 161 */     for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
/* 162 */       if ("Nimbus".equals(info.getName())) {
/*     */         try {
/* 164 */           UIManager.setLookAndFeel(info.getClassName());
/*     */         }
/*     */         catch (ClassNotFoundException ex) {
/* 167 */           Logger.getLogger(srunning.class.getName()).log(Level.SEVERE, null, ex);
/*     */         } catch (InstantiationException ex) {
/* 169 */           Logger.getLogger(srunning.class.getName()).log(Level.SEVERE, null, ex);
/*     */         } catch (IllegalAccessException ex) {
/* 171 */           Logger.getLogger(srunning.class.getName()).log(Level.SEVERE, null, ex);
/*     */         } catch (UnsupportedLookAndFeelException ex) {
/* 173 */           Logger.getLogger(srunning.class.getName()).log(Level.SEVERE, null, ex);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 178 */     EventQueue.invokeLater(new Runnable()
/*     */     {
/*     */       public void run() {
/* 181 */         new srunning().setVisible(true);
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.srunning
 * JD-Core Version:    0.6.2
 */