/*     */ package myschool;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPasswordField;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ 
/*     */ public class newuser extends JInternalFrame
/*     */ {
/*     */   mymain mf;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel2;
/*     */   private JLabel lblflatname5;
/*     */   private JLabel lblflatname6;
/*     */   private JLabel lblflatname7;
/*     */   private JLabel lblflatname8;
/*     */   private JLabel lblflatname9;
/*     */   private JPasswordField txtpass;
/*     */   private JPasswordField txtpass1;
/*     */   private JPasswordField txtpass2;
/*     */   private JPasswordField txtphint;
/*     */   private JTextField txtuser;
/*     */ 
/*     */   newuser(mymain aThis)
/*     */   {
/*  22 */     initComponents();
/*  23 */     this.mf = aThis;
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  31 */     this.txtuser = new JTextField();
/*  32 */     this.lblflatname5 = new JLabel();
/*  33 */     this.lblflatname6 = new JLabel();
/*  34 */     this.txtpass = new JPasswordField();
/*  35 */     this.jLabel1 = new JLabel();
/*  36 */     this.jLabel2 = new JLabel();
/*  37 */     this.lblflatname7 = new JLabel();
/*  38 */     this.txtpass1 = new JPasswordField();
/*  39 */     this.lblflatname8 = new JLabel();
/*  40 */     this.txtpass2 = new JPasswordField();
/*  41 */     this.txtphint = new JPasswordField();
/*  42 */     this.lblflatname9 = new JLabel();
/*     */ 
/*  44 */     setClosable(true);
/*  45 */     setIconifiable(true);
/*  46 */     setMaximizable(true);
/*  47 */     setResizable(true);
/*  48 */     setTitle(" New User Sign In");
/*  49 */     setAutoscrolls(true);
/*     */ 
/*  51 */     this.txtuser.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  53 */         newuser.this.txtuserActionPerformed(evt);
/*     */       }
/*     */     });
/*  57 */     this.lblflatname5.setFont(new Font("Traditional Arabic", 0, 18));
/*  58 */     this.lblflatname5.setText("User Name");
/*  59 */     this.lblflatname5.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/*  61 */     this.lblflatname6.setFont(new Font("Traditional Arabic", 0, 18));
/*  62 */     this.lblflatname6.setText("Password");
/*  63 */     this.lblflatname6.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/*  65 */     this.txtpass.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  67 */         newuser.this.txtpassActionPerformed(evt);
/*     */       }
/*     */     });
/*  71 */     this.jLabel1.setFont(new Font("Traditional Arabic", 1, 18));
/*  72 */     this.jLabel1.setIcon(new ImageIcon(getClass().getResource("/myschool/resources/Close-2-icon.png")));
/*  73 */     this.jLabel1.setText("Cancel");
/*  74 */     this.jLabel1.setBorder(BorderFactory.createBevelBorder(0, Color.darkGray, null, Color.darkGray, new Color(51, 51, 51)));
/*  75 */     this.jLabel1.addMouseListener(new MouseAdapter() {
/*     */       public void mouseClicked(MouseEvent evt) {
/*  77 */         newuser.this.jLabel1MouseClicked(evt);
/*     */       }
/*     */     });
/*  81 */     this.jLabel2.setFont(new Font("Traditional Arabic", 1, 18));
/*  82 */     this.jLabel2.setIcon(new ImageIcon(getClass().getResource("/myschool/resources/Sign-Select-icon.png")));
/*  83 */     this.jLabel2.setText("Okay");
/*  84 */     this.jLabel2.setBorder(BorderFactory.createBevelBorder(0, Color.green, null, Color.green, Color.green));
/*  85 */     this.jLabel2.addMouseListener(new MouseAdapter() {
/*     */       public void mouseClicked(MouseEvent evt) {
/*  87 */         newuser.this.jLabel2MouseClicked(evt);
/*     */       }
/*     */     });
/*  91 */     this.lblflatname7.setFont(new Font("Traditional Arabic", 0, 18));
/*  92 */     this.lblflatname7.setText("New Password");
/*  93 */     this.lblflatname7.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/*  95 */     this.txtpass1.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  97 */         newuser.this.txtpass1ActionPerformed(evt);
/*     */       }
/*     */     });
/* 101 */     this.lblflatname8.setFont(new Font("Traditional Arabic", 0, 18));
/* 102 */     this.lblflatname8.setText("Confirm New Password");
/* 103 */     this.lblflatname8.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 105 */     this.txtpass2.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 107 */         newuser.this.txtpass2ActionPerformed(evt);
/*     */       }
/*     */     });
/* 111 */     this.txtphint.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 113 */         newuser.this.txtphintActionPerformed(evt);
/*     */       }
/*     */     });
/* 117 */     this.lblflatname9.setFont(new Font("Traditional Arabic", 0, 18));
/* 118 */     this.lblflatname9.setText("Password Hint");
/* 119 */     this.lblflatname9.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 121 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 122 */     getContentPane().setLayout(layout);
/* 123 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.lblflatname8, -1, 203, 32767).addComponent(this.lblflatname7, -1, 203, 32767).addComponent(this.lblflatname6, -1, 203, 32767).addComponent(this.lblflatname5, -1, 203, 32767).addComponent(this.jLabel2, GroupLayout.Alignment.TRAILING, -2, 102, -2).addComponent(this.lblflatname9, -1, 203, 32767)).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtphint, -1, 241, 32767)).addComponent(this.txtpass2, -1, 245, 32767).addComponent(this.txtpass1, GroupLayout.Alignment.TRAILING, -1, 245, 32767).addComponent(this.txtuser, GroupLayout.Alignment.TRAILING, -1, 245, 32767).addComponent(this.txtpass, -1, 245, 32767)).addContainerGap()).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel1).addGap(23, 23, 23)))));
/*     */ 
/* 150 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGap(38, 38, 38).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.txtuser, -2, -1, -2).addComponent(this.lblflatname5, -2, 22, -2)).addGap(18, 18, 18).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.lblflatname6, -2, 22, -2).addComponent(this.txtpass, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtpass1, -2, -1, -2).addComponent(this.lblflatname7, -2, 22, -2)).addGap(18, 18, 18).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.lblflatname8, -2, 22, -2).addComponent(this.txtpass2, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.lblflatname9, -2, 22, -2).addComponent(this.txtphint, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel2, -1, 64, 32767).addComponent(this.jLabel1, -1, 64, 32767)).addContainerGap()));
/*     */ 
/* 180 */     pack();
/*     */   }
/*     */ 
/*     */   private void txtuserActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtpassActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtpass1ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtpass2ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void jLabel1MouseClicked(MouseEvent evt) {
/* 200 */     dispose();
/*     */   }
/*     */ 
/*     */   private void jLabel2MouseClicked(MouseEvent evt) {
/*     */     try {
/* 205 */       String user = this.txtuser.getText();
/* 206 */       String dflt = this.txtpass.getText();
/* 207 */       String phint = this.txtphint.getText();
/* 208 */       String pass1 = this.txtpass1.getText();
/* 209 */       String pass2 = this.txtpass2.getText();
/* 210 */       Class.forName("com.mysql.jdbc.Driver");
/* 211 */       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*     */ 
/* 213 */       Statement stmnt = con.createStatement();
/* 214 */       String sql = "Select * from user where username='" + user + "'";
/* 215 */       ResultSet rs = stmnt.executeQuery(sql);
/*     */ 
/* 218 */       if (rs.next()) {
/* 219 */         if (dflt.equals("1234")) {
/* 220 */           if ((pass1.length() > 5) && (pass2.length() > 5) && (pass1.equals(pass2))) {
/* 221 */             Statement st = con.createStatement();
/* 222 */             String sq = "Update user set password='" + pass1 + "'" + "where username='" + user + "'";
/* 223 */             String s = "Update user set hint='" + phint + "'" + "where username='" + user + "'";
/* 224 */             st.execute(sq);
/* 225 */             st.execute(s);
/* 226 */             dispose();
/* 227 */             JOptionPane.showMessageDialog(null, "Password succesfully updated\nYou can now login to the system");
/*     */ 
/* 229 */             this.mf.login();
/*     */           }
/* 234 */           else if (pass1 != pass2) {
/* 235 */             JOptionPane.showMessageDialog(null, "Your confirmation password does not match with the newpassword");
/*     */           }
/* 238 */           else if ((pass1.length() <= 5) || (pass2.length() <= 5)) {
/* 239 */             JOptionPane.showMessageDialog(null, "Your new password must be of 6 or more characters");
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 244 */           JOptionPane.showMessageDialog(null, "Wrong default password");
/*     */         }
/*     */       }
/* 247 */       else JOptionPane.showMessageDialog(null, "That username does not exist please try again"); 
/*     */     }
/*     */     catch (SQLException ex)
/*     */     {
/* 250 */       Logger.getLogger(newuser.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } catch (ClassNotFoundException ex) {
/* 252 */       Logger.getLogger(newuser.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void txtphintActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.newuser
 * JD-Core Version:    0.6.2
 */