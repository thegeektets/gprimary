/*     */ package myschool;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.event.InternalFrameEvent;
/*     */ import javax.swing.event.InternalFrameListener;
/*     */ 
/*     */ public class gradingsystem extends JInternalFrame
/*     */ {
/*     */   mymain mf;
/*     */   private JButton jButton2;
/*     */   private JButton jButton3;
/*     */   private JPanel jPanel1;
/*     */   private JPanel jPanel2;
/*     */   private JPanel jPanel3;
/*     */   private JTextField txtgrade;
/*     */   private JTextField txtgrade1;
/*     */   private JTextField txtgrade10;
/*     */   private JTextField txtgrade11;
/*     */   private JTextField txtgrade12;
/*     */   private JTextField txtgrade13;
/*     */   private JTextField txtgrade14;
/*     */   private JTextField txtgrade15;
/*     */   private JTextField txtgrade16;
/*     */   private JTextField txtgrade17;
/*     */   private JTextField txtgrade18;
/*     */   private JTextField txtgrade19;
/*     */   private JTextField txtgrade2;
/*     */   private JTextField txtgrade20;
/*     */   private JTextField txtgrade21;
/*     */   private JTextField txtgrade22;
/*     */   private JTextField txtgrade23;
/*     */   private JTextField txtgrade24;
/*     */   private JTextField txtgrade25;
/*     */   private JTextField txtgrade26;
/*     */   private JTextField txtgrade27;
/*     */   private JTextField txtgrade28;
/*     */   private JTextField txtgrade29;
/*     */   private JTextField txtgrade3;
/*     */   private JTextField txtgrade30;
/*     */   private JTextField txtgrade31;
/*     */   private JTextField txtgrade32;
/*     */   private JTextField txtgrade33;
/*     */   private JTextField txtgrade34;
/*     */   private JTextField txtgrade35;
/*     */   private JTextField txtgrade4;
/*     */   private JTextField txtgrade5;
/*     */   private JTextField txtgrade6;
/*     */   private JTextField txtgrade7;
/*     */   private JTextField txtgrade8;
/*     */   private JTextField txtgrade9;
/*     */ 
/*     */   public gradingsystem(mymain me)
/*     */   {
/*  18 */     initComponents();
/*  19 */     this.mf = me;
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  25 */     this.jPanel1 = new JPanel();
/*  26 */     this.txtgrade = new JTextField();
/*  27 */     this.txtgrade1 = new JTextField();
/*  28 */     this.txtgrade2 = new JTextField();
/*  29 */     this.txtgrade3 = new JTextField();
/*  30 */     this.txtgrade4 = new JTextField();
/*  31 */     this.txtgrade5 = new JTextField();
/*  32 */     this.txtgrade6 = new JTextField();
/*  33 */     this.txtgrade7 = new JTextField();
/*  34 */     this.txtgrade8 = new JTextField();
/*  35 */     this.txtgrade9 = new JTextField();
/*  36 */     this.txtgrade10 = new JTextField();
/*  37 */     this.txtgrade11 = new JTextField();
/*  38 */     this.jButton2 = new JButton();
/*  39 */     this.jPanel3 = new JPanel();
/*  40 */     this.txtgrade12 = new JTextField();
/*  41 */     this.txtgrade13 = new JTextField();
/*  42 */     this.txtgrade14 = new JTextField();
/*  43 */     this.txtgrade15 = new JTextField();
/*  44 */     this.txtgrade16 = new JTextField();
/*  45 */     this.txtgrade17 = new JTextField();
/*  46 */     this.txtgrade18 = new JTextField();
/*  47 */     this.txtgrade19 = new JTextField();
/*  48 */     this.txtgrade20 = new JTextField();
/*  49 */     this.txtgrade21 = new JTextField();
/*  50 */     this.txtgrade22 = new JTextField();
/*  51 */     this.txtgrade23 = new JTextField();
/*  52 */     this.jPanel2 = new JPanel();
/*  53 */     this.txtgrade24 = new JTextField();
/*  54 */     this.txtgrade25 = new JTextField();
/*  55 */     this.txtgrade26 = new JTextField();
/*  56 */     this.txtgrade27 = new JTextField();
/*  57 */     this.txtgrade28 = new JTextField();
/*  58 */     this.txtgrade29 = new JTextField();
/*  59 */     this.txtgrade30 = new JTextField();
/*  60 */     this.txtgrade31 = new JTextField();
/*  61 */     this.txtgrade32 = new JTextField();
/*  62 */     this.txtgrade33 = new JTextField();
/*  63 */     this.txtgrade34 = new JTextField();
/*  64 */     this.txtgrade35 = new JTextField();
/*  65 */     this.jButton3 = new JButton();
/*     */ 
/*  67 */     setClosable(true);
/*  68 */     setIconifiable(true);
/*  69 */     setMaximizable(true);
/*  70 */     setResizable(true);
/*  71 */     setTitle("Grading system");
/*  72 */     addInternalFrameListener(new InternalFrameListener() {
/*     */       public void internalFrameActivated(InternalFrameEvent evt) {
/*     */       }
/*     */       public void internalFrameClosed(InternalFrameEvent evt) {
/*     */       }
/*     */       public void internalFrameClosing(InternalFrameEvent evt) {
/*  78 */         gradingsystem.this.formInternalFrameClosing(evt);
/*     */       }
/*     */ 
/*     */       public void internalFrameDeactivated(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameDeiconified(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameIconified(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameOpened(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */     });
/*  90 */     this.jPanel1.setBorder(BorderFactory.createTitledBorder(null, "Grades", 2, 0, new Font("Traditional Arabic", 0, 18)));
/*     */ 
/*  92 */     this.txtgrade.setFont(new Font("Traditional Arabic", 0, 14));
/*  93 */     this.txtgrade.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/*  94 */     this.txtgrade.setFocusable(false);
/*  95 */     this.txtgrade.setHighlighter(null);
/*  96 */     this.txtgrade.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  98 */         gradingsystem.this.txtgradeActionPerformed(evt);
/*     */       }
/*     */     });
/* 102 */     this.txtgrade1.setFont(new Font("Traditional Arabic", 0, 14));
/* 103 */     this.txtgrade1.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 104 */     this.txtgrade1.setFocusable(false);
/* 105 */     this.txtgrade1.setHighlighter(null);
/* 106 */     this.txtgrade1.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 108 */         gradingsystem.this.txtgrade1ActionPerformed(evt);
/*     */       }
/*     */     });
/* 112 */     this.txtgrade2.setFont(new Font("Traditional Arabic", 0, 14));
/* 113 */     this.txtgrade2.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 114 */     this.txtgrade2.setFocusable(false);
/* 115 */     this.txtgrade2.setHighlighter(null);
/* 116 */     this.txtgrade2.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 118 */         gradingsystem.this.txtgrade2ActionPerformed(evt);
/*     */       }
/*     */     });
/* 122 */     this.txtgrade3.setFont(new Font("Traditional Arabic", 0, 14));
/* 123 */     this.txtgrade3.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 124 */     this.txtgrade3.setFocusable(false);
/* 125 */     this.txtgrade3.setHighlighter(null);
/* 126 */     this.txtgrade3.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 128 */         gradingsystem.this.txtgrade3ActionPerformed(evt);
/*     */       }
/*     */     });
/* 132 */     this.txtgrade4.setFont(new Font("Traditional Arabic", 0, 14));
/* 133 */     this.txtgrade4.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 134 */     this.txtgrade4.setFocusable(false);
/* 135 */     this.txtgrade4.setHighlighter(null);
/* 136 */     this.txtgrade4.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 138 */         gradingsystem.this.txtgrade4ActionPerformed(evt);
/*     */       }
/*     */     });
/* 142 */     this.txtgrade5.setFont(new Font("Traditional Arabic", 0, 14));
/* 143 */     this.txtgrade5.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 144 */     this.txtgrade5.setFocusable(false);
/* 145 */     this.txtgrade5.setHighlighter(null);
/* 146 */     this.txtgrade5.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 148 */         gradingsystem.this.txtgrade5ActionPerformed(evt);
/*     */       }
/*     */     });
/* 152 */     this.txtgrade6.setFont(new Font("Traditional Arabic", 0, 14));
/* 153 */     this.txtgrade6.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 154 */     this.txtgrade6.setFocusable(false);
/* 155 */     this.txtgrade6.setHighlighter(null);
/* 156 */     this.txtgrade6.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 158 */         gradingsystem.this.txtgrade6ActionPerformed(evt);
/*     */       }
/*     */     });
/* 162 */     this.txtgrade7.setFont(new Font("Traditional Arabic", 0, 14));
/* 163 */     this.txtgrade7.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 164 */     this.txtgrade7.setFocusable(false);
/* 165 */     this.txtgrade7.setHighlighter(null);
/* 166 */     this.txtgrade7.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 168 */         gradingsystem.this.txtgrade7ActionPerformed(evt);
/*     */       }
/*     */     });
/* 172 */     this.txtgrade8.setFont(new Font("Traditional Arabic", 0, 14));
/* 173 */     this.txtgrade8.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 174 */     this.txtgrade8.setFocusable(false);
/* 175 */     this.txtgrade8.setHighlighter(null);
/* 176 */     this.txtgrade8.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 178 */         gradingsystem.this.txtgrade8ActionPerformed(evt);
/*     */       }
/*     */     });
/* 182 */     this.txtgrade9.setFont(new Font("Traditional Arabic", 0, 14));
/* 183 */     this.txtgrade9.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 184 */     this.txtgrade9.setFocusable(false);
/* 185 */     this.txtgrade9.setHighlighter(null);
/* 186 */     this.txtgrade9.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 188 */         gradingsystem.this.txtgrade9ActionPerformed(evt);
/*     */       }
/*     */     });
/* 192 */     this.txtgrade10.setFont(new Font("Traditional Arabic", 0, 14));
/* 193 */     this.txtgrade10.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 194 */     this.txtgrade10.setFocusable(false);
/* 195 */     this.txtgrade10.setHighlighter(null);
/* 196 */     this.txtgrade10.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 198 */         gradingsystem.this.txtgrade10ActionPerformed(evt);
/*     */       }
/*     */     });
/* 202 */     this.txtgrade11.setFont(new Font("Traditional Arabic", 0, 14));
/* 203 */     this.txtgrade11.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 204 */     this.txtgrade11.setFocusable(false);
/* 205 */     this.txtgrade11.setHighlighter(null);
/* 206 */     this.txtgrade11.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 208 */         gradingsystem.this.txtgrade11ActionPerformed(evt);
/*     */       }
/*     */     });
/* 212 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/* 213 */     this.jPanel1.setLayout(jPanel1Layout);
/* 214 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.txtgrade, -1, 92, 32767).addComponent(this.txtgrade1, -1, 92, 32767).addComponent(this.txtgrade2, GroupLayout.Alignment.TRAILING, -1, 92, 32767).addComponent(this.txtgrade3, -1, 92, 32767).addComponent(this.txtgrade4, -1, 92, 32767).addComponent(this.txtgrade5, -1, 92, 32767).addComponent(this.txtgrade6, -1, 92, 32767).addComponent(this.txtgrade11, -1, 92, 32767).addComponent(this.txtgrade10, -1, 92, 32767).addComponent(this.txtgrade9, -1, 92, 32767).addComponent(this.txtgrade7, -1, 92, 32767).addComponent(this.txtgrade8, GroupLayout.Alignment.TRAILING, -1, 92, 32767)).addContainerGap()));
/*     */ 
/* 233 */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.txtgrade, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade1, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade2, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade3, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade4, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade5, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade6, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade7, -2, 28, -2).addGap(2, 2, 2).addComponent(this.txtgrade8, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade9, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade10, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade11, -2, 28, -2).addContainerGap(31, 32767)));
/*     */ 
/* 262 */     this.jButton2.setIcon(new ImageIcon(getClass().getResource("/myschool/Actions-go-next-icon.png")));
/* 263 */     this.jButton2.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 265 */         gradingsystem.this.jButton2ActionPerformed(evt);
/*     */       }
/*     */     });
/* 269 */     this.jPanel3.setBorder(BorderFactory.createTitledBorder(null, "Upper Limit\n", 2, 0, new Font("Traditional Arabic", 0, 18)));
/*     */ 
/* 271 */     this.txtgrade12.setFont(new Font("Traditional Arabic", 0, 14));
/* 272 */     this.txtgrade12.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 273 */     this.txtgrade12.setHighlighter(null);
/* 274 */     this.txtgrade12.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 276 */         gradingsystem.this.txtgrade12ActionPerformed(evt);
/*     */       }
/*     */     });
/* 280 */     this.txtgrade13.setFont(new Font("Traditional Arabic", 0, 14));
/* 281 */     this.txtgrade13.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 282 */     this.txtgrade13.setHighlighter(null);
/* 283 */     this.txtgrade13.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 285 */         gradingsystem.this.txtgrade13ActionPerformed(evt);
/*     */       }
/*     */     });
/* 289 */     this.txtgrade14.setFont(new Font("Traditional Arabic", 0, 14));
/* 290 */     this.txtgrade14.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 291 */     this.txtgrade14.setHighlighter(null);
/* 292 */     this.txtgrade14.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 294 */         gradingsystem.this.txtgrade14ActionPerformed(evt);
/*     */       }
/*     */     });
/* 298 */     this.txtgrade15.setFont(new Font("Traditional Arabic", 0, 14));
/* 299 */     this.txtgrade15.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 300 */     this.txtgrade15.setHighlighter(null);
/* 301 */     this.txtgrade15.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 303 */         gradingsystem.this.txtgrade15ActionPerformed(evt);
/*     */       }
/*     */     });
/* 307 */     this.txtgrade16.setFont(new Font("Traditional Arabic", 0, 14));
/* 308 */     this.txtgrade16.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 309 */     this.txtgrade16.setHighlighter(null);
/* 310 */     this.txtgrade16.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 312 */         gradingsystem.this.txtgrade16ActionPerformed(evt);
/*     */       }
/*     */     });
/* 316 */     this.txtgrade17.setFont(new Font("Traditional Arabic", 0, 14));
/* 317 */     this.txtgrade17.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 318 */     this.txtgrade17.setHighlighter(null);
/* 319 */     this.txtgrade17.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 321 */         gradingsystem.this.txtgrade17ActionPerformed(evt);
/*     */       }
/*     */     });
/* 325 */     this.txtgrade18.setFont(new Font("Traditional Arabic", 0, 14));
/* 326 */     this.txtgrade18.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 327 */     this.txtgrade18.setHighlighter(null);
/* 328 */     this.txtgrade18.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 330 */         gradingsystem.this.txtgrade18ActionPerformed(evt);
/*     */       }
/*     */     });
/* 334 */     this.txtgrade19.setFont(new Font("Traditional Arabic", 0, 14));
/* 335 */     this.txtgrade19.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 336 */     this.txtgrade19.setHighlighter(null);
/* 337 */     this.txtgrade19.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 339 */         gradingsystem.this.txtgrade19ActionPerformed(evt);
/*     */       }
/*     */     });
/* 343 */     this.txtgrade20.setFont(new Font("Traditional Arabic", 0, 14));
/* 344 */     this.txtgrade20.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 345 */     this.txtgrade20.setHighlighter(null);
/* 346 */     this.txtgrade20.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 348 */         gradingsystem.this.txtgrade20ActionPerformed(evt);
/*     */       }
/*     */     });
/* 352 */     this.txtgrade21.setFont(new Font("Traditional Arabic", 0, 14));
/* 353 */     this.txtgrade21.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 354 */     this.txtgrade21.setHighlighter(null);
/* 355 */     this.txtgrade21.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 357 */         gradingsystem.this.txtgrade21ActionPerformed(evt);
/*     */       }
/*     */     });
/* 361 */     this.txtgrade22.setFont(new Font("Traditional Arabic", 0, 14));
/* 362 */     this.txtgrade22.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 363 */     this.txtgrade22.setHighlighter(null);
/* 364 */     this.txtgrade22.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 366 */         gradingsystem.this.txtgrade22ActionPerformed(evt);
/*     */       }
/*     */     });
/* 370 */     this.txtgrade23.setFont(new Font("Traditional Arabic", 0, 14));
/* 371 */     this.txtgrade23.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 372 */     this.txtgrade23.setHighlighter(null);
/* 373 */     this.txtgrade23.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 375 */         gradingsystem.this.txtgrade23ActionPerformed(evt);
/*     */       }
/*     */     });
/* 379 */     GroupLayout jPanel3Layout = new GroupLayout(this.jPanel3);
/* 380 */     this.jPanel3.setLayout(jPanel3Layout);
/* 381 */     jPanel3Layout.setHorizontalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addContainerGap().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.txtgrade13, -1, 86, 32767).addComponent(this.txtgrade16, -1, 86, 32767).addComponent(this.txtgrade21, GroupLayout.Alignment.TRAILING, -1, 86, 32767).addComponent(this.txtgrade20, -1, 86, 32767).addComponent(this.txtgrade23, -1, 86, 32767).addComponent(this.txtgrade22, -1, 86, 32767).addComponent(this.txtgrade18, -1, 86, 32767).addComponent(this.txtgrade12, -1, 86, 32767).addComponent(this.txtgrade15, -1, 86, 32767).addComponent(this.txtgrade14, -1, 86, 32767).addComponent(this.txtgrade17, -1, 86, 32767).addComponent(this.txtgrade19, GroupLayout.Alignment.TRAILING, -1, 86, 32767)).addContainerGap()));
/*     */ 
/* 400 */     jPanel3Layout.setVerticalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.txtgrade13, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade16, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade21, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade20, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade23, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade22, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade18, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade17, -2, 28, -2).addGap(2, 2, 2).addComponent(this.txtgrade19, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade14, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade15, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade12, -2, 28, -2).addContainerGap(31, 32767)));
/*     */ 
/* 429 */     this.jPanel2.setBorder(BorderFactory.createTitledBorder(null, "Lower limit", 2, 0, new Font("Traditional Arabic", 0, 18)));
/*     */ 
/* 431 */     this.txtgrade24.setFont(new Font("Traditional Arabic", 0, 14));
/* 432 */     this.txtgrade24.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 433 */     this.txtgrade24.setHighlighter(null);
/* 434 */     this.txtgrade24.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 436 */         gradingsystem.this.txtgrade24ActionPerformed(evt);
/*     */       }
/*     */     });
/* 440 */     this.txtgrade25.setFont(new Font("Traditional Arabic", 0, 14));
/* 441 */     this.txtgrade25.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 442 */     this.txtgrade25.setHighlighter(null);
/* 443 */     this.txtgrade25.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 445 */         gradingsystem.this.txtgrade25ActionPerformed(evt);
/*     */       }
/*     */     });
/* 449 */     this.txtgrade26.setFont(new Font("Traditional Arabic", 0, 14));
/* 450 */     this.txtgrade26.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 451 */     this.txtgrade26.setHighlighter(null);
/* 452 */     this.txtgrade26.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 454 */         gradingsystem.this.txtgrade26ActionPerformed(evt);
/*     */       }
/*     */     });
/* 458 */     this.txtgrade27.setFont(new Font("Traditional Arabic", 0, 14));
/* 459 */     this.txtgrade27.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 460 */     this.txtgrade27.setHighlighter(null);
/* 461 */     this.txtgrade27.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 463 */         gradingsystem.this.txtgrade27ActionPerformed(evt);
/*     */       }
/*     */     });
/* 467 */     this.txtgrade28.setFont(new Font("Traditional Arabic", 0, 14));
/* 468 */     this.txtgrade28.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 469 */     this.txtgrade28.setHighlighter(null);
/* 470 */     this.txtgrade28.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 472 */         gradingsystem.this.txtgrade28ActionPerformed(evt);
/*     */       }
/*     */     });
/* 476 */     this.txtgrade29.setFont(new Font("Traditional Arabic", 0, 14));
/* 477 */     this.txtgrade29.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 478 */     this.txtgrade29.setHighlighter(null);
/* 479 */     this.txtgrade29.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 481 */         gradingsystem.this.txtgrade29ActionPerformed(evt);
/*     */       }
/*     */     });
/* 485 */     this.txtgrade30.setFont(new Font("Traditional Arabic", 0, 14));
/* 486 */     this.txtgrade30.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 487 */     this.txtgrade30.setHighlighter(null);
/* 488 */     this.txtgrade30.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 490 */         gradingsystem.this.txtgrade30ActionPerformed(evt);
/*     */       }
/*     */     });
/* 494 */     this.txtgrade31.setFont(new Font("Traditional Arabic", 0, 14));
/* 495 */     this.txtgrade31.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 496 */     this.txtgrade31.setHighlighter(null);
/* 497 */     this.txtgrade31.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 499 */         gradingsystem.this.txtgrade31ActionPerformed(evt);
/*     */       }
/*     */     });
/* 503 */     this.txtgrade32.setFont(new Font("Traditional Arabic", 0, 14));
/* 504 */     this.txtgrade32.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 505 */     this.txtgrade32.setHighlighter(null);
/* 506 */     this.txtgrade32.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 508 */         gradingsystem.this.txtgrade32ActionPerformed(evt);
/*     */       }
/*     */     });
/* 512 */     this.txtgrade33.setFont(new Font("Traditional Arabic", 0, 14));
/* 513 */     this.txtgrade33.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 514 */     this.txtgrade33.setHighlighter(null);
/* 515 */     this.txtgrade33.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 517 */         gradingsystem.this.txtgrade33ActionPerformed(evt);
/*     */       }
/*     */     });
/* 521 */     this.txtgrade34.setFont(new Font("Traditional Arabic", 0, 14));
/* 522 */     this.txtgrade34.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 523 */     this.txtgrade34.setHighlighter(null);
/* 524 */     this.txtgrade34.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 526 */         gradingsystem.this.txtgrade34ActionPerformed(evt);
/*     */       }
/*     */     });
/* 530 */     this.txtgrade35.setFont(new Font("Traditional Arabic", 0, 14));
/* 531 */     this.txtgrade35.setBorder(BorderFactory.createEtchedBorder(new Color(153, 153, 153), new Color(102, 102, 102)));
/* 532 */     this.txtgrade35.setHighlighter(null);
/* 533 */     this.txtgrade35.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 535 */         gradingsystem.this.txtgrade35ActionPerformed(evt);
/*     */       }
/*     */     });
/* 539 */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/* 540 */     this.jPanel2.setLayout(jPanel2Layout);
/* 541 */     jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.txtgrade25, -1, 79, 32767).addComponent(this.txtgrade28, -1, 79, 32767).addComponent(this.txtgrade33, GroupLayout.Alignment.TRAILING, -1, 79, 32767).addComponent(this.txtgrade32, -1, 79, 32767).addComponent(this.txtgrade35, -1, 79, 32767).addComponent(this.txtgrade34, -1, 79, 32767).addComponent(this.txtgrade30, -1, 79, 32767).addComponent(this.txtgrade24, -1, 79, 32767).addComponent(this.txtgrade27, -1, 79, 32767).addComponent(this.txtgrade26, -1, 79, 32767).addComponent(this.txtgrade29, -1, 79, 32767).addComponent(this.txtgrade31, GroupLayout.Alignment.TRAILING, -1, 79, 32767)).addContainerGap()));
/*     */ 
/* 560 */     jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.txtgrade25, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade28, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade33, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade32, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade35, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade34, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade30, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade29, -2, 28, -2).addGap(2, 2, 2).addComponent(this.txtgrade31, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade26, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade27, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtgrade24, -2, 28, -2).addContainerGap(31, 32767)));
/*     */ 
/* 589 */     this.jButton3.setIcon(new ImageIcon(getClass().getResource("/myschool/Actions-document-edit-icon.png")));
/* 590 */     this.jButton3.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 592 */         gradingsystem.this.jButton3ActionPerformed(evt);
/*     */       }
/*     */     });
/* 596 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 597 */     getContentPane().setLayout(layout);
/* 598 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jPanel1, -2, -1, -2).addGap(18, 18, 18).addComponent(this.jPanel3, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel2, -2, -1, -2).addGap(18, 18, 18).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jButton2, -2, 59, -2).addComponent(this.jButton3, -2, 59, -2)).addContainerGap(-1, 32767)));
/*     */ 
/* 613 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGap(215, 215, 215).addComponent(this.jButton3, -2, 53, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jButton2, -2, 53, -2)).addComponent(this.jPanel2, -1, -1, 32767).addComponent(this.jPanel3, -1, -1, 32767).addComponent(this.jPanel1, -1, -1, 32767))));
/*     */ 
/* 628 */     pack();
/*     */   }
/*     */ 
/*     */   private void txtgradeActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade1ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade2ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade3ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade4ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade5ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade6ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade8ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade9ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade10ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade11ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade7ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void jButton2ActionPerformed(ActionEvent evt)
/*     */   {
/*     */     try {
/* 682 */       Class.forName("com.mysql.jdbc.Driver");
/* 683 */       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*     */ 
/* 685 */       String sql = "Select * From grades ";
/*     */ 
/* 688 */       Statement stm = con.createStatement();
/* 689 */       ResultSet rs = stm.executeQuery(sql);
/* 690 */       rs.next();
/* 691 */       this.txtgrade.setText(rs.getString("grade"));
/* 692 */       this.txtgrade13.setText("" + rs.getInt("maximum"));
/* 693 */       this.txtgrade25.setText("" + rs.getInt("minmum"));
/* 694 */       rs.next();
/* 695 */       this.txtgrade1.setText(rs.getString("grade"));
/* 696 */       this.txtgrade16.setText("" + rs.getInt("maximum"));
/* 697 */       this.txtgrade28.setText("" + rs.getInt("minmum"));
/* 698 */       rs.next();
/* 699 */       this.txtgrade3.setText(rs.getString("grade"));
/* 700 */       this.txtgrade20.setText("" + rs.getInt("maximum"));
/* 701 */       this.txtgrade32.setText("" + rs.getInt("minmum"));
/* 702 */       rs.next();
/* 703 */       this.txtgrade2.setText(rs.getString("grade"));
/* 704 */       this.txtgrade21.setText("" + rs.getInt("maximum"));
/* 705 */       this.txtgrade33.setText("" + rs.getInt("minmum"));
/*     */ 
/* 708 */       rs.next();
/* 709 */       this.txtgrade4.setText(rs.getString("grade"));
/* 710 */       this.txtgrade23.setText("" + rs.getInt("maximum"));
/* 711 */       this.txtgrade35.setText("" + rs.getInt("minmum"));
/*     */ 
/* 714 */       rs.next();
/* 715 */       this.txtgrade6.setText(rs.getString("grade"));
/* 716 */       this.txtgrade18.setText("" + rs.getInt("maximum"));
/* 717 */       this.txtgrade30.setText("" + rs.getInt("minmum"));
/* 718 */       rs.next();
/* 719 */       this.txtgrade5.setText(rs.getString("grade"));
/* 720 */       this.txtgrade22.setText("" + rs.getInt("maximum"));
/* 721 */       this.txtgrade34.setText("" + rs.getInt("minmum"));
/* 722 */       rs.next();
/* 723 */       this.txtgrade7.setText(rs.getString("grade"));
/* 724 */       this.txtgrade17.setText("" + rs.getInt("maximum"));
/* 725 */       this.txtgrade29.setText("" + rs.getInt("minmum"));
/*     */ 
/* 727 */       rs.next();
/* 728 */       this.txtgrade9.setText(rs.getString("grade"));
/* 729 */       this.txtgrade14.setText("" + rs.getInt("maximum"));
/* 730 */       this.txtgrade26.setText("" + rs.getInt("minmum"));
/* 731 */       rs.next();
/* 732 */       this.txtgrade8.setText(rs.getString("grade"));
/* 733 */       this.txtgrade19.setText("" + rs.getInt("maximum"));
/* 734 */       this.txtgrade31.setText("" + rs.getInt("minmum"));
/* 735 */       rs.next();
/* 736 */       this.txtgrade10.setText(rs.getString("grade"));
/* 737 */       this.txtgrade15.setText("" + rs.getInt("maximum"));
/* 738 */       this.txtgrade27.setText("" + rs.getInt("minmum"));
/* 739 */       rs.next();
/* 740 */       this.txtgrade11.setText(rs.getString("grade"));
/* 741 */       this.txtgrade12.setText("" + rs.getInt("maximum"));
/* 742 */       this.txtgrade24.setText("" + rs.getInt("minmum"));
/*     */     } catch (SQLException ex) {
/* 744 */       Logger.getLogger(gradingsystem.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } catch (ClassNotFoundException ex) {
/* 746 */       Logger.getLogger(gradingsystem.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void txtgrade12ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade13ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade14ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade15ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade16ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade17ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade18ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade19ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade20ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade21ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade22ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade23ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade24ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade25ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade26ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade27ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade28ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade29ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade30ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade31ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade32ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade33ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade34ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtgrade35ActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void jButton3ActionPerformed(ActionEvent evt)
/*     */   {
/*     */     try
/*     */     {
/* 859 */       Class.forName("com.mysql.jdbc.Driver");
/* 860 */       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*     */ 
/* 862 */       String stat = mymain.lblstatus.getText();
/* 863 */       int index = stat.lastIndexOf("as");
/* 864 */       String prv = mymain.lblstatus.getText().substring(index);
/* 865 */       String[] options = new String[2];
/* 866 */       options[0] = "Yes";
/* 867 */       options[1] = "No";
/*     */ 
/* 871 */       if (prv.contains("Admin")) {
/* 872 */         int val = JOptionPane.showOptionDialog(this.rootPane, "Are you sure you want to make changes to the system", "Confirm changes", 0, 1, this.frameIcon, options, Integer.valueOf(0));
/* 873 */         if (val == 1)
/* 874 */           JOptionPane.showMessageDialog(null, "No updates were made");
/*     */         else
/*     */           try
/*     */           {
/* 878 */             String a = this.txtgrade.getText();
/* 879 */             int max = Integer.parseInt(this.txtgrade13.getText());
/* 880 */             int min = Integer.parseInt(this.txtgrade25.getText());
/* 881 */             PreparedStatement sts = con.prepareStatement("update grades set grade=?,maximum=?,minmum=? where grades.key=?");
/* 882 */             sts.setInt(2, max);
/* 883 */             sts.setInt(3, min);
/* 884 */             sts.setString(1, a);
/* 885 */             sts.setInt(4, 1);
/* 886 */             sts.executeUpdate();
/* 887 */             a = this.txtgrade1.getText();
/* 888 */             max = Integer.parseInt(this.txtgrade16.getText());
/* 889 */             min = Integer.parseInt(this.txtgrade28.getText());
/* 890 */             PreparedStatement st = con.prepareStatement("update grades set grade=?,maximum=?,minmum=? where grades.key=2");
/* 891 */             st.setInt(2, max);
/* 892 */             st.setInt(3, min);
/* 893 */             st.setString(1, a);
/* 894 */             st.executeUpdate();
/*     */ 
/* 896 */             a = this.txtgrade2.getText();
/* 897 */             max = Integer.parseInt(this.txtgrade21.getText());
/* 898 */             min = Integer.parseInt(this.txtgrade33.getText());
/* 899 */             PreparedStatement str = con.prepareStatement("update grades set grade=?,maximum=?,minmum=? where grades.key=3");
/* 900 */             str.setInt(2, max);
/* 901 */             str.setInt(3, min);
/* 902 */             str.setString(1, a);
/* 903 */             str.executeUpdate();
/* 904 */             a = this.txtgrade3.getText();
/* 905 */             max = Integer.parseInt(this.txtgrade20.getText());
/* 906 */             min = Integer.parseInt(this.txtgrade32.getText());
/* 907 */             sts = con.prepareStatement("update grades set grade=?,maximum=?,minmum=? where grades.key=4");
/* 908 */             sts.setInt(2, max);
/* 909 */             sts.setInt(3, min);
/* 910 */             sts.setString(1, a);
/* 911 */             sts.executeUpdate();
/*     */ 
/* 913 */             a = this.txtgrade4.getText();
/* 914 */             max = Integer.parseInt(this.txtgrade23.getText());
/* 915 */             min = Integer.parseInt(this.txtgrade35.getText());
/* 916 */             sts = con.prepareStatement("update grades set grade=?,maximum=?,minmum=? where grades.key=5");
/* 917 */             sts.setInt(2, max);
/* 918 */             sts.setInt(3, min);
/* 919 */             sts.setString(1, a);
/* 920 */             sts.executeUpdate();
/* 921 */             a = this.txtgrade5.getText();
/* 922 */             max = Integer.parseInt(this.txtgrade22.getText());
/* 923 */             min = Integer.parseInt(this.txtgrade34.getText());
/* 924 */             sts = con.prepareStatement("update grades set grade=?,maximum=?,minmum=? where grades.key=6");
/* 925 */             sts.setInt(2, max);
/* 926 */             sts.setInt(3, min);
/* 927 */             sts.setString(1, a);
/* 928 */             sts.executeUpdate();
/* 929 */             a = this.txtgrade6.getText();
/* 930 */             max = Integer.parseInt(this.txtgrade18.getText());
/* 931 */             min = Integer.parseInt(this.txtgrade30.getText());
/* 932 */             sts = con.prepareStatement("update grades set grade=?,maximum=?,minmum=? where grades.key=7");
/* 933 */             sts.setInt(2, max);
/* 934 */             sts.setInt(3, min);
/* 935 */             sts.setString(1, a);
/* 936 */             sts.executeUpdate();
/*     */ 
/* 938 */             a = this.txtgrade7.getText();
/* 939 */             max = Integer.parseInt(this.txtgrade17.getText());
/* 940 */             min = Integer.parseInt(this.txtgrade29.getText());
/* 941 */             sts = con.prepareStatement("update grades set grade=?,maximum=?,minmum=? where grades.key=8");
/* 942 */             sts.setInt(2, max);
/* 943 */             sts.setInt(3, min);
/* 944 */             sts.setString(1, a);
/* 945 */             sts.executeUpdate();
/*     */ 
/* 947 */             a = this.txtgrade8.getText();
/* 948 */             max = Integer.parseInt(this.txtgrade19.getText());
/* 949 */             min = Integer.parseInt(this.txtgrade31.getText());
/* 950 */             sts = con.prepareStatement("update grades set grade=?,maximum=?,minmum=? where grades.key=9");
/* 951 */             sts.setInt(2, max);
/* 952 */             sts.setInt(3, min);
/* 953 */             sts.setString(1, a);
/* 954 */             sts.executeUpdate();
/* 955 */             a = this.txtgrade9.getText();
/* 956 */             max = Integer.parseInt(this.txtgrade14.getText());
/* 957 */             min = Integer.parseInt(this.txtgrade26.getText());
/* 958 */             sts = con.prepareStatement("update grades set grade=?,maximum=?,minmum=? where grades.key=10");
/* 959 */             sts.setInt(2, max);
/* 960 */             sts.setInt(3, min);
/* 961 */             sts.setString(1, a);
/* 962 */             sts.executeUpdate();
/* 963 */             a = this.txtgrade10.getText();
/* 964 */             max = Integer.parseInt(this.txtgrade15.getText());
/* 965 */             min = Integer.parseInt(this.txtgrade27.getText());
/* 966 */             sts = con.prepareStatement("update grades set grade=?,maximum=?,minmum=? where grades.key=11");
/* 967 */             sts.setInt(2, max);
/* 968 */             sts.setInt(3, min);
/* 969 */             sts.setString(1, a);
/* 970 */             sts.executeUpdate();
/*     */ 
/* 972 */             a = this.txtgrade11.getText();
/* 973 */             max = Integer.parseInt(this.txtgrade12.getText());
/* 974 */             min = Integer.parseInt(this.txtgrade24.getText());
/* 975 */             sts = con.prepareStatement("update grades set grade=?,maximum=?,minmum=? where grades.key=12");
/* 976 */             sts.setInt(2, max);
/* 977 */             sts.setInt(3, min);
/* 978 */             sts.setString(1, a);
/* 979 */             sts.executeUpdate();
/* 980 */             JOptionPane.showMessageDialog(null, "Update operation successfull");
/*     */           } catch (SQLException ex) {
/* 982 */             Logger.getLogger(gradingsystem.class.getName()).log(Level.SEVERE, null, ex);
/*     */           }
/*     */       }
/*     */       else
/*     */       {
/* 987 */         JOptionPane.showMessageDialog(null, "You have to be logged in as an administrator to perfom this task");
/*     */       }
/*     */     } catch (ClassNotFoundException ex) { Logger.getLogger(gradingsystem.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } catch (SQLException ex) {
/* 991 */       Logger.getLogger(gradingsystem.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void formInternalFrameClosing(InternalFrameEvent evt) {
/* 996 */     this.mf.add();
/* 997 */     dispose();
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.gradingsystem
 * JD-Core Version:    0.6.2
 */