/*     */ package myschool;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import javax.swing.filechooser.FileFilter;
/*     */ 
/*     */ public class ExampleFileFilter extends FileFilter
/*     */ {
/*  44 */   private static String TYPE_UNKNOWN = "Type Unknown";
/*  45 */   private static String HIDDEN_FILE = "Hidden File";
/*     */ 
/*  47 */   private Hashtable filters = null;
/*  48 */   private String description = null;
/*  49 */   private String fullDescription = null;
/*  50 */   private boolean useExtensionsInDescription = true;
/*     */ 
/*     */   public ExampleFileFilter()
/*     */   {
/*  59 */     this.filters = new Hashtable();
/*     */   }
/*     */ 
/*     */   public ExampleFileFilter(String extension)
/*     */   {
/*  69 */     this(extension, null);
/*     */   }
/*     */ 
/*     */   public ExampleFileFilter(String extension, String description)
/*     */   {
/*  82 */     this();
/*  83 */     if (extension != null) addExtension(extension);
/*  84 */     if (description != null) setDescription(description);
/*     */   }
/*     */ 
/*     */   public ExampleFileFilter(String[] filters)
/*     */   {
/*  97 */     this(filters, null);
/*     */   }
/*     */ 
/*     */   public ExampleFileFilter(String[] filters, String description)
/*     */   {
/* 109 */     this();
/* 110 */     for (int i = 0; i < filters.length; i++)
/*     */     {
/* 112 */       addExtension(filters[i]);
/*     */     }
/* 114 */     if (description != null) setDescription(description);
/*     */   }
/*     */ 
/*     */   public boolean accept(File f)
/*     */   {
/* 127 */     if (f != null) {
/* 128 */       if (f.isDirectory()) {
/* 129 */         return true;
/*     */       }
/* 131 */       String extension = getExtension(f);
/* 132 */       if ((extension != null) && (this.filters.get(getExtension(f)) != null)) {
/* 133 */         return true;
/*     */       }
/*     */     }
/* 136 */     return false;
/*     */   }
/*     */ 
/*     */   public String getExtension(File f)
/*     */   {
/* 146 */     if (f != null) {
/* 147 */       String filename = f.getName();
/* 148 */       int i = filename.lastIndexOf(46);
/* 149 */       if ((i > 0) && (i < filename.length() - 1)) {
/* 150 */         return filename.substring(i + 1).toLowerCase();
/*     */       }
/*     */     }
/* 153 */     return null;
/*     */   }
/*     */ 
/*     */   public void addExtension(String extension)
/*     */   {
/* 169 */     if (this.filters == null) {
/* 170 */       this.filters = new Hashtable(5);
/*     */     }
/* 172 */     this.filters.put(extension.toLowerCase(), this);
/* 173 */     this.fullDescription = null;
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 187 */     if (this.fullDescription == null) {
/* 188 */       if ((this.description == null) || (isExtensionListInDescription())) {
/* 189 */         this.fullDescription = (this.description + " (");
/*     */ 
/* 191 */         Enumeration extensions = this.filters.keys();
/* 192 */         if (extensions != null) {
/* 193 */           this.fullDescription = (this.fullDescription + "." + (String)extensions.nextElement());
/* 194 */           while (extensions.hasMoreElements()) {
/* 195 */             this.fullDescription = (this.fullDescription + ", " + (String)extensions.nextElement());
/*     */           }
/*     */         }
/* 198 */         this.fullDescription += ")";
/*     */       } else {
/* 200 */         this.fullDescription = this.description;
/*     */       }
/*     */     }
/* 203 */     return this.fullDescription;
/*     */   }
/*     */ 
/*     */   public void setDescription(String description)
/*     */   {
/* 215 */     this.description = description;
/* 216 */     this.fullDescription = null;
/*     */   }
/*     */ 
/*     */   public void setExtensionListInDescription(boolean b)
/*     */   {
/* 231 */     this.useExtensionsInDescription = b;
/* 232 */     this.fullDescription = null;
/*     */   }
/*     */ 
/*     */   public boolean isExtensionListInDescription()
/*     */   {
/* 247 */     return this.useExtensionsInDescription;
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.ExampleFileFilter
 * JD-Core Version:    0.6.2
 */