/*     */ package myschool;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JProgressBar;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import net.sf.jasperreports.engine.JRException;
/*     */ import net.sf.jasperreports.engine.JasperFillManager;
/*     */ import net.sf.jasperreports.engine.JasperPrint;
/*     */ import net.sf.jasperreports.engine.JasperReport;
/*     */ import net.sf.jasperreports.engine.util.JRLoader;
/*     */ import net.sf.jasperreports.swing.JRViewer;
/*     */ 
/*     */ public class reportings extends JFrame
/*     */ {
/*     */   private static JComboBox btngenm;
/*     */   private static JComboBox btngenm1;
/*     */   private JLabel jLabel3;
/*     */   private JLabel jLabel4;
/*     */   private JLabel jLabel5;
/*     */   private JLabel jLabel6;
/*     */   private JLabel jLabel7;
/*     */   private JLabel jLabel8;
/*     */   private JPanel jPanel3;
/*     */   private JProgressBar jPreport;
/*     */   private JTextField txtadmno;
/*     */   private JTextField txtcls;
/*     */   private JTextField txtexamno;
/*     */   private JTextField txttrm;
/*     */   private static JComboBox txttype;
/*     */   private JTextField txtyear;
/*     */ 
/*     */   public reportings()
/*     */   {
/*  35 */     initComponents();
/*     */   }
/*     */   public void views() {
/*     */     try {
/*  39 */       int ex = Integer.parseInt(this.txtexamno.getText());
/*  40 */       int ad = Integer.parseInt(this.txtadmno.getText());
/*     */       try
/*     */       {
/*  43 */         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*  44 */         Map parameters = new HashMap();
/*  45 */         parameters.put("Admission", Integer.valueOf(ad));
/*  46 */         parameters.put("Examno", Integer.valueOf(ex));
/*  47 */         JasperReport report = (JasperReport)JRLoader.loadObject("C:/Users/Griffin M/Documents/NetBeansProjects/myschool/src/myschool/markshet.jasper");
/*  48 */         JasperPrint jasperPrint = JasperFillManager.fillReport(report, parameters, con);
/*  49 */         JFrame frame = new JFrame("Student Report Card");
/*  50 */         frame.getContentPane().add(new JRViewer(jasperPrint));
/*  51 */         frame.getPreferredSize();
/*  52 */         frame.pack();
/*  53 */         frame.setVisible(true);
/*     */       } catch (SQLException e) {
/*     */       } catch (JRException ed) {
/*     */       }
/*     */     } catch (Exception exr) {
/*  58 */       JOptionPane.showMessageDialog(null, "You must input the examno of the exam and the admno of the student to perform this action");
/*     */     }
/*     */   }
/*     */   public void views2() {
/*     */     try { int ex = Integer.parseInt(this.txtcls.getText());
/*  63 */       int ad = Integer.parseInt(this.txtyear.getText());
/*  64 */       int tr = Integer.parseInt(this.txttrm.getText());
/*  65 */       String type = (String)txttype.getSelectedItem();
/*     */       try
/*     */       {
/*  69 */         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*  70 */         Map parameters = new HashMap();
/*  71 */         parameters.put("Class", Integer.valueOf(ex));
/*  72 */         parameters.put("year", Integer.valueOf(ad));
/*  73 */         parameters.put("Term", Integer.valueOf(tr));
/*  74 */         parameters.put("Type", type);
/*  75 */         JasperReport report = (JasperReport)JRLoader.loadObject("C:/Users/Griffin M/Documents/NetBeansProjects/myschool/src/myschool/markshet_2.jasper");
/*  76 */         JasperPrint jasperPrint = JasperFillManager.fillReport(report, parameters, con);
/*  77 */         JFrame frame = new JFrame("Student Report Card");
/*  78 */         frame.getContentPane().add(new JRViewer(jasperPrint));
/*  79 */         frame.getPreferredSize();
/*  80 */         frame.pack();
/*  81 */         frame.setVisible(true);
/*     */       } catch (SQLException e) {
/*     */       } catch (JRException ed) {
/*     */       }
/*     */     } catch (Exception exr) {
/*  86 */       JOptionPane.showMessageDialog(null, "You must input the Year,Term of the examination and the Class of the students to perform this action");
/*     */     }
/*     */   }
/*     */   public void views3() {
/*     */     try { int ex = Integer.parseInt(this.txtexamno.getText());
/*     */       try
/*     */       {
/*  95 */         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*  96 */         Map parameters = new HashMap();
/*  97 */         parameters.put("Examno", Integer.valueOf(ex));
/*     */ 
/*  99 */         JasperReport report = (JasperReport)JRLoader.loadObject("C:/Users/Griffin M/Documents/NetBeansProjects/myschool/src/myschool/markshet_3.jasper");
/* 100 */         JasperPrint jasperPrint = JasperFillManager.fillReport(report, parameters, con);
/* 101 */         JFrame frame = new JFrame("Student Report Card");
/* 102 */         frame.getContentPane().add(new JRViewer(jasperPrint));
/* 103 */         frame.getPreferredSize();
/* 104 */         frame.pack();
/* 105 */         frame.setVisible(true);
/*     */       } catch (SQLException e) {
/*     */       } catch (JRException ed) {
/*     */       }
/*     */     } catch (Exception exr) {
/* 110 */       JOptionPane.showMessageDialog(null, "You must input the Examno to perform this action");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void views4() {
/*     */     try { int ex = Integer.parseInt(this.txtcls.getText());
/* 116 */       int ad = Integer.parseInt(this.txtyear.getText());
/* 117 */       int tr = Integer.parseInt(this.txttrm.getText());
/* 118 */       String type = (String)txttype.getSelectedItem();
/*     */       try
/*     */       {
/* 123 */         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/* 124 */         Map parameters = new HashMap();
/* 125 */         parameters.put("Examno", Integer.valueOf(ex));
/*     */ 
/* 127 */         JasperReport report = (JasperReport)JRLoader.loadObject("C:/Users/Griffin M/Documents/NetBeansProjects/myschool/src/myschool/markshet_2_2.jasper");
/* 128 */         JasperPrint jasperPrint = JasperFillManager.fillReport(report, parameters, con);
/* 129 */         JFrame frame = new JFrame("Student Report Card");
/* 130 */         frame.getContentPane().add(new JRViewer(jasperPrint));
/* 131 */         frame.getPreferredSize();
/* 132 */         frame.pack();
/* 133 */         frame.setVisible(true);
/*     */       } catch (SQLException e) {
/*     */       } catch (JRException ed) {
/*     */       }
/*     */     } catch (Exception exr) {
/* 138 */       JOptionPane.showMessageDialog(null, "You must input the Year,Term of the examination,Class of the students and the Exam type to perform this action");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/* 146 */     this.jPanel3 = new JPanel();
/* 147 */     this.txtexamno = new JTextField();
/* 148 */     this.jLabel3 = new JLabel();
/* 149 */     this.txtadmno = new JTextField();
/* 150 */     this.jLabel4 = new JLabel();
/* 151 */     this.txtcls = new JTextField();
/* 152 */     this.jLabel5 = new JLabel();
/* 153 */     this.txtyear = new JTextField();
/* 154 */     this.jLabel6 = new JLabel();
/* 155 */     this.jLabel7 = new JLabel();
/* 156 */     this.txttrm = new JTextField();
/* 157 */     this.jLabel8 = new JLabel();
/* 158 */     txttype = new JComboBox();
/* 159 */     btngenm = new JComboBox();
/* 160 */     btngenm1 = new JComboBox();
/* 161 */     this.jPreport = new JProgressBar();
/*     */ 
/* 163 */     setDefaultCloseOperation(3);
/*     */ 
/* 165 */     this.jPanel3.setBorder(BorderFactory.createTitledBorder(null, "Search exam/results", 0, 0, new Font("Traditional Arabic", 0, 18)));
/*     */ 
/* 167 */     this.txtexamno.setFont(new Font("Traditional Arabic", 0, 18));
/*     */ 
/* 169 */     this.jLabel3.setFont(new Font("Traditional Arabic", 0, 18));
/* 170 */     this.jLabel3.setText("Student Admno");
/* 171 */     this.jLabel3.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 173 */     this.txtadmno.setFont(new Font("Traditional Arabic", 0, 18));
/* 174 */     this.txtadmno.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 176 */         reportings.this.txtadmnoActionPerformed(evt);
/*     */       }
/*     */     });
/* 180 */     this.jLabel4.setFont(new Font("Traditional Arabic", 0, 18));
/* 181 */     this.jLabel4.setText("Exam Number");
/* 182 */     this.jLabel4.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 184 */     this.txtcls.setFont(new Font("Traditional Arabic", 0, 18));
/*     */ 
/* 186 */     this.jLabel5.setFont(new Font("Traditional Arabic", 0, 18));
/* 187 */     this.jLabel5.setText("Year");
/* 188 */     this.jLabel5.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 190 */     this.txtyear.setFont(new Font("Traditional Arabic", 0, 18));
/* 191 */     this.txtyear.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 193 */         reportings.this.txtyearActionPerformed(evt);
/*     */       }
/*     */     });
/* 197 */     this.jLabel6.setFont(new Font("Traditional Arabic", 0, 18));
/* 198 */     this.jLabel6.setText("Class");
/* 199 */     this.jLabel6.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 201 */     this.jLabel7.setFont(new Font("Traditional Arabic", 0, 18));
/* 202 */     this.jLabel7.setText("Term");
/* 203 */     this.jLabel7.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 205 */     this.txttrm.setFont(new Font("Traditional Arabic", 0, 18));
/* 206 */     this.txttrm.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 208 */         reportings.this.txttrmActionPerformed(evt);
/*     */       }
/*     */     });
/* 212 */     this.jLabel8.setFont(new Font("Traditional Arabic", 0, 18));
/* 213 */     this.jLabel8.setText("Exam Type");
/* 214 */     this.jLabel8.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 216 */     txttype.setEditable(true);
/* 217 */     txttype.setFont(new Font("Traditional Arabic", 0, 18));
/* 218 */     txttype.setModel(new DefaultComboBoxModel(new String[] { " ", "Opener Exam", "Midterm Exam", "Endterm Exam", " " }));
/* 219 */     txttype.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 221 */         reportings.this.txttypeActionPerformed(evt);
/*     */       }
/*     */     });
/* 225 */     GroupLayout jPanel3Layout = new GroupLayout(this.jPanel3);
/* 226 */     this.jPanel3.setLayout(jPanel3Layout);
/* 227 */     jPanel3Layout.setHorizontalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addContainerGap().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup().addComponent(this.jLabel5, -1, 141, 32767).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.txtyear, -2, 165, -2)).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel6, -1, 141, 32767).addGap(10, 10, 10).addComponent(this.txtcls, -2, 165, -2)).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel4, -1, 141, 32767).addGap(10, 10, 10).addComponent(this.txtexamno, -2, 165, -2)).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel3, -1, 141, 32767).addGap(10, 10, 10).addComponent(this.txtadmno, -2, 165, -2)).addGroup(GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel8, -1, 141, 32767).addComponent(this.jLabel7, GroupLayout.Alignment.TRAILING, -1, 141, 32767)).addGap(10, 10, 10).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(txttype, GroupLayout.Alignment.TRAILING, 0, 0, 32767).addComponent(this.txttrm, GroupLayout.Alignment.TRAILING, -1, 165, 32767)))).addContainerGap()));
/*     */ 
/* 258 */     jPanel3Layout.setVerticalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel4, -1, 29, 32767).addComponent(this.txtexamno, -2, 29, -2)).addGap(18, 18, 18).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel3, -1, -1, 32767).addComponent(this.txtadmno, -2, 29, -2)).addGap(18, 18, 18).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel5, -2, 33, -2).addComponent(this.txtyear, -2, 29, -2)).addGap(18, 18, 18).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel6, -1, 29, 32767).addComponent(this.txtcls, -2, 29, -2)).addGap(14, 14, 14).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel7, -1, -1, 32767).addComponent(this.txttrm, -2, 29, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel8, -1, -1, 32767).addComponent(txttype, -2, -1, -2)).addGap(22, 22, 22)));
/*     */ 
/* 287 */     btngenm.setFont(new Font("Traditional Arabic", 0, 18));
/* 288 */     btngenm.setModel(new DefaultComboBoxModel(new String[] { "Generate Reportcards:", "By Admno", "By Class", " " }));
/* 289 */     btngenm.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 291 */         reportings.this.btngenmActionPerformed(evt);
/*     */       }
/*     */     });
/* 295 */     btngenm1.setFont(new Font("Traditional Arabic", 0, 18));
/* 296 */     btngenm1.setModel(new DefaultComboBoxModel(new String[] { "Generate Marksheets:", "By Class", "By Form", " " }));
/* 297 */     btngenm1.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 299 */         reportings.this.btngenm1ActionPerformed(evt);
/*     */       }
/*     */     });
/* 303 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 304 */     getContentPane().setLayout(layout);
/* 305 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jPanel3, -1, -1, 32767).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(btngenm, GroupLayout.Alignment.TRAILING, 0, -1, 32767).addComponent(btngenm1, -2, -1, -2)).addComponent(this.jPreport, -1, 197, 32767)).addContainerGap()));
/*     */ 
/* 318 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap(57, 32767).addComponent(btngenm1, -2, 41, -2).addGap(39, 39, 39).addComponent(btngenm, -2, 41, -2).addGap(120, 120, 120).addComponent(this.jPreport, -1, 36, 32767)).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jPanel3, -1, -1, 32767)));
/*     */ 
/* 332 */     pack();
/*     */   }
/*     */ 
/*     */   private void txtadmnoActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtyearActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txttrmActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void btngenmActionPerformed(ActionEvent evt)
/*     */   {
/* 349 */     int ind = btngenm.getSelectedIndex();
/*     */ 
/* 367 */     if (ind == 1) {
/* 368 */       views();
/*     */     }
/* 370 */     else if (ind == 2)
/* 371 */       views2();
/*     */   }
/*     */ 
/*     */   private void txttypeActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void btngenm1ActionPerformed(ActionEvent evt)
/*     */   {
/* 381 */     int index = btngenm1.getSelectedIndex();
/* 382 */     if (index == 1) {
/* 383 */       views3();
/*     */     }
/* 385 */     else if (index == 2)
/* 386 */       views4();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 393 */     EventQueue.invokeLater(new Runnable()
/*     */     {
/*     */       public void run() {
/* 396 */         new reportings().setVisible(true);
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.reportings
 * JD-Core Version:    0.6.2
 */