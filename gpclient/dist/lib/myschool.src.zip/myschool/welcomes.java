/*     */ package myschool;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ 
/*     */ public class welcomes extends JInternalFrame
/*     */ {
/*   7 */   login lgg = new login(this);
/*     */   mymain mf;
/*     */   public static JComboBox cmbtodo;
/*     */   private JLabel jLabel3;
/*     */   private JLabel jLabel4;
/*     */   private JLabel jLabel5;
/*     */   private JLabel jLabel6;
/*     */   private JPanel jPanel1;
/*     */   public static JLabel lblwelcome;
/*     */ 
/*     */   public welcomes(mymain fm)
/*     */   {
/*  11 */     initComponents();
/*  12 */     this.mf = fm;
/*  13 */     this.lgg.wel();
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  21 */     this.jPanel1 = new JPanel();
/*  22 */     lblwelcome = new JLabel();
/*  23 */     this.jLabel3 = new JLabel();
/*  24 */     this.jLabel5 = new JLabel();
/*  25 */     this.jLabel6 = new JLabel();
/*  26 */     this.jLabel4 = new JLabel();
/*  27 */     cmbtodo = new JComboBox();
/*     */ 
/*  29 */     setIconifiable(true);
/*  30 */     setMaximizable(true);
/*  31 */     setResizable(true);
/*  32 */     setTitle("Welcome");
/*     */ 
/*  34 */     this.jPanel1.setBackground(new Color(153, 153, 255));
/*  35 */     this.jPanel1.setBorder(BorderFactory.createEtchedBorder());
/*     */ 
/*  37 */     lblwelcome.setFont(new Font("Gill Sans Ultra Bold Condensed", 0, 36));
/*  38 */     lblwelcome.setHorizontalAlignment(0);
/*  39 */     lblwelcome.setText("Welcome ");
/*     */ 
/*  41 */     this.jLabel3.setIcon(new ImageIcon(getClass().getResource("/myschool/resources/house.jpg")));
/*     */ 
/*  43 */     this.jLabel5.setIcon(new ImageIcon("C:\\Users\\Griffin M\\Documents\\Visual Studio 2010\\Projects\\MedicalSystem\\MedicalSystem\\Resources\\Close-2-icon.png"));
/*  44 */     this.jLabel5.setText("jLabel4");
/*     */ 
/*  46 */     this.jLabel6.setIcon(new ImageIcon("C:\\Users\\Griffin M\\Documents\\Visual Studio 2010\\Projects\\MedicalSystem\\MedicalSystem\\Resources\\Male-Face-D2-icon.png"));
/*  47 */     this.jLabel6.setText("jLabel4");
/*     */ 
/*  49 */     this.jLabel4.setFont(new Font("Harlow Solid Italic", 0, 18));
/*  50 */     this.jLabel4.setText("What do you want to do today :");
/*     */ 
/*  52 */     cmbtodo.setFont(new Font("Traditional Arabic", 0, 18));
/*  53 */     cmbtodo.setModel(new DefaultComboBoxModel(new String[] { "", "Admit new students", "Input exam scores", "Search for a record", "Print/Show  Reports", "Add new system user", "Grading system", "Logout" }));
/*  54 */     cmbtodo.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  56 */         welcomes.this.cmbtodoActionPerformed(evt);
/*     */       }
/*     */     });
/*  60 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/*  61 */     this.jPanel1.setLayout(jPanel1Layout);
/*  62 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGap(23, 23, 23).addComponent(this.jLabel3).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGap(84, 84, 84).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel6, 0, 0, 32767).addComponent(this.jLabel5, 0, 0, 32767))).addGroup(jPanel1Layout.createSequentialGroup().addGap(59, 59, 59).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel4, GroupLayout.Alignment.TRAILING, -1, 228, 32767).addComponent(cmbtodo, -2, 228, -2)))).addContainerGap()).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(lblwelcome, -1, 624, 32767).addGap(6, 6, 6)));
/*     */ 
/*  85 */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGap(28, 28, 28).addComponent(lblwelcome).addGap(18, 18, 18).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.jLabel4, -2, 34, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(cmbtodo, -2, -1, -2).addGap(72, 72, 72).addComponent(this.jLabel6, -2, 46, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jLabel5, -2, 40, -2)).addComponent(this.jLabel3, -2, 261, -2)).addContainerGap(34, 32767)));
/*     */ 
/* 104 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 105 */     getContentPane().setLayout(layout);
/* 106 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel1, -2, 640, -2));
/*     */ 
/* 110 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel1, -2, -1, -2));
/*     */ 
/* 115 */     pack();
/*     */   }
/*     */ 
/*     */   private void cmbtodoActionPerformed(ActionEvent evt) {
/* 119 */     int index = cmbtodo.getSelectedIndex();
/* 120 */     if (index == 1) {
/* 121 */       this.mf.reg();
/* 122 */       dispose();
/*     */     }
/* 124 */     else if (index == 2) {
/* 125 */       this.mf.examst();
/* 126 */       dispose();
/*     */     }
/* 128 */     else if (index == 3) {
/* 129 */       this.mf.search();
/* 130 */       dispose();
/*     */     }
/* 132 */     else if (index == 4) {
/* 133 */       this.mf.reportd();
/* 134 */       dispose();
/*     */     }
/* 136 */     else if (index == 5)
/*     */     {
/* 138 */       this.mf.define();
/* 139 */       dispose();
/*     */     }
/* 141 */     else if (index == 6)
/*     */     {
/* 143 */       this.mf.grdsy();
/* 144 */       dispose();
/*     */     }
/* 146 */     else if (index == 7) {
/* 147 */       String[] options = new String[2];
/* 148 */       options[0] = "Yes";
/* 149 */       options[1] = "No";
/*     */ 
/* 151 */       int val = JOptionPane.showOptionDialog(this.rootPane, "Are you sure you want to logout ??", "Logout", 0, 1, this.frameIcon, options, Integer.valueOf(0));
/* 152 */       if (val == 0) {
/* 153 */         dispose();
/*     */       }
/*     */       else
/*     */       {
/* 157 */         dispose();
/* 158 */         this.mf.add();
/*     */       }
/* 160 */       if (cmbtodo.getSelectedItem().toString().contains("Print/Show  Reports"))
/* 161 */         this.mf.reportd();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.welcomes
 * JD-Core Version:    0.6.2
 */