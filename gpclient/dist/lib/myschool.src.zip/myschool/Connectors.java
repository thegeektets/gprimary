/*    */ package myschool;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ 
/*    */ class Connectors
/*    */ {
/*    */   Connection getConnection()
/*    */   {
/* 16 */     throw new UnsupportedOperationException("Not yet implemented");
/*    */   }
/*    */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.Connectors
 * JD-Core Version:    0.6.2
 */