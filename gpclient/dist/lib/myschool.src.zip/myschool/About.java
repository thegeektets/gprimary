/*     */ package myschool;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JLayeredPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.border.SoftBevelBorder;
/*     */ 
/*     */ public class About extends JInternalFrame
/*     */ {
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel2;
/*     */   private JLabel jLabel3;
/*     */   private JLabel jLabel4;
/*     */   private JLayeredPane jLayeredPane1;
/*     */   private JPanel jPanel1;
/*     */   private JPanel jPanel2;
/*     */   private JScrollPane jScrollPane1;
/*     */   private JTextArea jTextArea1;
/*     */ 
/*     */   public About()
/*     */   {
/*  21 */     initComponents();
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  30 */     this.jPanel1 = new JPanel();
/*  31 */     this.jScrollPane1 = new JScrollPane();
/*  32 */     this.jTextArea1 = new JTextArea();
/*  33 */     this.jPanel2 = new JPanel();
/*  34 */     this.jLayeredPane1 = new JLayeredPane();
/*  35 */     this.jLabel3 = new JLabel();
/*  36 */     this.jLabel1 = new JLabel();
/*  37 */     this.jLabel4 = new JLabel();
/*  38 */     this.jLabel2 = new JLabel();
/*     */ 
/*  40 */     setClosable(true);
/*  41 */     setIconifiable(true);
/*  42 */     setMaximizable(true);
/*  43 */     setResizable(true);
/*  44 */     setTitle("About");
/*     */ 
/*  46 */     this.jPanel1.setBackground(new Color(0, 0, 0));
/*  47 */     this.jPanel1.setBorder(BorderFactory.createBevelBorder(1));
/*     */ 
/*  49 */     this.jTextArea1.setBackground(new Color(51, 51, 255));
/*  50 */     this.jTextArea1.setColumns(20);
/*  51 */     this.jTextArea1.setFont(new Font("Traditional Arabic", 0, 18));
/*  52 */     this.jTextArea1.setForeground(new Color(255, 255, 255));
/*  53 */     this.jTextArea1.setRows(5);
/*  54 */     this.jTextArea1.setText("The high school manager is a complete custom built program \nthat enables users to manage students,their parents and their \nexams.It is equipped with fast search features and reporting \ncapabalities.\nFor more information about the program ,\nBetter customization to suite your needs \nContact Me at \n\t:griffinmuteti31@gmail.com\n\t:winmcn@gmail.com\n\t:+254702990800\n\t:+254722637857\nThanks for purchasing :Enjoy using the high school manager \n");
/*  55 */     this.jTextArea1.setBorder(new SoftBevelBorder(0));
/*  56 */     this.jTextArea1.setFocusable(false);
/*  57 */     this.jScrollPane1.setViewportView(this.jTextArea1);
/*     */ 
/*  59 */     this.jPanel2.setBackground(new Color(102, 102, 255));
/*  60 */     this.jPanel2.setBorder(BorderFactory.createBevelBorder(0));
/*     */ 
/*  62 */     this.jLabel3.setIcon(new ImageIcon(getClass().getResource("/myschool/imagesd.jpg")));
/*  63 */     this.jLabel3.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*  64 */     this.jLabel3.setBounds(10, 10, 50, 120);
/*  65 */     this.jLayeredPane1.add(this.jLabel3, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/*  67 */     this.jLabel1.setIcon(new ImageIcon(getClass().getResource("/myschool/14797023-illustration-of-an-asian-schoolboy-carrying-a-backpack.jpg")));
/*  68 */     this.jLabel1.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*  69 */     this.jLabel1.setBounds(150, 0, 100, 170);
/*  70 */     this.jLayeredPane1.add(this.jLabel1, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/*  72 */     this.jLabel4.setFont(new Font("Monotype Corsiva", 0, 14));
/*  73 */     this.jLabel4.setText("The high school manager 2013");
/*  74 */     this.jLabel4.setBounds(100, 170, 150, 14);
/*  75 */     this.jLayeredPane1.add(this.jLabel4, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/*  77 */     this.jLabel2.setIcon(new ImageIcon(getClass().getResource("/myschool/imagesddd.jpg")));
/*  78 */     this.jLabel2.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*  79 */     this.jLabel2.setBounds(50, 30, 120, 110);
/*  80 */     this.jLayeredPane1.add(this.jLabel2, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/*  82 */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/*  83 */     this.jPanel2.setLayout(jPanel2Layout);
/*  84 */     jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap(-1, 32767).addComponent(this.jLayeredPane1, -2, 256, -2)));
/*     */ 
/*  90 */     jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup().addComponent(this.jLayeredPane1, -2, 191, -2).addContainerGap(6, 32767)));
/*     */ 
/*  97 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/*  98 */     this.jPanel1.setLayout(jPanel1Layout);
/*  99 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel2, -2, -1, -2).addComponent(this.jScrollPane1, GroupLayout.Alignment.TRAILING, -1, 495, 32767)).addContainerGap()));
/*     */ 
/* 108 */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(this.jPanel2, -2, 201, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jScrollPane1, -2, 361, -2).addContainerGap(-1, 32767)));
/*     */ 
/* 118 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 119 */     getContentPane().setLayout(layout);
/* 120 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jPanel1, -2, -1, -2).addContainerGap(-1, 32767)));
/*     */ 
/* 127 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jPanel1, -1, -1, 32767)));
/*     */ 
/* 134 */     pack();
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.About
 * JD-Core Version:    0.6.2
 */