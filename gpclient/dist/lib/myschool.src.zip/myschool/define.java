/*     */ package myschool;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ 
/*     */ public class define extends JInternalFrame
/*     */ {
/*     */   mymain mf;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel3;
/*     */   private JLabel lblflatname5;
/*     */   private JLabel lblflatname6;
/*     */   private JLabel lblflatname7;
/*     */   private JTextField txtname;
/*     */   private JTextField txtright;
/*     */   private JTextField txtuser;
/*     */ 
/*     */   public define(mymain aThis)
/*     */   {
/*  19 */     initComponents();
/*  20 */     this.mf = aThis;
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  34 */     this.txtname = new JTextField();
/*  35 */     this.jLabel3 = new JLabel();
/*  36 */     this.lblflatname5 = new JLabel();
/*  37 */     this.jLabel1 = new JLabel();
/*  38 */     this.txtuser = new JTextField();
/*  39 */     this.lblflatname6 = new JLabel();
/*  40 */     this.txtright = new JTextField();
/*  41 */     this.lblflatname7 = new JLabel();
/*     */ 
/*  43 */     this.txtname.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  45 */         define.this.txtnameActionPerformed(evt);
/*     */       }
/*     */     });
/*  49 */     this.jLabel3.setFont(new Font("Traditional Arabic", 1, 18));
/*  50 */     this.jLabel3.setIcon(new ImageIcon(getClass().getResource("/myschool/resources/Check-icon.png")));
/*  51 */     this.jLabel3.setText("Okay");
/*  52 */     this.jLabel3.setBorder(BorderFactory.createBevelBorder(0, Color.green, null, Color.green, Color.green));
/*  53 */     this.jLabel3.addMouseListener(new MouseAdapter() {
/*     */       public void mouseClicked(MouseEvent evt) {
/*  55 */         define.this.jLabel3MouseClicked(evt);
/*     */       }
/*     */     });
/*  59 */     this.lblflatname5.setFont(new Font("Traditional Arabic", 0, 18));
/*  60 */     this.lblflatname5.setText("User Name");
/*  61 */     this.lblflatname5.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/*  63 */     this.jLabel1.setFont(new Font("Traditional Arabic", 1, 18));
/*  64 */     this.jLabel1.setIcon(new ImageIcon(getClass().getResource("/myschool/resources/Close-2-icon.png")));
/*  65 */     this.jLabel1.setText("Exit");
/*  66 */     this.jLabel1.setBorder(BorderFactory.createBevelBorder(0, Color.darkGray, null, Color.darkGray, new Color(51, 51, 51)));
/*  67 */     this.jLabel1.addMouseListener(new MouseAdapter() {
/*     */       public void mouseClicked(MouseEvent evt) {
/*  69 */         define.this.jLabel1MouseClicked(evt);
/*     */       }
/*     */     });
/*  73 */     this.txtuser.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  75 */         define.this.txtuserActionPerformed(evt);
/*     */       }
/*     */     });
/*  79 */     this.lblflatname6.setFont(new Font("Traditional Arabic", 0, 18));
/*  80 */     this.lblflatname6.setText("Full Name");
/*  81 */     this.lblflatname6.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/*  83 */     this.txtright.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  85 */         define.this.txtrightActionPerformed(evt);
/*     */       }
/*     */     });
/*  89 */     this.lblflatname7.setFont(new Font("Traditional Arabic", 0, 18));
/*  90 */     this.lblflatname7.setText("Privilidges");
/*  91 */     this.lblflatname7.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/*  93 */     GroupLayout layout = new GroupLayout(getContentPane());
/*  94 */     getContentPane().setLayout(layout);
/*  95 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.lblflatname7, -2, 122, -2).addComponent(this.lblflatname5, -2, 122, -2).addComponent(this.lblflatname6, -2, 122, -2)).addGap(55, 55, 55).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.txtuser, -2, 228, -2).addComponent(this.txtright, -2, 228, -2).addComponent(this.txtname, -2, 228, -2)).addGap(117, 117, 117)).addGroup(layout.createSequentialGroup().addGap(56, 56, 56).addComponent(this.jLabel3, -2, 122, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 186, 32767).addComponent(this.jLabel1, -2, 113, -2).addGap(55, 55, 55)));
/*     */ 
/* 116 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.lblflatname5, -2, 22, -2).addComponent(this.txtuser, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.lblflatname6, -2, 22, -2).addComponent(this.txtname, -2, -1, -2)).addGap(18, 18, 18).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.lblflatname7, -2, 22, -2).addComponent(this.txtright, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel3, -2, 65, -2).addComponent(this.jLabel1, -2, 65, -2)).addContainerGap(15, 32767)));
/*     */ 
/* 138 */     pack();
/*     */   }
/*     */ 
/*     */   private void txtnameActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void jLabel3MouseClicked(MouseEvent evt) {
/*     */     try {
/* 147 */       String name = this.txtname.getText();
/* 148 */       String cred = this.txtright.getText();
/* 149 */       String user = this.txtuser.getText();
/* 150 */       String dflt = "1234";
/* 151 */       Class.forName("com.mysql.jdbc.Driver");
/* 152 */       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/* 153 */       PreparedStatement s = con.prepareStatement("INSERT INTO user values(?,?,?,?,?)");
/* 154 */       s.setString(1, user);
/* 155 */       s.setString(2, dflt);
/* 156 */       s.setString(3, cred);
/* 157 */       s.setString(4, name);
/* 158 */       s.setString(5, null);
/*     */ 
/* 160 */       s.executeUpdate();
/* 161 */       JOptionPane.showMessageDialog(null, user + " Has been registered as a new user and assinged a default password 1234");
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 164 */       Logger.getLogger(define.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } catch (SQLException ex) {
/* 166 */       JOptionPane.showMessageDialog(null, "Username already exists please try again");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void jLabel1MouseClicked(MouseEvent evt)
/*     */   {
/* 176 */     this.mf.add();
/* 177 */     dispose();
/*     */   }
/*     */ 
/*     */   private void txtuserActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtrightActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.define
 * JD-Core Version:    0.6.2
 */