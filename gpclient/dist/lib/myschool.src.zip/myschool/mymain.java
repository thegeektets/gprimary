/*     */ package myschool;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.Font;
/*     */ import java.awt.Image;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JDesktopPane;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JLayeredPane;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JProgressBar;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.KeyStroke;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.UIManager.LookAndFeelInfo;
/*     */ import javax.swing.UnsupportedLookAndFeelException;
/*     */ 
/*     */ public final class mymain extends JFrame
/*     */ {
/*     */   SchoolApp n;
/*     */   login l;
/*  27 */   login lg = new login(this);
/*  28 */   welcomes th = new welcomes(this);
/*  29 */   students st = new students(this);
/*  30 */   parent pr = new parent(this);
/*  31 */   examstud es = new examstud(this);
/*  32 */   results rst = new results(this);
/*  33 */   define df = new define(this);
/*  34 */   newuser nw = new newuser(this);
/*  35 */   report rp = new report(this);
/*  36 */   gradingsystem p = new gradingsystem(this);
/*  37 */   public static int thrown = 0;
/*     */ 
/*  39 */   String crd = login.cred;
/*     */   private JMenuItem aboutMenuItem;
/*     */   private JMenuItem adminMenuItem;
/*     */   private JDesktopPane desktopPane;
/*     */   private JMenuItem exitMenuItem;
/*     */   private JMenu fileMenu;
/*     */   private JMenu helpMenu;
/*     */   private JDialog jDialog1;
/*     */   private JPanel jPanel1;
/*     */   private JPanel jPanel2;
/*     */   private JProgressBar jProgressBar1;
/*     */   private JScrollPane jScrollPane1;
/*     */   private JTextArea jTextArea1;
/*     */   private static JLabel lblhead;
/*     */   private static JLabel lbllogo;
/*     */   public static JLabel lblstatus;
/*     */   public static JDesktopPane mainpane;
/*     */   private JMenuBar menuBar;
/*     */   private JMenuItem newMenuItem;
/*     */   private JMenuItem normalMenuItem;
/*     */ 
/*     */   public mymain()
/*     */   {
/*  19 */     setLocation(150, 0);
/*  20 */     initComponents();
/*  21 */     pip();
/*     */   }
/*     */ 
/*     */   mymain(SchoolApp aThis)
/*     */   {
/*  43 */     this.n = aThis;
/*  44 */     initComponents();
/*  45 */     pip();
/*     */   }
/*     */ 
/*     */   public void login() {
/*  49 */     login my = new login(this);
/*  50 */     mainpane.add(my);
/*  51 */     my.setLocation(360, 190);
/*  52 */     my.setVisible(true);
/*     */   }
/*     */ 
/*     */   public static void script()
/*     */   {
/*  57 */     boolean verbose = false;
/*     */     try {
/*  59 */       String host = "jdbc:mysql://localhost:3306/myschool";
/*  60 */       String user = "root";
/*  61 */       String password = "muteti";
/*  62 */       Connection con = DriverManager.getConnection(host, user, password);
/*     */       try {
/*  64 */         String[] cmd = { "mysql", "--user=" + user, "--password=" + password, "-e", "\"source C:/Users/Griffin M/Desktop/High school Manager/markquery.sql\"" };
/*     */ 
/*  71 */         System.err.println(cmd[0] + " " + cmd[1] + " " + cmd[2] + " " + cmd[3] + " " + cmd[4] + " ");
/*     */ 
/*  74 */         Process proc = Runtime.getRuntime().exec(cmd);
/*  75 */         if (verbose) {
/*  76 */           InputStream inputstream = proc.getInputStream();
/*  77 */           InputStreamReader inputstreamreader = new InputStreamReader(inputstream);
/*  78 */           BufferedReader bufferedreader = new BufferedReader(inputstreamreader);
/*     */           String line;
/*  82 */           while ((line = bufferedreader.readLine()) != null) {
/*  83 */             System.out.println(line);
/*     */           }
/*     */ 
/*     */           try
/*     */           {
/*  88 */             if (proc.waitFor() != 0) {
/*  89 */               System.err.println("exit value = " + proc.exitValue());
/*     */             }
/*     */           }
/*     */           catch (InterruptedException e)
/*     */           {
/*  94 */             System.err.println(e);
/*     */           }
/*     */         }
/*     */       } catch (Exception e) {
/*  98 */         e.printStackTrace();
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (SQLException ex)
/*     */     {
/* 107 */       Logger.getLogger(mymain.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void pip()
/*     */   {
/*     */     try {
/* 114 */       String host = "jdbc:mysql://localhost:3306/myschool";
/* 115 */       String user = "root";
/* 116 */       String password = "muteti";
/* 117 */       Connection con = DriverManager.getConnection(host, user, password);
/* 118 */       Statement st = con.createStatement();
/* 119 */       ResultSet rs = st.executeQuery("Select * from school");
/* 120 */       rs.next();
/* 121 */       String name = rs.getString("sname");
/* 122 */       lblhead.setText(name);
/*     */ 
/* 124 */       ImageIcon spic = new ImageIcon(rs.getString("scpic"));
/* 125 */       Image sp = spic.getImage();
/* 126 */       Image resizedImage = sp.getScaledInstance(lbllogo.getWidth(), lbllogo.getHeight(), 0);
/* 127 */       ImageIcon rim = new ImageIcon(resizedImage);
/* 128 */       lbllogo.setIcon(rim);
/*     */ 
/* 130 */       mainpane.setToolTipText("Welcome please login to proceed");
/*     */     }
/*     */     catch (SQLException ex) {
/*     */     }
/*     */   }
/*     */ 
/*     */   public void add() {
/* 137 */     welcomes wm = new welcomes(this);
/* 138 */     mainpane.add(wm);
/* 139 */     wm.setLocation(290, 190);
/* 140 */     wm.setVisible(true);
/* 141 */     mainpane.setToolTipText(null);
/*     */   }
/*     */ 
/*     */   public void reg()
/*     */   {
/* 146 */     welcomes w = new welcomes(this);
/* 147 */     students wm = new students(this);
/* 148 */     mainpane.add(wm);
/* 149 */     w.dispose();
/* 150 */     wm.setLocation(150, 20);
/* 151 */     wm.setVisible(true);
/*     */   }
/*     */ 
/*     */   public void prnt() {
/* 155 */     students w = new students(this);
/* 156 */     parent wm = new parent(this);
/* 157 */     mainpane.add(wm);
/* 158 */     w.dispose();
/* 159 */     wm.setLocation(150, 20);
/* 160 */     wm.setVisible(true);
/*     */   }
/*     */ 
/*     */   public void examst() {
/* 164 */     welcomes w = new welcomes(this);
/* 165 */     examstud ex = new examstud(this);
/* 166 */     mainpane.add(ex);
/* 167 */     w.dispose();
/* 168 */     ex.setLocation(20, 1);
/* 169 */     ex.setVisible(true);
/*     */   }
/*     */ 
/*     */   public void search() {
/* 173 */     welcomes w = new welcomes(this);
/* 174 */     results ex = new results(this);
/* 175 */     mainpane.add(ex);
/* 176 */     w.dispose();
/* 177 */     ex.setLocation(150, 20);
/* 178 */     ex.setVisible(true);
/*     */   }
/*     */   public void define() {
/* 181 */     welcomes w = new welcomes(this);
/* 182 */     this.crd = lblstatus.getText();
/* 183 */     int as = this.crd.lastIndexOf("as");
/* 184 */     as += 3;
/* 185 */     String scred = this.crd.substring(as);
/* 186 */     if (scred.contains("Admin")) {
/* 187 */       define my = new define(this);
/* 188 */       mainpane.add(my);
/* 189 */       my.setLocation(360, 190);
/* 190 */       my.setVisible(true);
/* 191 */       w.dispose();
/*     */     }
/*     */     else {
/* 194 */       System.out.println(scred);
/* 195 */       JOptionPane.showMessageDialog(null, "You must be logged in as an administrator to perform this task");
/* 196 */       welcomes wr = new welcomes(this);
/* 197 */       add();
/*     */     }
/*     */   }
/*     */ 
/* 201 */   public void reportd() { welcomes er = new welcomes(this);
/* 202 */     report re = new report(this);
/* 203 */     mainpane.add(re);
/* 204 */     er.dispose();
/* 205 */     re.setLocation(150, 20);
/* 206 */     re.setVisible(true);
/* 207 */     System.out.println("Running"); }
/*     */ 
/*     */   public void grdsy() {
/* 210 */     welcomes er = new welcomes(this);
/* 211 */     gradingsystem gr = new gradingsystem(this);
/* 212 */     mainpane.add(gr);
/* 213 */     er.dispose();
/* 214 */     gr.setLocation(360, 190);
/* 215 */     gr.setVisible(true);
/*     */   }
/*     */ 
/*     */   public static void pop()
/*     */   {
/*     */     try {
/* 221 */       String host = "jdbc:mysql://localhost:3306/myschool";
/* 222 */       String user = "root";
/* 223 */       String password = "muteti";
/* 224 */       Connection con = DriverManager.getConnection(host, user, password);
/* 225 */       Statement st = con.createStatement();
/* 226 */       ResultSet rs = st.executeQuery("Select * from school");
/* 227 */       rs.next();
/* 228 */       name = rs.getString("sname");
/*     */     }
/*     */     catch (SQLException ex)
/*     */     {
/*     */       String name;
/* 232 */       thrown = 1;
/* 233 */       System.out.println("running for the first time");
/* 234 */       script();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/* 243 */     this.desktopPane = new JDesktopPane();
/* 244 */     this.jDialog1 = new JDialog();
/* 245 */     mainpane = new JDesktopPane();
/* 246 */     this.jScrollPane1 = new JScrollPane();
/* 247 */     this.jTextArea1 = new JTextArea();
/* 248 */     this.jPanel1 = new JPanel();
/* 249 */     lblhead = new JLabel();
/* 250 */     this.jPanel2 = new JPanel();
/* 251 */     lbllogo = new JLabel();
/* 252 */     this.jProgressBar1 = new JProgressBar();
/* 253 */     lblstatus = new JLabel();
/* 254 */     this.menuBar = new JMenuBar();
/* 255 */     this.fileMenu = new JMenu();
/* 256 */     this.adminMenuItem = new JMenuItem();
/* 257 */     this.normalMenuItem = new JMenuItem();
/* 258 */     this.newMenuItem = new JMenuItem();
/* 259 */     this.exitMenuItem = new JMenuItem();
/* 260 */     this.helpMenu = new JMenu();
/* 261 */     this.aboutMenuItem = new JMenuItem();
/*     */ 
/* 263 */     GroupLayout jDialog1Layout = new GroupLayout(this.jDialog1.getContentPane());
/* 264 */     this.jDialog1.getContentPane().setLayout(jDialog1Layout);
/* 265 */     jDialog1Layout.setHorizontalGroup(jDialog1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 400, 32767));
/*     */ 
/* 269 */     jDialog1Layout.setVerticalGroup(jDialog1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 300, 32767));
/*     */ 
/* 274 */     setDefaultCloseOperation(3);
/* 275 */     setTitle("Highschoolmanager");
/* 276 */     setBackground(new Color(0, 0, 0));
/* 277 */     setResizable(false);
/*     */ 
/* 279 */     mainpane.setBackground(new Color(153, 153, 255));
/* 280 */     mainpane.setBorder(BorderFactory.createTitledBorder(null, "Welcome to the Highskul Manager", 0, 0, new Font("Traditional Arabic", 0, 18)));
/* 281 */     mainpane.setToolTipText("");
/*     */ 
/* 283 */     this.jScrollPane1.setBackground(new Color(153, 153, 255));
/* 284 */     this.jScrollPane1.setViewportBorder(BorderFactory.createEtchedBorder(new Color(0, 0, 0), new Color(51, 51, 51)));
/*     */ 
/* 286 */     this.jTextArea1.setBackground(new Color(153, 153, 255));
/* 287 */     this.jTextArea1.setColumns(20);
/* 288 */     this.jTextArea1.setFont(new Font("Traditional Arabic", 2, 14));
/* 289 */     this.jTextArea1.setRows(5);
/* 290 */     this.jTextArea1.setText("Programmed and Designed by:\nGriffin M Ngei");
/* 291 */     this.jScrollPane1.setViewportView(this.jTextArea1);
/*     */ 
/* 293 */     this.jScrollPane1.setBounds(880, 610, 250, 130);
/* 294 */     mainpane.add(this.jScrollPane1, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/* 296 */     this.jPanel1.setBorder(BorderFactory.createEtchedBorder(null, new Color(51, 51, 51)));
/*     */ 
/* 298 */     lblhead.setFont(new Font("Snap ITC", 1, 36));
/* 299 */     lblhead.setHorizontalTextPosition(0);
/*     */ 
/* 301 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/* 302 */     this.jPanel1.setLayout(jPanel1Layout);
/* 303 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGap(37, 37, 37).addComponent(lblhead, -1, 869, 32767).addContainerGap()));
/*     */ 
/* 310 */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(lblhead, -1, 64, 32767).addContainerGap()));
/*     */ 
/* 318 */     this.jPanel1.setBounds(140, 30, 920, 90);
/* 319 */     mainpane.add(this.jPanel1, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/* 321 */     this.jPanel2.setBorder(BorderFactory.createEtchedBorder(null, new Color(51, 51, 51)));
/*     */ 
/* 323 */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/* 324 */     this.jPanel2.setLayout(jPanel2Layout);
/* 325 */     jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup().addContainerGap(89, 32767).addComponent(lbllogo, -2, 416, -2).addGap(71, 71, 71)));
/*     */ 
/* 332 */     jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup().addContainerGap(39, 32767).addComponent(lbllogo, -2, 347, -2)));
/*     */ 
/* 339 */     this.jPanel2.setBounds(290, 190, 580, 390);
/* 340 */     mainpane.add(this.jPanel2, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/* 342 */     lblstatus.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 344 */     this.menuBar.setInheritsPopupMenu(true);
/*     */ 
/* 346 */     this.fileMenu.setMnemonic('L');
/* 347 */     this.fileMenu.setText("Login");
/* 348 */     this.fileMenu.setFont(new Font("Traditional Arabic", 0, 18));
/*     */ 
/* 350 */     this.adminMenuItem.setAccelerator(KeyStroke.getKeyStroke(65, 2));
/* 351 */     this.adminMenuItem.setIcon(new ImageIcon(getClass().getResource("/myschool/resources/M.png")));
/* 352 */     this.adminMenuItem.setMnemonic('o');
/* 353 */     this.adminMenuItem.setText("Administrator");
/* 354 */     this.adminMenuItem.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 356 */         mymain.this.adminMenuItemActionPerformed(evt);
/*     */       }
/*     */     });
/* 359 */     this.fileMenu.add(this.adminMenuItem);
/*     */ 
/* 361 */     this.normalMenuItem.setAccelerator(KeyStroke.getKeyStroke(85, 2));
/* 362 */     this.normalMenuItem.setIcon(new ImageIcon(getClass().getResource("/myschool/resources/F.png")));
/* 363 */     this.normalMenuItem.setMnemonic('s');
/* 364 */     this.normalMenuItem.setText("Normal Users");
/* 365 */     this.normalMenuItem.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 367 */         mymain.this.normalMenuItemActionPerformed(evt);
/*     */       }
/*     */     });
/* 370 */     this.fileMenu.add(this.normalMenuItem);
/*     */ 
/* 372 */     this.newMenuItem.setAccelerator(KeyStroke.getKeyStroke(78, 2));
/* 373 */     this.newMenuItem.setIcon(new ImageIcon(getClass().getResource("/myschool/resources/F.png")));
/* 374 */     this.newMenuItem.setMnemonic('a');
/* 375 */     this.newMenuItem.setText("New Users");
/* 376 */     this.newMenuItem.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 378 */         mymain.this.newMenuItemActionPerformed(evt);
/*     */       }
/*     */     });
/* 381 */     this.fileMenu.add(this.newMenuItem);
/*     */ 
/* 383 */     this.exitMenuItem.setAccelerator(KeyStroke.getKeyStroke(88, 2));
/* 384 */     this.exitMenuItem.setIcon(new ImageIcon(getClass().getResource("/myschool/resources/Close-2-icon.png")));
/* 385 */     this.exitMenuItem.setMnemonic('x');
/* 386 */     this.exitMenuItem.setText("Exit");
/* 387 */     this.exitMenuItem.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 389 */         mymain.this.exitMenuItemActionPerformed(evt);
/*     */       }
/*     */     });
/* 392 */     this.fileMenu.add(this.exitMenuItem);
/*     */ 
/* 394 */     this.menuBar.add(this.fileMenu);
/*     */ 
/* 396 */     this.helpMenu.setMnemonic('h');
/* 397 */     this.helpMenu.setText("About");
/* 398 */     this.helpMenu.setFont(new Font("Traditional Arabic", 0, 18));
/* 399 */     this.helpMenu.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 401 */         mymain.this.helpMenuActionPerformed(evt);
/*     */       }
/*     */     });
/* 405 */     this.aboutMenuItem.setAccelerator(KeyStroke.getKeyStroke(66, 2));
/* 406 */     this.aboutMenuItem.setIcon(new ImageIcon(getClass().getResource("/myschool/resources/arrow-down.png")));
/* 407 */     this.aboutMenuItem.setMnemonic('a');
/* 408 */     this.aboutMenuItem.setText("About");
/* 409 */     this.aboutMenuItem.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 411 */         mymain.this.aboutMenuItemActionPerformed(evt);
/*     */       }
/*     */     });
/* 414 */     this.helpMenu.add(this.aboutMenuItem);
/*     */ 
/* 416 */     this.menuBar.add(this.helpMenu);
/*     */ 
/* 418 */     setJMenuBar(this.menuBar);
/*     */ 
/* 420 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 421 */     getContentPane().setLayout(layout);
/* 422 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(lblstatus, -2, 542, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jProgressBar1, -1, 594, 32767)).addComponent(mainpane, -1, 1150, 32767));
/*     */ 
/* 431 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(mainpane, -2, 760, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(lblstatus, -2, 20, -2).addComponent(this.jProgressBar1, -2, 30, -2))));
/*     */ 
/* 441 */     pack();
/*     */   }
/*     */ 
/*     */   private void normalMenuItemActionPerformed(ActionEvent evt) {
/* 445 */     login my = new login(this);
/* 446 */     mainpane.add(my);
/* 447 */     my.setLocation(360, 190);
/* 448 */     my.setVisible(true);
/*     */   }
/*     */ 
/*     */   private void exitMenuItemActionPerformed(ActionEvent evt)
/*     */   {
/* 454 */     System.exit(0);
/*     */   }
/*     */ 
/*     */   private void adminMenuItemActionPerformed(ActionEvent evt) {
/* 458 */     login my = new login(this);
/* 459 */     mainpane.add(my);
/* 460 */     my.setLocation(360, 190);
/* 461 */     my.setVisible(true);
/*     */   }
/*     */ 
/*     */   private void newMenuItemActionPerformed(ActionEvent evt)
/*     */   {
/* 466 */     newuser my = new newuser(this);
/* 467 */     mainpane.add(my);
/* 468 */     my.setLocation(360, 190);
/* 469 */     my.setVisible(true);
/*     */   }
/*     */ 
/*     */   private void aboutMenuItemActionPerformed(ActionEvent evt) {
/* 473 */     About b = new About();
/* 474 */     mainpane.add(b);
/* 475 */     b.setLocation(360, 100);
/* 476 */     b.setVisible(true);
/*     */   }
/*     */ 
/*     */   private void helpMenuActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/* 488 */       for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
/* 489 */         if ("Nimbus".equals(info.getName())) {
/* 490 */           UIManager.setLookAndFeel(info.getClassName());
/* 491 */           break;
/*     */         }
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 495 */       Logger.getLogger(mymain.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } catch (InstantiationException ex) {
/* 497 */       Logger.getLogger(mymain.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } catch (IllegalAccessException ex) {
/* 499 */       Logger.getLogger(mymain.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } catch (UnsupportedLookAndFeelException ex) {
/* 501 */       Logger.getLogger(mymain.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/* 503 */     pop();
/* 504 */     if (thrown == 1) {
/* 505 */       System.out.println("running for the first time");
/* 506 */       EventQueue.invokeLater(new Runnable()
/*     */       {
/*     */         public void run() {
/* 509 */           new frunning().setVisible(true);
/*     */         } } );
/*     */     }
/*     */     else {
/* 513 */       EventQueue.invokeLater(new Runnable()
/*     */       {
/*     */         public void run() {
/* 516 */           new mymain().setVisible(true);
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.mymain
 * JD-Core Version:    0.6.2
 */