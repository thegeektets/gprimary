/*     */ package myschool;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.Font;
/*     */ import java.awt.Image;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JLayeredPane;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPasswordField;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.UIManager.LookAndFeelInfo;
/*     */ import javax.swing.UnsupportedLookAndFeelException;
/*     */ import javax.swing.border.SoftBevelBorder;
/*     */ 
/*     */ public class rrunning extends JFrame
/*     */ {
/*     */   public String path;
/*     */   private JButton jButton2;
/*     */   private JButton jButton3;
/*     */   private JButton jButton4;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel10;
/*     */   private JLabel jLabel11;
/*     */   private JLabel jLabel12;
/*     */   private JLabel jLabel13;
/*     */   private JLabel jLabel14;
/*     */   private JLabel jLabel15;
/*     */   private JLabel jLabel2;
/*     */   private JLabel jLabel3;
/*     */   private JLabel jLabel4;
/*     */   private JLabel jLabel5;
/*     */   private JLabel jLabel6;
/*     */   private JLabel jLabel7;
/*     */   private JLabel jLabel8;
/*     */   private JLabel jLabel9;
/*     */   private JLayeredPane jLayeredPane1;
/*     */   private JPanel jPanel1;
/*     */   private JPanel jPanel2;
/*     */   private JPanel jPanel3;
/*     */   private JPanel jPanel4;
/*     */   private JLabel lblspic;
/*     */   private JTextField txtaddress;
/*     */   private JPasswordField txtcpass;
/*     */   private JTextField txtcred;
/*     */   private JTextField txtfname;
/*     */   private JTextField txtlocation;
/*     */   private JTextField txtphint;
/*     */   private JTextField txtskul;
/*     */   private JPasswordField txtupass;
/*     */   private JTextField txtuser;
/*     */ 
/*     */   public rrunning()
/*     */   {
/*  20 */     initComponents();
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  27 */     this.jPanel2 = new JPanel();
/*  28 */     this.jLayeredPane1 = new JLayeredPane();
/*  29 */     this.jLabel3 = new JLabel();
/*  30 */     this.jLabel1 = new JLabel();
/*  31 */     this.jLabel4 = new JLabel();
/*  32 */     this.jLabel2 = new JLabel();
/*  33 */     this.jPanel1 = new JPanel();
/*  34 */     this.jPanel3 = new JPanel();
/*  35 */     this.jLabel6 = new JLabel();
/*  36 */     this.jLabel7 = new JLabel();
/*  37 */     this.jLabel8 = new JLabel();
/*  38 */     this.jLabel9 = new JLabel();
/*  39 */     this.txtskul = new JTextField();
/*  40 */     this.txtlocation = new JTextField();
/*  41 */     this.txtaddress = new JTextField();
/*  42 */     this.lblspic = new JLabel();
/*  43 */     this.jButton4 = new JButton();
/*  44 */     this.jPanel4 = new JPanel();
/*  45 */     this.jLabel10 = new JLabel();
/*  46 */     this.jLabel11 = new JLabel();
/*  47 */     this.jLabel12 = new JLabel();
/*  48 */     this.jLabel13 = new JLabel();
/*  49 */     this.txtfname = new JTextField();
/*  50 */     this.txtcred = new JTextField();
/*  51 */     this.txtuser = new JTextField();
/*  52 */     this.jLabel14 = new JLabel();
/*  53 */     this.jLabel15 = new JLabel();
/*  54 */     this.txtcpass = new JPasswordField();
/*  55 */     this.txtupass = new JPasswordField();
/*  56 */     this.txtphint = new JTextField();
/*  57 */     this.jLabel5 = new JLabel();
/*  58 */     this.jButton2 = new JButton();
/*  59 */     this.jButton3 = new JButton();
/*     */ 
/*  61 */     setDefaultCloseOperation(3);
/*  62 */     setTitle("Running for the first time");
/*  63 */     setAlwaysOnTop(true);
/*  64 */     setBackground(new Color(204, 204, 204));
/*     */ 
/*  66 */     this.jPanel2.setBackground(new Color(102, 102, 255));
/*  67 */     this.jPanel2.setBorder(BorderFactory.createBevelBorder(0));
/*     */ 
/*  69 */     this.jLabel3.setIcon(new ImageIcon(getClass().getResource("/myschool/imagesd.jpg")));
/*  70 */     this.jLabel3.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*  71 */     this.jLabel3.setBounds(10, 10, 50, 120);
/*  72 */     this.jLayeredPane1.add(this.jLabel3, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/*  74 */     this.jLabel1.setIcon(new ImageIcon(getClass().getResource("/myschool/14797023-illustration-of-an-asian-schoolboy-carrying-a-backpack.jpg")));
/*  75 */     this.jLabel1.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*  76 */     this.jLabel1.setBounds(150, 0, 100, 170);
/*  77 */     this.jLayeredPane1.add(this.jLabel1, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/*  79 */     this.jLabel4.setFont(new Font("Monotype Corsiva", 0, 14));
/*  80 */     this.jLabel4.setText("The high school manager 2013");
/*  81 */     this.jLabel4.setBounds(100, 170, 150, 14);
/*  82 */     this.jLayeredPane1.add(this.jLabel4, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/*  84 */     this.jLabel2.setIcon(new ImageIcon(getClass().getResource("/myschool/imagesddd.jpg")));
/*  85 */     this.jLabel2.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*  86 */     this.jLabel2.setBounds(50, 30, 120, 110);
/*  87 */     this.jLayeredPane1.add(this.jLabel2, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/*  89 */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/*  90 */     this.jPanel2.setLayout(jPanel2Layout);
/*  91 */     jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap(-1, 32767).addComponent(this.jLayeredPane1, -2, 256, -2)));
/*     */ 
/*  97 */     jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup().addComponent(this.jLayeredPane1, -2, 191, -2).addContainerGap(-1, 32767)));
/*     */ 
/* 104 */     this.jPanel1.setBackground(new Color(51, 51, 51));
/* 105 */     this.jPanel1.setBorder(BorderFactory.createEtchedBorder(0));
/*     */ 
/* 107 */     this.jPanel3.setBackground(new Color(102, 102, 255));
/* 108 */     this.jPanel3.setBorder(new SoftBevelBorder(0, new Color(102, 102, 102), Color.blue, null, null));
/*     */ 
/* 110 */     this.jLabel6.setFont(new Font("Traditional Arabic", 0, 18));
/* 111 */     this.jLabel6.setText("School Location");
/* 112 */     this.jLabel6.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 114 */     this.jLabel7.setFont(new Font("Traditional Arabic", 0, 18));
/* 115 */     this.jLabel7.setText("School Name");
/* 116 */     this.jLabel7.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 118 */     this.jLabel8.setFont(new Font("Traditional Arabic", 0, 18));
/* 119 */     this.jLabel8.setText("School Address");
/* 120 */     this.jLabel8.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 122 */     this.jLabel9.setFont(new Font("Traditional Arabic", 0, 18));
/* 123 */     this.jLabel9.setText("School Logo");
/* 124 */     this.jLabel9.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 126 */     this.txtskul.setFont(new Font("Traditional Arabic", 0, 18));
/* 127 */     this.txtskul.setBorder(null);
/*     */ 
/* 129 */     this.txtlocation.setFont(new Font("Traditional Arabic", 0, 18));
/* 130 */     this.txtlocation.setBorder(null);
/* 131 */     this.txtlocation.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 133 */         rrunning.this.txtlocationActionPerformed(evt);
/*     */       }
/*     */     });
/* 137 */     this.txtaddress.setFont(new Font("Traditional Arabic", 0, 18));
/* 138 */     this.txtaddress.setBorder(null);
/*     */ 
/* 140 */     this.lblspic.setBackground(new Color(102, 102, 102));
/* 141 */     this.lblspic.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 143 */     this.jButton4.setFont(new Font("Traditional Arabic", 0, 14));
/* 144 */     this.jButton4.setIcon(new ImageIcon(getClass().getResource("/myschool/navigate-down-icon.png")));
/* 145 */     this.jButton4.setText("Select logo");
/* 146 */     this.jButton4.setHorizontalTextPosition(0);
/* 147 */     this.jButton4.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 149 */         rrunning.this.jButton4ActionPerformed(evt);
/*     */       }
/*     */     });
/* 153 */     GroupLayout jPanel3Layout = new GroupLayout(this.jPanel3);
/* 154 */     this.jPanel3.setLayout(jPanel3Layout);
/* 155 */     jPanel3Layout.setHorizontalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel9, -2, 153, -2).addGap(77, 77, 77).addComponent(this.lblspic, -2, 164, -2).addGap(10, 10, 10).addComponent(this.jButton4, -1, 140, 32767)).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel7, -2, 153, -2).addGap(77, 77, 77).addComponent(this.txtskul, -1, 314, 32767)).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel8, -2, 153, -2).addGap(77, 77, 77).addComponent(this.txtaddress, -1, 314, 32767)).addGroup(GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup().addComponent(this.jLabel6, -2, 153, -2).addGap(77, 77, 77).addComponent(this.txtlocation, -1, 314, 32767))).addContainerGap()));
/*     */ 
/* 179 */     jPanel3Layout.setVerticalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup().addContainerGap().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel7, -2, 37, -2).addComponent(this.txtskul, -2, 29, -2)).addGap(14, 14, 14).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtaddress, -2, -1, -2).addComponent(this.jLabel8, -2, 37, -2)).addGap(18, 18, 18).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtlocation, -2, 28, -2).addComponent(this.jLabel6, -2, 37, -2)).addGap(18, 18, 18).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.lblspic, -2, 124, -2).addComponent(this.jLabel9, -2, 37, -2).addComponent(this.jButton4)).addContainerGap(84, 32767)));
/*     */ 
/* 202 */     this.jPanel4.setBackground(new Color(102, 102, 255));
/* 203 */     this.jPanel4.setBorder(BorderFactory.createTitledBorder(new SoftBevelBorder(0), "Set up main user", 0, 0, new Font("Traditional Arabic", 0, 18)));
/*     */ 
/* 205 */     this.jLabel10.setFont(new Font("Traditional Arabic", 0, 18));
/* 206 */     this.jLabel10.setText("User Password");
/* 207 */     this.jLabel10.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 209 */     this.jLabel11.setFont(new Font("Traditional Arabic", 0, 18));
/* 210 */     this.jLabel11.setText("Full Name ");
/* 211 */     this.jLabel11.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 213 */     this.jLabel12.setFont(new Font("Traditional Arabic", 0, 18));
/* 214 */     this.jLabel12.setText("Username");
/* 215 */     this.jLabel12.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 217 */     this.jLabel13.setFont(new Font("Traditional Arabic", 0, 18));
/* 218 */     this.jLabel13.setText("Credentials");
/* 219 */     this.jLabel13.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 221 */     this.txtfname.setFont(new Font("Traditional Arabic", 0, 18));
/* 222 */     this.txtfname.setBorder(null);
/*     */ 
/* 224 */     this.txtcred.setFont(new Font("Traditional Arabic", 0, 18));
/* 225 */     this.txtcred.setText("Admin");
/* 226 */     this.txtcred.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/* 227 */     this.txtcred.setFocusable(false);
/* 228 */     this.txtcred.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 230 */         rrunning.this.txtcredActionPerformed(evt);
/*     */       }
/*     */     });
/* 234 */     this.txtuser.setFont(new Font("Traditional Arabic", 0, 18));
/* 235 */     this.txtuser.setBorder(null);
/*     */ 
/* 237 */     this.jLabel14.setFont(new Font("Traditional Arabic", 0, 18));
/* 238 */     this.jLabel14.setText("Confirm Password");
/* 239 */     this.jLabel14.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 241 */     this.jLabel15.setFont(new Font("Traditional Arabic", 0, 18));
/* 242 */     this.jLabel15.setText("Password Hint");
/* 243 */     this.jLabel15.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 245 */     this.txtcpass.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 247 */         rrunning.this.txtcpassActionPerformed(evt);
/*     */       }
/*     */     });
/* 251 */     this.txtphint.setFont(new Font("Traditional Arabic", 0, 18));
/* 252 */     this.txtphint.setBorder(null);
/* 253 */     this.txtphint.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 255 */         rrunning.this.txtphintActionPerformed(evt);
/*     */       }
/*     */     });
/* 259 */     GroupLayout jPanel4Layout = new GroupLayout(this.jPanel4);
/* 260 */     this.jPanel4.setLayout(jPanel4Layout);
/* 261 */     jPanel4Layout.setHorizontalGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel4Layout.createSequentialGroup().addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel4Layout.createSequentialGroup().addComponent(this.jLabel11, -2, 153, -2).addGap(77, 77, 77).addComponent(this.txtfname, -1, 312, 32767)).addGroup(jPanel4Layout.createSequentialGroup().addComponent(this.jLabel12, -2, 153, -2).addGap(77, 77, 77).addComponent(this.txtuser, -1, 312, 32767)).addGroup(jPanel4Layout.createSequentialGroup().addComponent(this.jLabel10, -2, 153, -2).addGap(77, 77, 77).addComponent(this.txtupass, -1, 312, 32767)).addGroup(jPanel4Layout.createSequentialGroup().addComponent(this.jLabel14, -2, 153, -2).addGap(77, 77, 77).addComponent(this.txtcpass, -1, 312, 32767)).addGroup(jPanel4Layout.createSequentialGroup().addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel13, -2, 153, -2).addComponent(this.jLabel15, -2, 153, -2)).addGap(77, 77, 77).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.txtphint, -1, 312, 32767).addComponent(this.txtcred, GroupLayout.Alignment.LEADING, -1, 312, 32767)))).addContainerGap()));
/*     */ 
/* 291 */     jPanel4Layout.setVerticalGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup().addContainerGap().addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel11, -2, 37, -2).addComponent(this.txtfname, -2, 29, -2)).addGap(14, 14, 14).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtuser, -2, -1, -2).addComponent(this.jLabel12, -2, 37, -2)).addGap(18, 18, 18).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel10, -2, 37, -2).addComponent(this.txtupass, -2, 29, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel14, -2, 37, -2).addComponent(this.txtcpass, -2, 29, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel15, -2, 37, -2).addComponent(this.txtphint, -2, 28, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel13, -2, 37, -2).addComponent(this.txtcred, -2, 28, -2)).addGap(44, 44, 44)));
/*     */ 
/* 321 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/* 322 */     this.jPanel1.setLayout(jPanel1Layout);
/* 323 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(this.jPanel3, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel4, -1, -1, 32767).addContainerGap()));
/*     */ 
/* 332 */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.jPanel3, GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.jPanel4, GroupLayout.Alignment.LEADING, -1, 386, 32767)).addContainerGap()));
/*     */ 
/* 341 */     this.jLabel5.setFont(new Font("Goudy Stout", 0, 24));
/* 342 */     this.jLabel5.setText("setup your system");
/*     */ 
/* 344 */     this.jButton2.setIcon(new ImageIcon(getClass().getResource("/myschool/Close-2-icon.png")));
/* 345 */     this.jButton2.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 347 */         rrunning.this.jButton2ActionPerformed(evt);
/*     */       }
/*     */     });
/* 351 */     this.jButton3.setIcon(new ImageIcon(getClass().getResource("/myschool/Actions-go-next-icon.png")));
/* 352 */     this.jButton3.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 354 */         rrunning.this.jButton3ActionPerformed(evt);
/*     */       }
/*     */     });
/* 358 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 359 */     getContentPane().setLayout(layout);
/* 360 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.jPanel2, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.jLabel5, -1, 882, 32767).addContainerGap()).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addComponent(this.jButton2, -2, 144, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton3, -2, 155, -2).addGap(27, 27, 27)))).addGroup(layout.createSequentialGroup().addComponent(this.jPanel1, -1, -1, 32767).addContainerGap()))));
/*     */ 
/* 381 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addGroup(layout.createSequentialGroup().addGap(53, 53, 53).addComponent(this.jLabel5, -2, 61, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 27, 32767).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.jButton3, -2, 53, -2).addComponent(this.jButton2, -2, 53, -2)).addGap(12, 12, 12)).addComponent(this.jPanel2, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel1, -2, -1, -2).addContainerGap()));
/*     */ 
/* 399 */     pack();
/*     */   }
/*     */ 
/*     */   private void jButton2ActionPerformed(ActionEvent evt) {
/* 403 */     String[] options = new String[2];
/* 404 */     options[0] = "Yes";
/* 405 */     options[1] = "No";
/*     */ 
/* 407 */     int val = JOptionPane.showOptionDialog(this.rootPane, "You must complete the setup procedure to use the system\n Are you sure you want to cancel??", "Exit", 0, 1, null, options, Integer.valueOf(0));
/* 408 */     if (val == 0) {
/* 409 */       JOptionPane.showMessageDialog(this.rootPane, "Setup cancelled by user");
/* 410 */       dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void jButton3ActionPerformed(ActionEvent evt) {
/*     */     try {
/* 416 */       String sname = this.txtskul.getText();
/* 417 */       String spic = this.path;
/* 418 */       String add = this.txtaddress.getText();
/* 419 */       String loc = this.txtlocation.getText();
/* 420 */       String fname = this.txtfname.getText();
/* 421 */       String uname = this.txtuser.getText();
/* 422 */       String upass = this.txtupass.getText();
/* 423 */       String cpass = this.txtcpass.getText();
/* 424 */       String hint = this.txtphint.getText();
/* 425 */       String cred = this.txtcred.getText();
/*     */ 
/* 429 */       if ((upass.length() > 5) && (cpass.length() > 5) && (upass.equals(cpass))) {
/* 430 */         JOptionPane.showMessageDialog(this.rootPane, "password match confirmed");
/*     */       }
/* 432 */       else if (cpass == null ? upass != null : !cpass.equals(upass)) {
/* 433 */         JOptionPane.showMessageDialog(this.rootPane, "Your confirmation password does not match with your password");
/*     */       }
/* 436 */       else if ((cpass.length() <= 5) || (upass.length() <= 5)) {
/* 437 */         JOptionPane.showMessageDialog(this.rootPane, "Your  password must be of 6 or more characters");
/*     */       }
/*     */ 
/* 443 */       String host = "jdbc:mysql://localhost:3306/myschool";
/* 444 */       String user = "root";
/* 445 */       String password = "muteti";
/* 446 */       Connection con = DriverManager.getConnection(host, user, password);
/* 447 */       con.setAutoCommit(false);
/* 448 */       PreparedStatement stmt = con.prepareStatement("INSERT INTO user VALUES(?,?,?,?,?)");
/* 449 */       stmt.setString(1, uname);
/* 450 */       stmt.setString(2, upass);
/* 451 */       stmt.setString(3, cred);
/* 452 */       stmt.setString(4, fname);
/* 453 */       stmt.setString(5, hint);
/* 454 */       stmt.executeUpdate();
/* 455 */       PreparedStatement stm = con.prepareStatement("INSERT INTO school VALUES(?,?,?,?)");
/* 456 */       stm.setString(1, sname);
/* 457 */       stm.setString(2, spic);
/* 458 */       stm.setString(3, add);
/* 459 */       stm.setString(4, loc);
/* 460 */       stm.executeUpdate();
/*     */       int u;
/* 461 */       if ((sname.isEmpty()) || (spic.isEmpty()) || (add.isEmpty()) || (loc.isEmpty()) || (fname.isEmpty()) || (uname.isEmpty()) || (upass.isEmpty()) || (cpass.isEmpty()) || (hint.isEmpty()) || (cred.isEmpty()))
/*     */       {
/* 464 */         con.rollback();
/* 465 */         u = Integer.parseInt("XX");
/*     */       }
/*     */       else {
/* 468 */         con.commit();
/*     */       }
/*     */ 
/* 471 */       JOptionPane.showMessageDialog(this.rootPane, "Setup complete Reload the program and Enjoy using the Highschool manager");
/* 472 */       dispose();
/*     */     }
/*     */     catch (Exception ex) {
/* 475 */       String sname = this.txtskul.getText();
/* 476 */       String spic = this.path;
/* 477 */       String add = this.txtaddress.getText();
/* 478 */       String loc = this.txtlocation.getText();
/* 479 */       String fname = this.txtfname.getText();
/* 480 */       String uname = this.txtuser.getText();
/* 481 */       String upass = this.txtupass.getText();
/* 482 */       String cpass = this.txtcpass.getText();
/* 483 */       String hint = this.txtphint.getText();
/* 484 */       String cred = this.txtcred.getText();
/*     */ 
/* 486 */       if ((sname.isEmpty()) || (spic.isEmpty()) || (add.isEmpty()) || (loc.isEmpty()) || (fname.isEmpty()) || (uname.isEmpty()) || (upass.isEmpty()) || (cpass.isEmpty()) || (hint.isEmpty()) || (cred.isEmpty()))
/*     */       {
/* 489 */         JOptionPane.showMessageDialog(this.rootPane, "You must input all field values correctly to proceed");
/*     */       }
/*     */       else
/*     */       {
/* 493 */         JOptionPane.showMessageDialog(this.rootPane, "An Error occured :Please make sure you set up the database with the instruction provided earlier\n " + ex.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void txtlocationActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void jButton4ActionPerformed(ActionEvent evt)
/*     */   {
/* 505 */     JFileChooser chooser = new JFileChooser();
/* 506 */     ExampleFileFilter filter = new ExampleFileFilter();
/* 507 */     filter.addExtension("jpg");
/* 508 */     filter.addExtension("gif");
/* 509 */     filter.setDescription("JPG & GIF Images");
/* 510 */     chooser.setFileFilter(filter);
/* 511 */     int returnVal = chooser.showOpenDialog(this);
/* 512 */     if (returnVal == 0)
/*     */     {
/* 514 */       this.path = chooser.getSelectedFile().getPath();
/* 515 */       ImageIcon spic = new ImageIcon("" + chooser.getSelectedFile().getPath());
/* 516 */       Image sp = spic.getImage();
/* 517 */       Image resizedImage = sp.getScaledInstance(this.lblspic.getWidth(), this.lblspic.getHeight(), 0);
/* 518 */       ImageIcon rim = new ImageIcon(resizedImage);
/* 519 */       this.lblspic.setIcon(rim);
/*     */     } else {
/* 521 */       ImageIcon spic = new ImageIcon();
/* 522 */       Image sp = spic.getImage();
/* 523 */       Image resizedImage = sp.getScaledInstance(this.lblspic.getWidth(), this.lblspic.getHeight(), 0);
/* 524 */       ImageIcon rim = new ImageIcon(resizedImage);
/* 525 */       this.lblspic.setIcon(rim);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void txtcredActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtphintActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtcpassActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 544 */     for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
/* 545 */       if ("Nimbus".equals(info.getName())) {
/*     */         try {
/* 547 */           UIManager.setLookAndFeel(info.getClassName());
/*     */         }
/*     */         catch (ClassNotFoundException ex) {
/* 550 */           Logger.getLogger(rrunning.class.getName()).log(Level.SEVERE, null, ex);
/*     */         } catch (InstantiationException ex) {
/* 552 */           Logger.getLogger(rrunning.class.getName()).log(Level.SEVERE, null, ex);
/*     */         } catch (IllegalAccessException ex) {
/* 554 */           Logger.getLogger(rrunning.class.getName()).log(Level.SEVERE, null, ex);
/*     */         } catch (UnsupportedLookAndFeelException ex) {
/* 556 */           Logger.getLogger(rrunning.class.getName()).log(Level.SEVERE, null, ex);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 561 */     EventQueue.invokeLater(new Runnable()
/*     */     {
/*     */       public void run() {
/* 564 */         new rrunning().setVisible(true);
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.rrunning
 * JD-Core Version:    0.6.2
 */