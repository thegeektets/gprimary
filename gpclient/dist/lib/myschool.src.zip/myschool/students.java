/*     */ package myschool;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.Image;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.border.LineBorder;
/*     */ import javax.swing.event.InternalFrameEvent;
/*     */ import javax.swing.event.InternalFrameListener;
/*     */ 
/*     */ public class students extends JInternalFrame
/*     */ {
/*     */   public static int parentid;
/*     */   mymain my;
/*     */   parent pr;
/*     */   String pic;
/*     */   private JButton btnadmit;
/*     */   private JButton btnchoosepic;
/*     */   private JButton btndte;
/*     */   private JButton btnfind;
/*     */   private JButton btnnew;
/*     */   private JComboBox cmbstream;
/*     */   private JComboBox combohouse;
/*     */   private JComboBox combosprt;
/*     */   private JButton jButton2;
/*     */   private JComboBox jComboBox1;
/*     */   private JComboBox jComboBox3;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel10;
/*     */   private JLabel jLabel11;
/*     */   private JLabel jLabel12;
/*     */   private JLabel jLabel2;
/*     */   private JLabel jLabel3;
/*     */   private JLabel jLabel5;
/*     */   private JLabel jLabel6;
/*     */   private JLabel jLabel7;
/*     */   private JLabel jLabel8;
/*     */   private JLabel jLabel9;
/*     */   private JPanel jPanel1;
/*     */   private JPanel jPanel2;
/*     */   private JPanel jPanel3;
/*     */   private JLabel lblheader;
/*     */   private JLabel lblspic;
/*     */   private JPanel pnlheader;
/*     */   private JTextField txtBCN;
/*     */   private JTextField txtPID;
/*     */   private JTextField txtadmin;
/*     */   private JComboBox txtclass;
/*     */   private JTextField txtdate;
/*     */   private JTextField txtfname;
/*     */   private JTextField txtsearch;
/*     */ 
/*     */   students(mymain aThis)
/*     */   {
/*  25 */     initComponents();
/*  26 */     this.my = aThis;
/*     */   }
/*     */ 
/*     */   students(parent aThis)
/*     */   {
/*  31 */     this.pr = aThis;
/*     */   }
/*     */   public String path() {
/*  34 */     JFileChooser chooser = new JFileChooser();
/*     */ 
/*  37 */     ExampleFileFilter filter = new ExampleFileFilter();
/*  38 */     filter.addExtension("jpg");
/*  39 */     filter.addExtension("gif");
/*  40 */     filter.setDescription("JPG & GIF Images");
/*  41 */     chooser.setFileFilter(filter);
/*  42 */     int returnVal = chooser.showOpenDialog(this);
/*  43 */     if (returnVal == 0) {
/*  44 */       System.out.println("You chose to open this file: " + chooser.getSelectedFile().getPath());
/*     */ 
/*  46 */       ImageIcon spic = new ImageIcon("" + chooser.getSelectedFile().getPath());
/*  47 */       Image sp = spic.getImage();
/*  48 */       Image resizedImage = sp.getScaledInstance(this.lblspic.getWidth(), this.lblspic.getHeight(), 0);
/*  49 */       ImageIcon rim = new ImageIcon(resizedImage);
/*  50 */       this.lblspic.setIcon(rim);
/*  51 */       return this.pic = chooser.getSelectedFile().getPath();
/*     */     }
/*     */ 
/*  54 */     ImageIcon spic = new ImageIcon("C:/Users/Griffin M/Documents/NetBeansProjects/myschool/index");
/*  55 */     Image sp = spic.getImage();
/*  56 */     Image resizedImage = sp.getScaledInstance(this.lblspic.getWidth(), this.lblspic.getHeight(), 0);
/*  57 */     ImageIcon rim = new ImageIcon(resizedImage);
/*  58 */     this.lblspic.setIcon(rim);
/*  59 */     return this.pic = chooser.getSelectedFile().getPath();
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  65 */     this.jPanel2 = new JPanel();
/*  66 */     this.jLabel2 = new JLabel();
/*  67 */     this.txtfname = new JTextField();
/*  68 */     this.jLabel9 = new JLabel();
/*  69 */     this.jLabel10 = new JLabel();
/*  70 */     this.txtBCN = new JTextField();
/*  71 */     this.jLabel8 = new JLabel();
/*  72 */     this.txtPID = new JTextField();
/*  73 */     this.jComboBox3 = new JComboBox();
/*  74 */     this.btnchoosepic = new JButton();
/*  75 */     this.jLabel3 = new JLabel();
/*  76 */     this.lblspic = new JLabel();
/*  77 */     this.pnlheader = new JPanel();
/*  78 */     this.lblheader = new JLabel();
/*  79 */     this.txtsearch = new JTextField();
/*  80 */     this.btnfind = new JButton();
/*  81 */     this.jPanel3 = new JPanel();
/*  82 */     this.jLabel6 = new JLabel();
/*  83 */     this.jLabel5 = new JLabel();
/*  84 */     this.jLabel7 = new JLabel();
/*  85 */     this.jLabel12 = new JLabel();
/*  86 */     this.combosprt = new JComboBox();
/*  87 */     this.combohouse = new JComboBox();
/*  88 */     this.cmbstream = new JComboBox();
/*  89 */     this.jButton2 = new JButton();
/*  90 */     this.btnadmit = new JButton();
/*  91 */     this.btnnew = new JButton();
/*  92 */     this.jComboBox1 = new JComboBox();
/*  93 */     this.txtclass = new JComboBox();
/*  94 */     this.jPanel1 = new JPanel();
/*  95 */     this.txtadmin = new JTextField();
/*  96 */     this.jLabel1 = new JLabel();
/*  97 */     this.jLabel11 = new JLabel();
/*  98 */     this.txtdate = new JTextField();
/*  99 */     this.btndte = new JButton();
/*     */ 
/* 101 */     setClosable(true);
/* 102 */     setIconifiable(true);
/* 103 */     setMaximizable(true);
/* 104 */     setResizable(true);
/* 105 */     setTitle("Student Registration");
/* 106 */     addInternalFrameListener(new InternalFrameListener() {
/*     */       public void internalFrameActivated(InternalFrameEvent evt) {
/*     */       }
/*     */       public void internalFrameClosed(InternalFrameEvent evt) {
/*     */       }
/*     */       public void internalFrameClosing(InternalFrameEvent evt) {
/* 112 */         students.this.formInternalFrameClosing(evt);
/*     */       }
/*     */ 
/*     */       public void internalFrameDeactivated(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameDeiconified(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameIconified(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameOpened(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */     });
/* 124 */     this.jPanel2.setBorder(BorderFactory.createTitledBorder(null, "Personal Details", 0, 0, new Font("Traditional Arabic", 0, 18)));
/* 125 */     this.jPanel2.setFont(new Font("Traditional Arabic", 0, 18));
/*     */ 
/* 127 */     this.jLabel2.setFont(new Font("Traditional Arabic", 0, 18));
/* 128 */     this.jLabel2.setText("Student Name");
/* 129 */     this.jLabel2.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 131 */     this.jLabel9.setFont(new Font("Traditional Arabic", 0, 18));
/* 132 */     this.jLabel9.setText("Sex");
/* 133 */     this.jLabel9.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 135 */     this.jLabel10.setFont(new Font("Traditional Arabic", 0, 18));
/* 136 */     this.jLabel10.setText("Bth Cert No.");
/* 137 */     this.jLabel10.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 139 */     this.jLabel8.setFont(new Font("Traditional Arabic", 0, 18));
/* 140 */     this.jLabel8.setText("ParentID");
/* 141 */     this.jLabel8.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 143 */     this.jComboBox3.setModel(new DefaultComboBoxModel(new String[] { "MALE", "FEMALE" }));
/*     */ 
/* 145 */     this.btnchoosepic.setText("Choose Picture");
/* 146 */     this.btnchoosepic.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 148 */         students.this.btnchoosepicActionPerformed(evt);
/*     */       }
/*     */     });
/* 152 */     this.jLabel3.setBackground(new Color(204, 204, 204));
/* 153 */     this.jLabel3.setFont(new Font("Traditional Arabic", 0, 18));
/* 154 */     this.jLabel3.setText("Student Picture");
/* 155 */     this.jLabel3.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 157 */     this.lblspic.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 159 */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/* 160 */     this.jPanel2.setLayout(jPanel2Layout);
/* 161 */     jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addComponent(this.jLabel3, -1, 172, 32767).addGap(35, 35, 35)).addGroup(jPanel2Layout.createSequentialGroup().addGap(31, 31, 31).addComponent(this.btnchoosepic, -2, 140, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.jLabel8, GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.jLabel10, GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.jLabel9, GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.jLabel2, GroupLayout.Alignment.LEADING, -1, 191, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED))).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.txtPID, GroupLayout.Alignment.LEADING, -1, 209, 32767).addComponent(this.txtfname, -1, 209, 32767).addComponent(this.lblspic, -2, 207, -2).addGroup(jPanel2Layout.createSequentialGroup().addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jComboBox3, 0, 209, 32767)).addGroup(jPanel2Layout.createSequentialGroup().addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtBCN, -1, 209, 32767))).addContainerGap()));
/*     */ 
/* 193 */     jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.jLabel3, -2, 25, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 151, 32767).addComponent(this.btnchoosepic, -2, 23, -2)).addComponent(this.lblspic, -2, 165, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtfname, -2, -1, -2).addComponent(this.jLabel2)).addGap(18, 18, 18).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel9).addComponent(this.jComboBox3, -2, -1, -2)).addGap(18, 18, 18).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel10).addComponent(this.txtBCN, -2, -1, -2)).addGap(36, 36, 36).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.txtPID, -2, -1, -2).addComponent(this.jLabel8)).addContainerGap()));
/*     */ 
/* 221 */     this.pnlheader.setBackground(new Color(204, 204, 255));
/* 222 */     this.pnlheader.setBorder(BorderFactory.createBevelBorder(0));
/* 223 */     this.pnlheader.setName("headerpanel");
/* 224 */     this.pnlheader.setRequestFocusEnabled(false);
/*     */ 
/* 226 */     this.lblheader.setFont(new Font("Traditional Arabic", 0, 24));
/* 227 */     this.lblheader.setHorizontalAlignment(0);
/* 228 */     this.lblheader.setText("Student Registration Form");
/* 229 */     this.lblheader.setToolTipText("");
/* 230 */     this.lblheader.setVerticalAlignment(1);
/* 231 */     this.lblheader.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
/* 232 */     this.lblheader.setEnabled(false);
/* 233 */     this.lblheader.setName("lblheader");
/*     */ 
/* 235 */     GroupLayout pnlheaderLayout = new GroupLayout(this.pnlheader);
/* 236 */     this.pnlheader.setLayout(pnlheaderLayout);
/* 237 */     pnlheaderLayout.setHorizontalGroup(pnlheaderLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, pnlheaderLayout.createSequentialGroup().addContainerGap().addComponent(this.lblheader, -1, 872, 32767).addContainerGap()));
/*     */ 
/* 244 */     pnlheaderLayout.setVerticalGroup(pnlheaderLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(pnlheaderLayout.createSequentialGroup().addContainerGap().addComponent(this.lblheader, -2, 37, -2).addContainerGap(14, 32767)));
/*     */ 
/* 252 */     this.btnfind.setFont(new Font("Traditional Arabic", 0, 18));
/* 253 */     this.btnfind.setText("Find Student by Adm");
/* 254 */     this.btnfind.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 256 */         students.this.btnfindActionPerformed(evt);
/*     */       }
/*     */     });
/* 260 */     this.jPanel3.setBorder(BorderFactory.createTitledBorder(null, "Other Details", 0, 0, new Font("Traditional Arabic", 0, 18)));
/*     */ 
/* 262 */     this.jLabel6.setFont(new Font("Traditional Arabic", 0, 18));
/* 263 */     this.jLabel6.setText("Stream");
/* 264 */     this.jLabel6.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 266 */     this.jLabel5.setFont(new Font("Traditional Arabic", 0, 18));
/* 267 */     this.jLabel5.setText("Class");
/* 268 */     this.jLabel5.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 270 */     this.jLabel7.setFont(new Font("Traditional Arabic", 0, 18));
/* 271 */     this.jLabel7.setText("House");
/* 272 */     this.jLabel7.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 274 */     this.jLabel12.setFont(new Font("Traditional Arabic", 0, 18));
/* 275 */     this.jLabel12.setText("Sport");
/* 276 */     this.jLabel12.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 278 */     this.combosprt.setEditable(true);
/* 279 */     this.combosprt.setModel(new DefaultComboBoxModel(new String[] { "", "Rugby", "Foot Ball", "hockey", "basket ball", "volley ball" }));
/*     */ 
/* 281 */     this.combohouse.setEditable(true);
/* 282 */     this.combohouse.setModel(new DefaultComboBoxModel(new String[] { "Nyayo1", " " }));
/*     */ 
/* 284 */     this.cmbstream.setEditable(true);
/* 285 */     this.cmbstream.setModel(new DefaultComboBoxModel(new String[] { "", "North", "South", "West", "" }));
/*     */ 
/* 287 */     this.jButton2.setFont(new Font("Traditional Arabic", 0, 18));
/* 288 */     this.jButton2.setText("Parent Details");
/* 289 */     this.jButton2.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 291 */         students.this.jButton2ActionPerformed(evt);
/*     */       }
/*     */     });
/* 295 */     this.btnadmit.setFont(new Font("Traditional Arabic", 0, 18));
/* 296 */     this.btnadmit.setText("Admit Student");
/* 297 */     this.btnadmit.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 299 */         students.this.btnadmitActionPerformed(evt);
/*     */       }
/*     */     });
/* 303 */     this.btnnew.setFont(new Font("Traditional Arabic", 0, 18));
/* 304 */     this.btnnew.setText("New  Student");
/* 305 */     this.btnnew.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 307 */         students.this.btnnewActionPerformed(evt);
/*     */       }
/*     */     });
/* 311 */     this.jComboBox1.setModel(new DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
/*     */ 
/* 313 */     this.txtclass.setModel(new DefaultComboBoxModel(new String[] { "", "1", "2", "3", "4", "" }));
/*     */ 
/* 315 */     GroupLayout jPanel3Layout = new GroupLayout(this.jPanel3);
/* 316 */     this.jPanel3.setLayout(jPanel3Layout);
/* 317 */     jPanel3Layout.setHorizontalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addGap(24, 24, 24).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel6, GroupLayout.Alignment.TRAILING, -1, 81, 32767).addComponent(this.jLabel7, -1, -1, 32767).addComponent(this.jLabel12, -1, -1, 32767).addComponent(this.jLabel5, -2, 103, -2)).addGap(26, 26, 26).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.combosprt, GroupLayout.Alignment.TRAILING, 0, 243, 32767).addComponent(this.combohouse, GroupLayout.Alignment.TRAILING, 0, 243, 32767).addComponent(this.cmbstream, 0, 243, 32767).addComponent(this.txtclass, 0, 243, 32767)).addContainerGap()).addGroup(GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup().addContainerGap(251, 32767).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jButton2, -2, 132, -2).addGap(23, 23, 23)).addGroup(GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup().addComponent(this.btnadmit).addGap(20, 20, 20)))).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addGap(20, 20, 20).addComponent(this.btnnew, -2, 140, -2).addContainerGap(246, 32767))));
/*     */ 
/* 348 */     jPanel3Layout.setVerticalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addContainerGap().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel5).addComponent(this.txtclass, -2, -1, -2)).addGap(31, 31, 31).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel6).addComponent(this.cmbstream, -2, -1, -2)).addGap(18, 18, 18).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel7).addComponent(this.combohouse, -2, -1, -2)).addGap(24, 24, 24).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel12).addComponent(this.combosprt, -2, -1, -2)).addGap(76, 76, 76).addComponent(this.jButton2, -1, 40, 32767).addGap(32, 32, 32).addComponent(this.btnadmit, -1, 41, 32767).addGap(49, 49, 49)).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addGap(275, 275, 275).addComponent(this.btnnew).addContainerGap(128, 32767))));
/*     */ 
/* 379 */     this.jPanel1.setBorder(BorderFactory.createTitledBorder(null, "", 2, 0, new Font("Arial", 1, 14), Color.white));
/*     */ 
/* 381 */     this.txtadmin.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 383 */         students.this.txtadminActionPerformed(evt);
/*     */       }
/*     */     });
/* 387 */     this.jLabel1.setFont(new Font("Traditional Arabic", 0, 18));
/* 388 */     this.jLabel1.setText("Adm Number");
/* 389 */     this.jLabel1.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 391 */     this.jLabel11.setFont(new Font("Traditional Arabic", 0, 18));
/* 392 */     this.jLabel11.setText("Admission Date");
/* 393 */     this.jLabel11.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 395 */     this.btndte.setIcon(new ImageIcon(getClass().getResource("/myschool/resources/arrow-down.png")));
/* 396 */     this.btndte.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 398 */         students.this.btndteActionPerformed(evt);
/*     */       }
/*     */     });
/* 402 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/* 403 */     this.jPanel1.setLayout(jPanel1Layout);
/* 404 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGap(25, 25, 25).addComponent(this.jLabel1, -2, 157, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 44, 32767).addComponent(this.txtadmin, -2, 160, -2).addGap(61, 61, 61).addComponent(this.jLabel11, -2, 153, -2).addGap(18, 18, 18).addComponent(this.txtdate, -2, 186, -2).addGap(10, 10, 10).addComponent(this.btndte, -2, 50, -2).addContainerGap()));
/*     */ 
/* 419 */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel1).addComponent(this.txtadmin, -2, -1, -2).addComponent(this.jLabel11))).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(this.txtdate, -2, -1, -2)).addComponent(this.btndte, -2, 48, -2)).addContainerGap(-1, 32767)));
/*     */ 
/* 436 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 437 */     getContentPane().setLayout(layout);
/* 438 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel1, -1, -1, 32767).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jPanel2, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.txtsearch, -2, 160, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 75, 32767).addComponent(this.btnfind)).addComponent(this.jPanel3, -2, -1, -2)))).addContainerGap()).addComponent(this.pnlheader, -1, -1, 32767));
/*     */ 
/* 456 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addComponent(this.pnlheader, -2, -1, -2).addGap(18, 18, 18).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtsearch, -2, 29, -2).addComponent(this.btnfind, -2, 37, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel1, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel2, -2, -1, -2).addComponent(this.jPanel3, -1, -1, 32767)).addContainerGap()));
/*     */ 
/* 473 */     pack();
/*     */   }
/*     */ 
/*     */   private void btnchoosepicActionPerformed(ActionEvent evt) {
/* 477 */     this.pic = path();
/*     */   }
/*     */ 
/*     */   private void btnfindActionPerformed(ActionEvent evt) {
/*     */     try {
/* 482 */       this.txtadmin.setText("");
/*     */ 
/* 485 */       this.txtfname.setText("");
/*     */ 
/* 488 */       this.txtclass.setSelectedItem("");
/* 489 */       this.txtdate.setText("");
/*     */ 
/* 491 */       this.txtPID.setText("");
/* 492 */       this.txtBCN.setText("");
/*     */ 
/* 494 */       String host = "jdbc:mysql://localhost:3306/myschool";
/* 495 */       String user = "root";
/* 496 */       String password = "muteti";
/* 497 */       Connection con = DriverManager.getConnection(host, user, password);
/*     */ 
/* 500 */       Statement stmt = con.createStatement();
/*     */ 
/* 502 */       ResultSet rs = stmt.executeQuery("Select *from STUDENT where studentnumber= " + Integer.parseInt(this.txtsearch.getText()));
/*     */ 
/* 505 */       if (rs.next()) {
/* 506 */         JOptionPane.showMessageDialog(null, "Record found!");
/*     */ 
/* 508 */         this.txtadmin.setText("" + rs.getInt("studentnumber"));
/* 509 */         String name = rs.getString("studentname");
/*     */ 
/* 511 */         this.txtfname.setText(name);
/*     */ 
/* 514 */         this.txtclass.setSelectedItem("" + rs.getInt("Class"));
/* 515 */         this.txtdate.setText(rs.getString("DOA"));
/* 516 */         this.cmbstream.setSelectedItem(rs.getString("stream"));
/* 517 */         this.txtPID.setText("" + rs.getInt("ParentsId"));
/* 518 */         this.combohouse.setSelectedItem(rs.getString("House"));
/* 519 */         this.txtBCN.setText("" + rs.getInt("Bcertnumber"));
/* 520 */         this.jComboBox3.setSelectedItem(rs.getString("sex"));
/* 521 */         System.out.println(rs.getString("spic"));
/* 522 */         ImageIcon spic = new ImageIcon(rs.getString("spic"));
/* 523 */         Image sp = spic.getImage();
/* 524 */         Image resizedImage = sp.getScaledInstance(this.lblspic.getWidth(), this.lblspic.getHeight(), 0);
/* 525 */         ImageIcon rim = new ImageIcon(resizedImage);
/* 526 */         this.lblspic.setIcon(rim);
/*     */       }
/*     */       else
/*     */       {
/* 531 */         JOptionPane.showMessageDialog(null, "No matching record found");
/*     */       }
/*     */     } catch (SQLException ex) { JOptionPane.showMessageDialog(null, "The above input student Admno does not show any record of a student please try again  "); }
/*     */   }
/*     */ 
/*     */   private void jButton2ActionPerformed(ActionEvent evt)
/*     */   {
/*     */     try {
/* 539 */       parentid = Integer.parseInt(this.txtPID.getText());
/*     */     }
/*     */     catch (Exception e) {
/* 542 */       parentid = 0;
/*     */     }
/*     */     finally {
/* 545 */       this.my.prnt();
/* 546 */       dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void btnadmitActionPerformed(ActionEvent evt)
/*     */   {
/*     */     try {
/* 553 */       String host = "jdbc:mysql://localhost:3306/myschool";
/* 554 */       String user = "root";
/* 555 */       String password = "muteti";
/* 556 */       Connection con = DriverManager.getConnection(host, user, password);
/* 557 */       String hou = (String)this.combohouse.getSelectedItem();
/* 558 */       String sport = (String)this.combosprt.getSelectedItem();
/* 559 */       String gender = (String)this.jComboBox3.getSelectedItem();
/*     */ 
/* 561 */       PreparedStatement stmt = con.prepareStatement("INSERT INTO STUDENT VALUES(?,?,?,?,?,?,?,?,?,?)");
/*     */ 
/* 563 */       stmt.setInt(1, Integer.parseInt(this.txtadmin.getText()));
/* 564 */       stmt.setString(2, this.txtfname.getText());
/* 565 */       String clas = (String)this.txtclass.getSelectedItem();
/* 566 */       stmt.setString(7, clas);
/* 567 */       stmt.setString(6, this.txtsearch.getText());
/* 568 */       stmt.setString(5, hou);
/* 569 */       stmt.setString(8, this.txtPID.getText());
/* 570 */       String stream = (String)this.cmbstream.getSelectedItem();
/* 571 */       stmt.setString(4, stream);
/* 572 */       stmt.setString(3, gender);
/* 573 */       stmt.setInt(9, Integer.parseInt(this.txtBCN.getText()));
/* 574 */       stmt.setString(10, this.pic);
/* 575 */       System.out.println(this.pic);
/* 576 */       stmt.executeUpdate();
/* 577 */       JOptionPane.showMessageDialog(null, "Save operation successfull");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 581 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void btnnewActionPerformed(ActionEvent evt) {
/* 586 */     this.txtadmin.setText("");
/*     */ 
/* 589 */     this.txtfname.setText("");
/*     */ 
/* 592 */     this.txtclass.setSelectedItem("");
/* 593 */     this.txtdate.setText("");
/*     */ 
/* 595 */     this.txtPID.setText("");
/* 596 */     this.txtBCN.setText("");
/* 597 */     this.lblspic.setIcon(null);
/*     */   }
/*     */ 
/*     */   private void txtadminActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void btndteActionPerformed(ActionEvent evt)
/*     */   {
/* 689 */     JFrame f = null;
/*     */ 
/* 691 */     this.txtdate.setText(new Object()
/*     */     {
/* 606 */       int month = Calendar.getInstance().get(2);
/* 607 */       int year = Calendar.getInstance().get(1);
/* 608 */       JLabel l = new JLabel("", 0);
/* 609 */       String day = "";
/*     */       JDialog d;
/* 611 */       JButton[] button = new JButton[49];
/*     */ 
/*     */       public void displayDate()
/*     */       {
/* 665 */         for (int x = 7; x < this.button.length; x++)
/* 666 */           this.button[x].setText("");
/* 667 */         SimpleDateFormat sdf = new SimpleDateFormat("MMMM yyyy");
/*     */ 
/* 669 */         Calendar cal = Calendar.getInstance();
/* 670 */         cal.set(this.year, this.month, 1);
/* 671 */         int dayOfWeek = cal.get(7);
/* 672 */         int daysInMonth = cal.getActualMaximum(5);
/* 673 */         int x = 6 + dayOfWeek; for (int day = 1; day <= daysInMonth; day++) {
/* 674 */           this.button[x].setText("" + day);
/*     */ 
/* 673 */           x++;
/*     */         }
/* 675 */         this.l.setText(sdf.format(cal.getTime()));
/* 676 */         this.d.setTitle("Date Picker");
/*     */       }
/*     */ 
/*     */       public String setPickedDate() {
/* 680 */         if (this.day.equals(""))
/* 681 */           return this.day;
/* 682 */         SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
/*     */ 
/* 684 */         Calendar cal = Calendar.getInstance();
/* 685 */         cal.set(this.year, this.month, Integer.parseInt(this.day));
/* 686 */         return sdf.format(cal.getTime());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 691 */     .setPickedDate());
/*     */   }
/*     */ 
/*     */   private void formInternalFrameClosing(InternalFrameEvent evt)
/*     */   {
/* 704 */     this.my.add();
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.students
 * JD-Core Version:    0.6.2
 */