/*     */ package myschool;
/*     */ 
/*     */ import java.awt.Window;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.UIManager.LookAndFeelInfo;
/*     */ import javax.swing.UnsupportedLookAndFeelException;
/*     */ import org.jdesktop.application.Application;
/*     */ import org.jdesktop.application.SingleFrameApplication;
/*     */ 
/*     */ public class SchoolApp extends SingleFrameApplication
/*     */ {
/*  25 */   mymain df = new mymain(this);
/*  26 */   frunning f = new frunning(this);
/*     */ 
/*  28 */   public static int thrown = 0;
/*     */ 
/*     */   public static void script() {
/*  31 */     boolean verbose = false;
/*     */ 
/*  34 */     String user = "root";
/*  35 */     String password = "muteti";
/*     */     try
/*     */     {
/*  38 */       String[] cmd = { "mysql", "--user=" + user, "--password=" + password, "-e", "\"source C:/Program Files/markquery.sql\"" };
/*     */ 
/*  45 */       System.err.println(cmd[0] + " " + cmd[1] + " " + cmd[2] + " " + cmd[3] + " " + cmd[4] + " ");
/*     */ 
/*  48 */       Process proc = Runtime.getRuntime().exec(cmd);
/*  49 */       if (verbose) {
/*  50 */         InputStream inputstream = proc.getInputStream();
/*  51 */         InputStreamReader inputstreamreader = new InputStreamReader(inputstream);
/*  52 */         BufferedReader bufferedreader = new BufferedReader(inputstreamreader);
/*     */         String line;
/*  56 */         while ((line = bufferedreader.readLine()) != null) {
/*  57 */           System.out.println(line);
/*     */         }
/*     */ 
/*     */         try
/*     */         {
/*  62 */           if (proc.waitFor() != 0) {
/*  63 */             System.err.println("exit value = " + proc.exitValue());
/*     */           }
/*     */         }
/*     */         catch (InterruptedException e)
/*     */         {
/*  68 */           System.err.println(e);
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/*  72 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  75 */     JOptionPane.showMessageDialog(null, "Database creation successfull");
/*     */   }
/*     */ 
/*     */   public static void pop()
/*     */   {
/*     */     try {
/*  81 */       String host = "jdbc:mysql://localhost:3306/myschool";
/*  82 */       String user = "root";
/*  83 */       String password = "muteti";
/*  84 */       Connection con = DriverManager.getConnection(host, user, password);
/*  85 */       Statement st = con.createStatement();
/*  86 */       ResultSet rs = st.executeQuery("Select * from school");
/*  87 */       rs.next();
/*  88 */       name = rs.getString("sname");
/*     */     }
/*     */     catch (SQLException ex)
/*     */     {
/*     */       String name;
/*  92 */       thrown = 1;
/*  93 */       System.out.println("running for the first time");
/*  94 */       script();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void startup()
/*     */   {
/*     */     try {
/* 101 */       for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
/* 102 */         if ("Nimbus".equals(info.getName())) {
/* 103 */           UIManager.setLookAndFeel(info.getClassName());
/* 104 */           break;
/*     */         }
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 108 */       Logger.getLogger(SchoolApp.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } catch (InstantiationException ex) {
/* 110 */       Logger.getLogger(SchoolApp.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } catch (IllegalAccessException ex) {
/* 112 */       Logger.getLogger(SchoolApp.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } catch (UnsupportedLookAndFeelException ex) {
/* 114 */       Logger.getLogger(SchoolApp.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/* 116 */     pop();
/* 117 */     if (thrown == 1) {
/* 118 */       System.out.println("running for the first time");
/*     */ 
/* 121 */       show(new frunning(this));
/*     */     }
/*     */     else
/*     */     {
/* 126 */       show(new mymain(this));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void configureWindow(Window root)
/*     */   {
/*     */   }
/*     */ 
/*     */   public static SchoolApp getApplication()
/*     */   {
/* 142 */     return (SchoolApp)Application.getInstance(SchoolApp.class);
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 149 */     launch(SchoolApp.class, args);
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.SchoolApp
 * JD-Core Version:    0.6.2
 */