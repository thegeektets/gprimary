/*      */ package myschool;
/*      */ 
/*      */ import java.awt.Color;
/*      */ import java.awt.Container;
/*      */ import java.awt.Font;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.io.PrintStream;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DriverManager;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.swing.BorderFactory;
/*      */ import javax.swing.DefaultComboBoxModel;
/*      */ import javax.swing.GroupLayout;
/*      */ import javax.swing.GroupLayout.Alignment;
/*      */ import javax.swing.GroupLayout.ParallelGroup;
/*      */ import javax.swing.GroupLayout.SequentialGroup;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JInternalFrame;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JOptionPane;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JScrollPane;
/*      */ import javax.swing.JTabbedPane;
/*      */ import javax.swing.JTable;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.LayoutStyle.ComponentPlacement;
/*      */ import javax.swing.border.LineBorder;
/*      */ import javax.swing.event.ChangeEvent;
/*      */ import javax.swing.event.ChangeListener;
/*      */ import javax.swing.event.InternalFrameEvent;
/*      */ import javax.swing.event.InternalFrameListener;
/*      */ import javax.swing.table.DefaultTableModel;
/*      */ 
/*      */ public class examstud extends JInternalFrame
/*      */ {
/*      */   mymain fm;
/*    9 */   int thrown = 0;
/*      */   private JButton btnfindall;
/*      */   private JButton btnsave;
/*      */   private JButton bttnew;
/*      */   private JTable endtbl;
/*      */   private JButton jButton1;
/*      */   private JScrollPane jScrollPane1;
/*      */   private JScrollPane jScrollPane5;
/*      */   private JScrollPane jScrollPane6;
/*      */   private JScrollPane jScrollPane7;
/*      */   private JLabel lblagentno1;
/*      */   private JLabel lblagentno3;
/*      */   private JLabel lblagentno4;
/*      */   private JLabel lblagentno5;
/*      */   private JLabel lblflatname1;
/*      */   private JLabel lblflatnumber1;
/*      */   private JLabel lblflatnumber2;
/*      */   private JLabel lblflatnumber3;
/*      */   private JLabel lblheader;
/*      */   private JTable midtbl;
/*      */   private JTable openertbl;
/*      */   private JTable othertbl;
/*      */   private JPanel pnlexamdetails;
/*      */   private JPanel pnlheader;
/*      */   private JTabbedPane pnlscores;
/*      */   private JComboBox txtclass;
/*      */   private JTextField txtentry;
/*      */   private JTextField txtexamno;
/*      */   private JComboBox txtexamtype;
/*      */   private JTextField txtstream;
/*      */   private JComboBox txttrm;
/*      */   private JTextField txtyear;
/*      */   private JTextField txtyr;
/*      */ 
/*      */   public examstud(mymain mf)
/*      */   {
/*   12 */     initComponents();
/*   13 */     this.fm = mf;
/*      */   }
/*      */ 
/*      */   public void spop()
/*      */   {
/*      */     try
/*      */     {
/*   21 */       Class.forName("com.mysql.jdbc.Driver");
/*   22 */       Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*   23 */       Statement S = conn.createStatement();
/*      */       String sql;
/*      */       String sql;
/*   24 */       if ((this.txtclass.getSelectedItem().toString().length() > 0) && (this.txtstream.getText().length() > 0))
/*      */       {
/*   27 */         sql = "Select studentnumber,studentname from student where Class='" + Integer.parseInt((String)this.txtclass.getSelectedItem()) + "'and student.stream='" + this.txtstream.getText() + "'";
/*      */       }
/*      */       else
/*      */       {
/*      */         String sql;
/*   29 */         if (this.txtclass.getSelectedItem().toString().length() > 0) {
/*   30 */           sql = "Select studentnumber,studentname from student where Class='" + Integer.parseInt((String)this.txtclass.getSelectedItem()) + "'";
/*      */         }
/*      */         else
/*   33 */           sql = "Select studentnumber,studentname from student where stream='" + this.txtstream.getText() + "'";
/*      */       }
/*   35 */       ResultSet rset = S.executeQuery(sql);
/*   36 */       int r = 0;
/*      */       try
/*      */       {
/*   40 */         while (rset.next())
/*      */         {
/*   42 */           int adm = rset.getInt("studentnumber");
/*   43 */           String name = rset.getString("studentname");
/*      */ 
/*   45 */           if (this.txtexamno.getText().length() > 0) {
/*   46 */             this.openertbl.setValueAt(this.txtexamno.getText(), r, 0);
/*   47 */             this.openertbl.setValueAt("" + adm, r, 1);
/*   48 */             this.openertbl.setValueAt(name, r, 2);
/*      */ 
/*   51 */             this.midtbl.setValueAt(this.txtexamno.getText(), r, 0);
/*   52 */             this.midtbl.setValueAt("" + adm, r, 1);
/*   53 */             this.midtbl.setValueAt(name, r, 2);
/*      */ 
/*   57 */             this.endtbl.setValueAt(this.txtexamno.getText(), r, 0);
/*   58 */             this.endtbl.setValueAt("" + adm, r, 1);
/*   59 */             this.endtbl.setValueAt(name, r, 2);
/*      */ 
/*   62 */             this.othertbl.setValueAt(this.txtexamno.getText(), r, 0);
/*   63 */             this.othertbl.setValueAt("" + adm, r, 1);
/*   64 */             this.othertbl.setValueAt(name, r, 2);
/*      */ 
/*   66 */             r++;
/*      */           } else {
/*   68 */             JOptionPane.showMessageDialog(null, "please input an exam number before you can proceed");
/*      */           }
/*      */         }
/*      */       } catch (Exception e) {
/*   72 */         JOptionPane.showMessageDialog(null, "Please ensure that you have input class and stream details correctly \n Because the ones selected above show no record of studens");
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (ClassNotFoundException ex)
/*      */     {
/*   80 */       Logger.getLogger(examstud.class.getName()).log(Level.SEVERE, null, ex);
/*      */     } catch (SQLException ex) {
/*   82 */       Logger.getLogger(examstud.class.getName()).log(Level.SEVERE, null, ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void save()
/*      */   {
/*      */   }
/*      */ 
/*      */   public void populate()
/*      */   {
/*      */     try
/*      */     {
/*  104 */       Class.forName("com.mysql.jdbc.Driver");
/*  105 */       Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*      */ 
/*  107 */       String ex = (String)this.txtexamtype.getSelectedItem();
/*  108 */       Statement S = conn.createStatement();
/*  109 */       String sql = "Select *from score where examno=" + Integer.parseInt(this.txtexamno.getText());
/*  110 */       ResultSet rset = S.executeQuery(sql);
/*  111 */       if (ex.isEmpty())
/*      */       {
/*  113 */         int r = 0;
/*  114 */         while (rset.next())
/*      */         {
/*  116 */           this.openertbl.setValueAt(null, r, 0);
/*  117 */           this.openertbl.setValueAt(null, r, 1);
/*  118 */           this.openertbl.setValueAt(null, r, 2);
/*  119 */           this.openertbl.setValueAt(null, r, 3);
/*  120 */           this.openertbl.setValueAt(null, r, 4);
/*  121 */           this.openertbl.setValueAt(null, r, 5);
/*  122 */           this.openertbl.setValueAt(null, r, 6);
/*  123 */           this.openertbl.setValueAt(null, r, 7);
/*  124 */           this.openertbl.setValueAt(null, r, 8);
/*  125 */           this.openertbl.setValueAt(null, r, 9);
/*  126 */           this.openertbl.setValueAt(null, r, 10);
/*  127 */           this.openertbl.setValueAt(null, r, 11);
/*  128 */           this.openertbl.setValueAt(null, r, 12);
/*  129 */           this.openertbl.setValueAt(null, r, 13);
/*  130 */           this.openertbl.setValueAt(null, r, 0);
/*  131 */           r++;
/*      */         }
/*      */ 
/*      */       }
/*  136 */       else if (ex.contains("Opener"))
/*      */       {
/*  140 */         int r = 0;
/*  141 */         while (rset.next())
/*      */         {
/*  143 */           int admno = rset.getInt("admno");
/*  144 */           String sq = "Select studentname from student where studentnumber=" + admno;
/*      */ 
/*  146 */           Statement st = conn.createStatement();
/*  147 */           ResultSet rst = st.executeQuery(sq);
/*  148 */           rst.next();
/*  149 */           String name = rst.getString("studentname");
/*  150 */           int en = rset.getInt("examno");
/*  151 */           int eng = rset.getInt("exam");
/*  152 */           int kis = rset.getInt("exam1");
/*  153 */           int math = rset.getInt("exam2");
/*  154 */           int bio = rset.getInt("exam3");
/*      */ 
/*  156 */           int chem = rset.getInt("exam4");
/*  157 */           int phyc = rset.getInt("exam5");
/*  158 */           int histo = rset.getInt("exam6");
/*  159 */           int cre = rset.getInt("exam7");
/*  160 */           int geog = rset.getInt("exam8");
/*  161 */           int bs = rset.getInt("exam9");
/*  162 */           int comp = rset.getInt("exam10");
/*  163 */           int agri = rset.getInt("exam11");
/*  164 */           this.openertbl.setValueAt(Integer.valueOf(admno), r, 1);
/*  165 */           this.openertbl.setValueAt(Integer.valueOf(en), r, 0);
/*  166 */           this.openertbl.setValueAt(name, r, 2);
/*  167 */           this.openertbl.setValueAt(Integer.valueOf(eng), r, 3);
/*  168 */           this.openertbl.setValueAt(Integer.valueOf(kis), r, 4);
/*  169 */           this.openertbl.setValueAt(Integer.valueOf(math), r, 5);
/*  170 */           this.openertbl.setValueAt(Integer.valueOf(bio), r, 6);
/*  171 */           this.openertbl.setValueAt(Integer.valueOf(chem), r, 7);
/*  172 */           this.openertbl.setValueAt(Integer.valueOf(phyc), r, 8);
/*  173 */           this.openertbl.setValueAt(Integer.valueOf(histo), r, 9);
/*  174 */           this.openertbl.setValueAt(Integer.valueOf(cre), r, 10);
/*  175 */           this.openertbl.setValueAt(Integer.valueOf(geog), r, 11);
/*  176 */           this.openertbl.setValueAt(Integer.valueOf(bs), r, 12);
/*  177 */           this.openertbl.setValueAt(Integer.valueOf(comp), r, 13);
/*  178 */           this.openertbl.setValueAt(Integer.valueOf(agri), r, 14);
/*      */ 
/*  180 */           r++;
/*      */         }
/*  182 */       } else if (ex.contains("Midterm")) {
/*  183 */         spop();
/*      */ 
/*  185 */         int r = 0;
/*  186 */         while (rset.next())
/*      */         {
/*  188 */           int admno = rset.getInt("admno");
/*  189 */           String sq = "Select studentname from student where studentnumber=" + admno;
/*      */ 
/*  191 */           Statement st = conn.createStatement();
/*  192 */           ResultSet rst = st.executeQuery(sq);
/*  193 */           rst.next();
/*  194 */           String name = rst.getString("studentname");
/*  195 */           int en = rset.getInt("examno");
/*  196 */           int eng = rset.getInt("exam");
/*  197 */           int kis = rset.getInt("exam1");
/*  198 */           int math = rset.getInt("exam2");
/*  199 */           int bio = rset.getInt("exam3");
/*      */ 
/*  201 */           int chem = rset.getInt("exam4");
/*  202 */           int phyc = rset.getInt("exam5");
/*  203 */           int histo = rset.getInt("exam6");
/*  204 */           int cre = rset.getInt("exam7");
/*  205 */           int geog = rset.getInt("exam8");
/*  206 */           int bs = rset.getInt("exam9");
/*  207 */           int comp = rset.getInt("exam10");
/*  208 */           int agri = rset.getInt("exam11");
/*      */ 
/*  211 */           this.midtbl.setValueAt(Integer.valueOf(admno), r, 1);
/*  212 */           this.midtbl.setValueAt(Integer.valueOf(en), r, 0);
/*  213 */           this.midtbl.setValueAt(name, r, 2);
/*      */ 
/*  215 */           this.midtbl.setValueAt(Integer.valueOf(eng), r, 3);
/*  216 */           this.midtbl.setValueAt(Integer.valueOf(kis), r, 4);
/*  217 */           this.midtbl.setValueAt(Integer.valueOf(math), r, 5);
/*  218 */           this.midtbl.setValueAt(Integer.valueOf(bio), r, 6);
/*  219 */           this.midtbl.setValueAt(Integer.valueOf(chem), r, 7);
/*  220 */           this.midtbl.setValueAt(Integer.valueOf(phyc), r, 8);
/*  221 */           this.midtbl.setValueAt(Integer.valueOf(histo), r, 9);
/*  222 */           this.midtbl.setValueAt(Integer.valueOf(cre), r, 10);
/*  223 */           this.midtbl.setValueAt(Integer.valueOf(geog), r, 11);
/*  224 */           this.midtbl.setValueAt(Integer.valueOf(bs), r, 12);
/*  225 */           this.midtbl.setValueAt(Integer.valueOf(comp), r, 13);
/*  226 */           this.midtbl.setValueAt(Integer.valueOf(agri), r, 14);
/*      */ 
/*  228 */           r++;
/*      */         }
/*  230 */       } else if (ex.contains("Endterm"))
/*      */       {
/*  233 */         int r = 0;
/*  234 */         while (rset.next())
/*      */         {
/*  236 */           int admno = rset.getInt("admno");
/*  237 */           String sq = "Select studentname from student where studentnumber=" + admno;
/*      */ 
/*  239 */           Statement st = conn.createStatement();
/*  240 */           ResultSet rst = st.executeQuery(sq);
/*  241 */           rst.next();
/*  242 */           String name = rst.getString("studentname");
/*  243 */           int en = rset.getInt("examno");
/*  244 */           int eng = rset.getInt("exam");
/*  245 */           int kis = rset.getInt("exam1");
/*  246 */           int math = rset.getInt("exam2");
/*  247 */           int bio = rset.getInt("exam3");
/*      */ 
/*  249 */           int chem = rset.getInt("exam4");
/*  250 */           int phyc = rset.getInt("exam5");
/*  251 */           int histo = rset.getInt("exam6");
/*  252 */           int cre = rset.getInt("exam7");
/*  253 */           int geog = rset.getInt("exam8");
/*  254 */           int bs = rset.getInt("exam9");
/*  255 */           int comp = rset.getInt("exam10");
/*  256 */           int agri = rset.getInt("exam11");
/*      */ 
/*  259 */           this.endtbl.setValueAt(Integer.valueOf(admno), r, 1);
/*  260 */           this.endtbl.setValueAt(Integer.valueOf(en), r, 0);
/*  261 */           this.endtbl.setValueAt(name, r, 2);
/*      */ 
/*  263 */           this.endtbl.setValueAt(Integer.valueOf(eng), r, 3);
/*  264 */           this.endtbl.setValueAt(Integer.valueOf(kis), r, 4);
/*  265 */           this.endtbl.setValueAt(Integer.valueOf(math), r, 5);
/*  266 */           this.endtbl.setValueAt(Integer.valueOf(bio), r, 6);
/*  267 */           this.endtbl.setValueAt(Integer.valueOf(chem), r, 7);
/*  268 */           this.endtbl.setValueAt(Integer.valueOf(phyc), r, 8);
/*  269 */           this.endtbl.setValueAt(Integer.valueOf(histo), r, 9);
/*  270 */           this.endtbl.setValueAt(Integer.valueOf(cre), r, 10);
/*  271 */           this.endtbl.setValueAt(Integer.valueOf(geog), r, 11);
/*  272 */           this.endtbl.setValueAt(Integer.valueOf(bs), r, 12);
/*  273 */           this.endtbl.setValueAt(Integer.valueOf(comp), r, 13);
/*  274 */           this.endtbl.setValueAt(Integer.valueOf(agri), r, 14);
/*      */ 
/*  276 */           r++;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  281 */         int r = 0;
/*  282 */         while (rset.next())
/*      */         {
/*  284 */           int admno = rset.getInt("admno");
/*  285 */           String sq = "Select studentname from student where studentnumber=" + admno;
/*      */ 
/*  287 */           Statement st = conn.createStatement();
/*  288 */           ResultSet rst = st.executeQuery(sq);
/*  289 */           rst.next();
/*  290 */           String name = rst.getString("studentname");
/*      */ 
/*  292 */           int en = rset.getInt("examno");
/*  293 */           int eng = rset.getInt("exam");
/*  294 */           int kis = rset.getInt("exam1");
/*  295 */           int math = rset.getInt("exam2");
/*  296 */           int bio = rset.getInt("exam3");
/*      */ 
/*  298 */           int chem = rset.getInt("exam4");
/*  299 */           int phyc = rset.getInt("exam5");
/*  300 */           int histo = rset.getInt("exam6");
/*  301 */           int cre = rset.getInt("exam7");
/*  302 */           int geog = rset.getInt("exam8");
/*  303 */           int bs = rset.getInt("exam9");
/*  304 */           int comp = rset.getInt("exam10");
/*  305 */           int agri = rset.getInt("exam11");
/*      */ 
/*  308 */           this.othertbl.setValueAt(Integer.valueOf(admno), r, 1);
/*  309 */           this.othertbl.setValueAt(Integer.valueOf(en), r, 0);
/*  310 */           this.othertbl.setValueAt(name, r, 2);
/*  311 */           this.othertbl.setValueAt(Integer.valueOf(eng), r, 3);
/*  312 */           this.othertbl.setValueAt(Integer.valueOf(kis), r, 4);
/*  313 */           this.othertbl.setValueAt(Integer.valueOf(math), r, 5);
/*  314 */           this.othertbl.setValueAt(Integer.valueOf(bio), r, 6);
/*  315 */           this.othertbl.setValueAt(Integer.valueOf(chem), r, 7);
/*  316 */           this.othertbl.setValueAt(Integer.valueOf(phyc), r, 8);
/*  317 */           this.othertbl.setValueAt(Integer.valueOf(histo), r, 9);
/*  318 */           this.othertbl.setValueAt(Integer.valueOf(cre), r, 10);
/*  319 */           this.othertbl.setValueAt(Integer.valueOf(geog), r, 11);
/*  320 */           this.othertbl.setValueAt(Integer.valueOf(bs), r, 12);
/*  321 */           this.othertbl.setValueAt(Integer.valueOf(comp), r, 13);
/*  322 */           this.othertbl.setValueAt(Integer.valueOf(agri), r, 14);
/*      */ 
/*  324 */           r++;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  330 */       rset.close();
/*      */     } catch (ClassNotFoundException ex) {
/*  332 */       Logger.getLogger(examstud.class.getName()).log(Level.SEVERE, null, ex);
/*      */     } catch (SQLException ex) {
/*  334 */       Logger.getLogger(examstud.class.getName()).log(Level.SEVERE, null, ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void validate(String nu)
/*      */   {
/*      */     try
/*      */     {
/*  343 */       int number = Integer.parseInt(nu);
/*  344 */       if ((number < 0) || (number > 100))
/*      */       {
/*  346 */         JOptionPane.showMessageDialog(null, "You have input a value " + nu + " which is an incorrect format");
/*      */       }
/*      */     } catch (Exception e) { JOptionPane.showMessageDialog(null, "Value " + nu + " input is non numeric all value must be numeric"); }
/*      */   }
/*      */ 
/*      */   public void add(String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, String s9, String s10, String s11, String s12)
/*      */   {
/*  353 */     String[] marks = new String[12];
/*  354 */     marks[0] = s1;
/*  355 */     marks[1] = s2;
/*  356 */     marks[2] = s3;
/*  357 */     marks[3] = s4;
/*  358 */     marks[4] = s5;
/*  359 */     marks[5] = s6;
/*  360 */     marks[6] = s7;
/*  361 */     marks[7] = s8;
/*  362 */     marks[8] = s9;
/*  363 */     marks[9] = s10;
/*  364 */     marks[10] = s11;
/*  365 */     marks[11] = s12;
/*      */ 
/*  367 */     for (int a = 0; a < 12; a++) {
/*  368 */       String mark = marks[a];
/*  369 */       validate(mark);
/*  370 */       System.out.println(mark);
/*      */     }
/*      */   }
/*      */ 
/*      */   public String grade(int mark) {
/*      */     try { Class.forName("com.mysql.jdbc.Driver");
/*  376 */       Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*      */ 
/*  378 */       Statement st = conn.createStatement();
/*  379 */       ResultSet rs = st.executeQuery("select * from grades");
/*  380 */       while (rs.next()) {
/*  381 */         int max = rs.getInt("maximum");
/*  382 */         int min = rs.getInt("minmum");
/*  383 */         String grde = rs.getString("grade");
/*  384 */         if (max < mark)
/*      */         {
/*  386 */           rs.next();
/*  387 */           return grde;
/*      */         }
/*  389 */         if (max == mark)
/*      */         {
/*  391 */           return grde;
/*      */         }
/*      */ 
/*  395 */         if ((max > mark) && (mark > min)) {
/*  396 */           return grde;
/*      */         }
/*      */ 
/*  399 */         if ((mark > 100) || (mark < 0) || (mark == 0)) {
/*  400 */           return "Y";
/*      */         }
/*  402 */         if (min == mark) {
/*  403 */           return grde;
/*      */         }
/*      */       }
/*      */ 
/*  407 */       return "Y";
/*      */     }
/*      */     catch (SQLException ex)
/*      */     {
/*  411 */       Logger.getLogger(examstud.class.getName()).log(Level.SEVERE, null, ex);
/*  412 */       return "Y";
/*      */     }
/*      */     catch (ClassNotFoundException ex) {
/*  415 */       Logger.getLogger(examstud.class.getName()).log(Level.SEVERE, null, ex);
/*  416 */       return "Y";
/*      */     }
/*      */   }
/*      */ 
/*      */   public void grde(String examno, String adm, String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, String s9, String s10, String s11, String s12)
/*      */   {
/*      */     try
/*      */     {
/*  429 */       Class.forName("com.mysql.jdbc.Driver");
/*  430 */       Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*      */ 
/*  432 */       String[] marks = new String[12];
/*  433 */       marks[0] = s1;
/*  434 */       marks[1] = s2;
/*  435 */       marks[2] = s3;
/*  436 */       marks[3] = s4;
/*  437 */       marks[4] = s5;
/*  438 */       marks[5] = s6;
/*  439 */       marks[6] = s7;
/*  440 */       marks[7] = s8;
/*  441 */       marks[8] = s9;
/*  442 */       marks[9] = s10;
/*  443 */       marks[10] = s11;
/*  444 */       marks[11] = s12;
/*  445 */       String[] grades = new String[12];
/*  446 */       for (int a = 0; a < 12; a++) {
/*  447 */         String mark = marks[a];
/*      */         try
/*      */         {
/*  450 */           mrk = Integer.parseInt(mark);
/*  451 */           grades[a] = grade(mrk);
/*      */         }
/*      */         catch (Exception e) {
/*  454 */           int mrk = 0;
/*  455 */           grades[a] = grade(mrk);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  460 */       String g1 = grades[0];
/*  461 */       String g2 = grades[1];
/*  462 */       String g3 = grades[2];
/*  463 */       String g4 = grades[3];
/*  464 */       String g5 = grades[4];
/*  465 */       String g6 = grades[5];
/*  466 */       String g7 = grades[6];
/*  467 */       String g8 = grades[7];
/*  468 */       String g9 = grades[8];
/*  469 */       String g10 = grades[9];
/*  470 */       String g11 = grades[10];
/*  471 */       String g12 = grades[11];
/*      */ 
/*  473 */       int exam = Integer.parseInt(examno);
/*  474 */       int admn = Integer.parseInt(adm);
/*  475 */       String sql = "select * from grade where examno='" + exam + "'and admno=" + admn;
/*  476 */       Statement st = mycon.createStatement();
/*  477 */       ResultSet rs = st.executeQuery(sql);
/*  478 */       rs.next();
/*      */       try {
/*  480 */         int a = rs.getInt("examno");
/*      */ 
/*  482 */         PreparedStatement stmt = mycon.prepareStatement("update grade set examno=?,grade=?,grade1=?,grade2=?,grade3=?,grade4=?,grade5=?,grade6=?,grade7=?,grade8=?,grade9=?,grade10=?,grade11=? ,admno=? where examno='" + exam + "' and admno=" + admn);
/*      */ 
/*  485 */         stmt.setInt(1, a);
/*  486 */         stmt.setString(2, g1);
/*  487 */         stmt.setString(3, g2);
/*  488 */         stmt.setString(4, g3);
/*  489 */         stmt.setString(5, g4);
/*  490 */         stmt.setString(6, g5);
/*  491 */         stmt.setString(7, g6);
/*  492 */         stmt.setString(8, g7);
/*  493 */         stmt.setString(9, g8);
/*  494 */         stmt.setString(10, g9);
/*  495 */         stmt.setString(11, g10);
/*  496 */         stmt.setString(12, g11);
/*  497 */         stmt.setString(13, g12);
/*  498 */         stmt.setInt(14, admn);
/*  499 */         stmt.executeUpdate();
/*      */ 
/*  501 */         stmt.executeUpdate();
/*      */       }
/*      */       catch (Exception t)
/*      */       {
/*  507 */         t.printStackTrace();
/*  508 */         PreparedStatement stmt = mycon.prepareStatement("INSERT into grade values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
/*      */ 
/*  510 */         stmt.setInt(1, exam);
/*  511 */         stmt.setString(2, g1);
/*  512 */         stmt.setString(3, g2);
/*  513 */         stmt.setString(4, g3);
/*  514 */         stmt.setString(5, g4);
/*  515 */         stmt.setString(6, g5);
/*  516 */         stmt.setString(7, g6);
/*  517 */         stmt.setString(8, g7);
/*  518 */         stmt.setString(9, g8);
/*  519 */         stmt.setString(10, g9);
/*  520 */         stmt.setString(11, g10);
/*  521 */         stmt.setString(12, g11);
/*  522 */         stmt.setString(13, g12);
/*  523 */         stmt.setInt(14, admn);
/*  524 */         stmt.executeUpdate();
/*      */       }
/*      */     }
/*      */     catch (SQLException ex) {
/*  528 */       Logger.getLogger(examstud.class.getName()).log(Level.SEVERE, null, ex);
/*      */     } catch (ClassNotFoundException ex) {
/*  530 */       Logger.getLogger(examstud.class.getName()).log(Level.SEVERE, null, ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void initComponents()
/*      */   {
/*  541 */     this.pnlheader = new JPanel();
/*  542 */     this.lblheader = new JLabel();
/*  543 */     this.pnlexamdetails = new JPanel();
/*  544 */     this.lblflatnumber1 = new JLabel();
/*  545 */     this.lblflatname1 = new JLabel();
/*  546 */     this.lblagentno1 = new JLabel();
/*  547 */     this.txtyr = new JTextField();
/*  548 */     this.lblagentno3 = new JLabel();
/*  549 */     this.lblagentno4 = new JLabel();
/*  550 */     this.txtstream = new JTextField();
/*  551 */     this.lblflatnumber2 = new JLabel();
/*  552 */     this.txtexamno = new JTextField();
/*  553 */     this.txtentry = new JTextField();
/*  554 */     this.lblagentno5 = new JLabel();
/*  555 */     this.txtexamtype = new JComboBox();
/*  556 */     this.txttrm = new JComboBox();
/*  557 */     this.txtclass = new JComboBox();
/*  558 */     this.btnsave = new JButton();
/*  559 */     this.txtyear = new JTextField();
/*  560 */     this.lblflatnumber3 = new JLabel();
/*  561 */     this.btnfindall = new JButton();
/*  562 */     this.bttnew = new JButton();
/*  563 */     this.pnlscores = new JTabbedPane();
/*  564 */     this.jScrollPane5 = new JScrollPane();
/*  565 */     this.openertbl = new JTable();
/*  566 */     this.jScrollPane6 = new JScrollPane();
/*  567 */     this.midtbl = new JTable();
/*  568 */     this.jScrollPane7 = new JScrollPane();
/*  569 */     this.endtbl = new JTable();
/*  570 */     this.jScrollPane1 = new JScrollPane();
/*  571 */     this.othertbl = new JTable();
/*  572 */     this.jButton1 = new JButton();
/*      */ 
/*  574 */     setClosable(true);
/*  575 */     setIconifiable(true);
/*  576 */     setMaximizable(true);
/*  577 */     setResizable(true);
/*  578 */     setTitle("Record Scores");
/*  579 */     addInternalFrameListener(new InternalFrameListener() {
/*      */       public void internalFrameActivated(InternalFrameEvent evt) {
/*      */       }
/*      */       public void internalFrameClosed(InternalFrameEvent evt) {
/*      */       }
/*      */       public void internalFrameClosing(InternalFrameEvent evt) {
/*  585 */         examstud.this.formInternalFrameClosing(evt);
/*      */       }
/*      */ 
/*      */       public void internalFrameDeactivated(InternalFrameEvent evt)
/*      */       {
/*      */       }
/*      */ 
/*      */       public void internalFrameDeiconified(InternalFrameEvent evt)
/*      */       {
/*      */       }
/*      */ 
/*      */       public void internalFrameIconified(InternalFrameEvent evt)
/*      */       {
/*      */       }
/*      */ 
/*      */       public void internalFrameOpened(InternalFrameEvent evt)
/*      */       {
/*      */       }
/*      */     });
/*  597 */     this.pnlheader.setBackground(new Color(204, 204, 255));
/*  598 */     this.pnlheader.setBorder(BorderFactory.createBevelBorder(0));
/*  599 */     this.pnlheader.setName("headerpanel");
/*  600 */     this.pnlheader.setRequestFocusEnabled(false);
/*      */ 
/*  602 */     this.lblheader.setFont(new Font("Traditional Arabic", 0, 24));
/*  603 */     this.lblheader.setHorizontalAlignment(0);
/*  604 */     this.lblheader.setText("Exam-Scores Data Entry Form");
/*  605 */     this.lblheader.setToolTipText("");
/*  606 */     this.lblheader.setVerticalAlignment(1);
/*  607 */     this.lblheader.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
/*  608 */     this.lblheader.setEnabled(false);
/*  609 */     this.lblheader.setName("lblheader");
/*      */ 
/*  611 */     GroupLayout pnlheaderLayout = new GroupLayout(this.pnlheader);
/*  612 */     this.pnlheader.setLayout(pnlheaderLayout);
/*  613 */     pnlheaderLayout.setHorizontalGroup(pnlheaderLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(pnlheaderLayout.createSequentialGroup().addContainerGap().addComponent(this.lblheader, -1, 995, 32767).addContainerGap()));
/*      */ 
/*  620 */     pnlheaderLayout.setVerticalGroup(pnlheaderLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(pnlheaderLayout.createSequentialGroup().addContainerGap().addComponent(this.lblheader).addContainerGap(-1, 32767)));
/*      */ 
/*  628 */     this.pnlexamdetails.setBorder(BorderFactory.createTitledBorder(null, "Exam Details", 0, 0, new Font("Traditional Arabic", 0, 18)));
/*      */ 
/*  630 */     this.lblflatnumber1.setFont(new Font("Traditional Arabic", 0, 18));
/*  631 */     this.lblflatnumber1.setText("Exam Type ");
/*  632 */     this.lblflatnumber1.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*      */ 
/*  634 */     this.lblflatname1.setFont(new Font("Traditional Arabic", 0, 18));
/*  635 */     this.lblflatname1.setText("Year");
/*  636 */     this.lblflatname1.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*      */ 
/*  638 */     this.lblagentno1.setFont(new Font("Traditional Arabic", 0, 18));
/*  639 */     this.lblagentno1.setText("Term");
/*  640 */     this.lblagentno1.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*      */ 
/*  642 */     this.lblagentno3.setFont(new Font("Traditional Arabic", 0, 18));
/*  643 */     this.lblagentno3.setText("Stream");
/*  644 */     this.lblagentno3.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*      */ 
/*  646 */     this.lblagentno4.setFont(new Font("Traditional Arabic", 0, 18));
/*  647 */     this.lblagentno4.setText("Class");
/*  648 */     this.lblagentno4.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*      */ 
/*  650 */     this.txtstream.setToolTipText("Please press enter after input to populate the grid");
/*  651 */     this.txtstream.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  653 */         examstud.this.txtstreamActionPerformed(evt);
/*      */       }
/*      */     });
/*  657 */     this.lblflatnumber2.setFont(new Font("Traditional Arabic", 0, 18));
/*  658 */     this.lblflatnumber2.setText("Exam Number ");
/*  659 */     this.lblflatnumber2.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*      */ 
/*  661 */     this.txtexamno.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  663 */         examstud.this.txtexamnoActionPerformed(evt);
/*      */       }
/*      */     });
/*  667 */     this.lblagentno5.setFont(new Font("Traditional Arabic", 0, 18));
/*  668 */     this.lblagentno5.setText("Entry Students");
/*  669 */     this.lblagentno5.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*      */ 
/*  671 */     this.txtexamtype.setModel(new DefaultComboBoxModel(new String[] { "", "Opener Exam", "Midterm Exam", "Endterm Exam", "Other Exams" }));
/*  672 */     this.txtexamtype.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  674 */         examstud.this.txtexamtypeActionPerformed(evt);
/*      */       }
/*      */     });
/*  678 */     this.txttrm.setModel(new DefaultComboBoxModel(new String[] { "", "1", "2", "3", "" }));
/*      */ 
/*  680 */     this.txtclass.setModel(new DefaultComboBoxModel(new String[] { " ", "1", "2", "3", "4", " " }));
/*  681 */     this.txtclass.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  683 */         examstud.this.txtclassActionPerformed(evt);
/*      */       }
/*      */     });
/*  687 */     GroupLayout pnlexamdetailsLayout = new GroupLayout(this.pnlexamdetails);
/*  688 */     this.pnlexamdetails.setLayout(pnlexamdetailsLayout);
/*  689 */     pnlexamdetailsLayout.setHorizontalGroup(pnlexamdetailsLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, pnlexamdetailsLayout.createSequentialGroup().addContainerGap().addGroup(pnlexamdetailsLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.lblflatnumber1, -1, -1, 32767).addComponent(this.lblagentno1, -1, 188, 32767).addComponent(this.lblflatnumber2, -1, -1, 32767).addComponent(this.lblflatname1, -1, -1, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(pnlexamdetailsLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(pnlexamdetailsLayout.createSequentialGroup().addGap(27, 27, 27).addGroup(pnlexamdetailsLayout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.txtexamtype, GroupLayout.Alignment.LEADING, 0, -1, 32767).addComponent(this.txtexamno, GroupLayout.Alignment.LEADING, -1, 221, 32767))).addGroup(GroupLayout.Alignment.TRAILING, pnlexamdetailsLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.txtyr, GroupLayout.Alignment.TRAILING).addComponent(this.txttrm, GroupLayout.Alignment.TRAILING, 0, 223, 32767))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 59, 32767).addGroup(pnlexamdetailsLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.lblagentno3, -1, -1, 32767).addComponent(this.lblagentno5, -1, 182, 32767).addComponent(this.lblagentno4, -1, -1, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 33, 32767).addGroup(pnlexamdetailsLayout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.txtentry).addComponent(this.txtstream).addComponent(this.txtclass, 0, 218, 32767)).addContainerGap()));
/*      */ 
/*  720 */     pnlexamdetailsLayout.setVerticalGroup(pnlexamdetailsLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(pnlexamdetailsLayout.createSequentialGroup().addGroup(pnlexamdetailsLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(pnlexamdetailsLayout.createSequentialGroup().addGroup(pnlexamdetailsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.lblflatnumber2, -2, 22, -2).addComponent(this.txtexamno, -2, -1, -2)).addGap(17, 17, 17).addGroup(pnlexamdetailsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.lblflatnumber1, -2, 22, -2).addComponent(this.txtexamtype, -2, 27, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(pnlexamdetailsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.lblflatname1, -2, 22, -2).addComponent(this.txtyr, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(pnlexamdetailsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.lblagentno1, -2, 22, -2).addComponent(this.txttrm, -2, 25, -2))).addGroup(pnlexamdetailsLayout.createSequentialGroup().addContainerGap().addGroup(pnlexamdetailsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.lblagentno4, -2, 22, -2).addComponent(this.txtclass, -2, 28, -2)).addGap(18, 18, 18).addGroup(pnlexamdetailsLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.lblagentno3, -2, 22, -2).addComponent(this.txtstream, -2, -1, -2)).addGap(18, 18, 18).addGroup(pnlexamdetailsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtentry, -2, -1, -2).addComponent(this.lblagentno5, -2, 22, -2)))).addGap(171, 171, 171)));
/*      */ 
/*  756 */     this.btnsave.setIcon(new ImageIcon(getClass().getResource("/myschool/resources/Floppy-Small-icon.png")));
/*  757 */     this.btnsave.setText("Save  Record");
/*  758 */     this.btnsave.setHorizontalAlignment(2);
/*  759 */     this.btnsave.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/*  761 */         examstud.this.btnsaveStateChanged(evt);
/*      */       }
/*      */     });
/*  764 */     this.btnsave.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  766 */         examstud.this.btnsaveActionPerformed(evt);
/*      */       }
/*      */     });
/*  770 */     this.txtyear.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  772 */         examstud.this.txtyearActionPerformed(evt);
/*      */       }
/*      */     });
/*  776 */     this.lblflatnumber3.setFont(new Font("Traditional Arabic", 0, 18));
/*  777 */     this.lblflatnumber3.setText("Exam no");
/*  778 */     this.lblflatnumber3.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*      */ 
/*  780 */     this.btnfindall.setText("Find Record");
/*  781 */     this.btnfindall.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  783 */         examstud.this.btnfindallActionPerformed(evt);
/*      */       }
/*      */     });
/*  787 */     this.bttnew.setText("New Record");
/*  788 */     this.bttnew.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  790 */         examstud.this.bttnewActionPerformed(evt);
/*      */       }
/*      */     });
/*  794 */     this.pnlscores.setBorder(BorderFactory.createTitledBorder(null, "Scores", 0, 0, new Font("Traditional Arabic", 0, 18)));
/*      */ 
/*  796 */     this.openertbl.setModel(new DefaultTableModel(new Object[][] { { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null } }, new String[] { "ExamNo", "Admno", "S/Name ", "Eng ", "Kisw", "Maths", "Bio", "Chem", "Phyc", "Histo", "CRE", "Geog", "B/studies", "Comp", "Agric" })
/*      */     {
/*  858 */       boolean[] canEdit = { false, false, false, true, true, true, true, true, true, true, true, true, true, true, true };
/*      */ 
/*      */       public boolean isCellEditable(int rowIndex, int columnIndex)
/*      */       {
/*  863 */         return this.canEdit[columnIndex];
/*      */       }
/*      */     });
/*  866 */     this.openertbl.setColumnSelectionAllowed(true);
/*  867 */     this.jScrollPane5.setViewportView(this.openertbl);
/*      */ 
/*  869 */     this.pnlscores.addTab("Opener Exam ", this.jScrollPane5);
/*      */ 
/*  871 */     this.midtbl.setModel(new DefaultTableModel(new Object[][] { { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null } }, new String[] { "ExamNo", "Admno", "S/Name", "Eng ", "Kisw", "Maths", "Bio", "Chem", "Phyc", "Histo", "CRE", "Geog", "B/studies", "Comp", "Agric" })
/*      */     {
/*  933 */       boolean[] canEdit = { false, false, false, true, true, true, true, true, true, true, true, true, true, true, true };
/*      */ 
/*      */       public boolean isCellEditable(int rowIndex, int columnIndex)
/*      */       {
/*  938 */         return this.canEdit[columnIndex];
/*      */       }
/*      */     });
/*  941 */     this.midtbl.setColumnSelectionAllowed(true);
/*  942 */     this.jScrollPane6.setViewportView(this.midtbl);
/*      */ 
/*  944 */     this.pnlscores.addTab("Midterm Exam", this.jScrollPane6);
/*      */ 
/*  946 */     this.endtbl.setModel(new DefaultTableModel(new Object[][] { { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null } }, new String[] { "ExamNo", "Admno", "S/Name", "Eng ", "Kisw", "Maths", "Bio", "Chem", "Phyc", "Histo", "CRE", "Geog", "B/studies", "Comp", "Agric" })
/*      */     {
/* 1008 */       boolean[] canEdit = { false, false, false, true, true, true, true, true, true, true, true, true, true, true, true };
/*      */ 
/*      */       public boolean isCellEditable(int rowIndex, int columnIndex)
/*      */       {
/* 1013 */         return this.canEdit[columnIndex];
/*      */       }
/*      */     });
/* 1016 */     this.endtbl.setColumnSelectionAllowed(true);
/* 1017 */     this.jScrollPane7.setViewportView(this.endtbl);
/*      */ 
/* 1019 */     this.pnlscores.addTab("Endterm Exam", this.jScrollPane7);
/*      */ 
/* 1021 */     this.othertbl.setModel(new DefaultTableModel(new Object[][] { { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null } }, new String[] { "ExamNo", "Admno", "S/Name", "Eng ", "Kisw", "Maths", "Bio", "Chem", "Phyc", "Histo", "CRE", "Geog", "B/studies", "Comp", "Agric" })
/*      */     {
/* 1083 */       boolean[] canEdit = { false, false, false, true, true, true, true, true, true, true, true, true, true, true, true };
/*      */ 
/*      */       public boolean isCellEditable(int rowIndex, int columnIndex)
/*      */       {
/* 1088 */         return this.canEdit[columnIndex];
/*      */       }
/*      */     });
/* 1091 */     this.othertbl.setColumnSelectionAllowed(true);
/* 1092 */     this.jScrollPane1.setViewportView(this.othertbl);
/*      */ 
/* 1094 */     this.pnlscores.addTab("Other Exams", this.jScrollPane1);
/*      */ 
/* 1096 */     this.jButton1.setIcon(new ImageIcon(getClass().getResource("/myschool/resources/Actions-document-edit-icon.png")));
/* 1097 */     this.jButton1.setText("Make Changes");
/* 1098 */     this.jButton1.setHorizontalAlignment(2);
/* 1099 */     this.jButton1.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/* 1101 */         examstud.this.jButton1StateChanged(evt);
/*      */       }
/*      */     });
/* 1104 */     this.jButton1.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1106 */         examstud.this.jButton1ActionPerformed(evt);
/*      */       }
/*      */     });
/* 1110 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 1111 */     getContentPane().setLayout(layout);
/* 1112 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup().addContainerGap().addComponent(this.pnlscores, -1, 1009, 32767)).addComponent(this.pnlheader, GroupLayout.Alignment.LEADING, -2, -1, -2).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.lblflatnumber3, -2, 228, -2).addGap(18, 18, 18).addComponent(this.txtyear, -2, 198, -2).addGap(46, 46, 46).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.bttnew, -1, 215, 32767).addComponent(this.btnfindall, -1, 215, 32767)).addGap(121, 121, 121).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.btnsave, -1, -1, 32767).addComponent(this.jButton1, -1, 183, 32767))).addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup().addContainerGap().addComponent(this.pnlexamdetails, -2, -1, -2))).addContainerGap()));
/*      */ 
/* 1138 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.pnlheader, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.pnlexamdetails, -2, 216, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.btnfindall, GroupLayout.Alignment.LEADING, -1, -1, 32767).addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup().addGap(13, 13, 13).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtyear, -2, 34, -2).addComponent(this.lblflatnumber3)))).addComponent(this.jButton1, 0, 0, 32767)).addGap(18, 18, 18).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.btnsave, -2, 45, -2).addComponent(this.bttnew, -1, -1, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.pnlscores, -2, 360, -2)));
/*      */ 
/* 1162 */     pack();
/*      */   }
/*      */ 
/*      */   private void txtexamnoActionPerformed(ActionEvent evt) {
/* 1166 */     spop();
/*      */   }
/*      */ 
/*      */   private void txtexamtypeActionPerformed(ActionEvent evt) {
/* 1170 */     int type = this.txtexamtype.getSelectedIndex();
/* 1171 */     if (type == 1) {
/* 1172 */       this.openertbl.show();
/* 1173 */       this.midtbl.hide();
/* 1174 */       this.endtbl.hide();
/* 1175 */       this.othertbl.hide();
/* 1176 */       this.pnlscores.setSelectedIndex(0);
/* 1177 */     } else if (type == 2) {
/* 1178 */       this.openertbl.hide();
/* 1179 */       this.endtbl.hide();
/* 1180 */       this.othertbl.hide();
/* 1181 */       this.midtbl.show();
/* 1182 */       this.pnlscores.setSelectedIndex(1);
/* 1183 */     } else if (type == 3) {
/* 1184 */       this.openertbl.hide();
/* 1185 */       this.midtbl.hide();
/* 1186 */       this.othertbl.hide();
/* 1187 */       this.endtbl.show();
/* 1188 */       this.pnlscores.setSelectedIndex(2);
/*      */     } else {
/* 1190 */       this.openertbl.hide();
/* 1191 */       this.midtbl.hide();
/* 1192 */       this.endtbl.hide();
/* 1193 */       this.othertbl.show();
/* 1194 */       this.pnlscores.setSelectedIndex(3);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void btnsaveActionPerformed(ActionEvent evt)
/*      */   {
/*      */     try
/*      */     {
/*      */       try
/*      */       {
/* 1204 */         int r = 0;
/* 1205 */         int last = 0;
/*      */ 
/* 1207 */         last = Integer.parseInt(this.txtentry.getText());
/*      */ 
/* 1209 */         String exam = (String)this.txtexamtype.getSelectedItem();
/* 1210 */         int clas = Integer.parseInt((String)this.txtclass.getSelectedItem());
/* 1211 */         String stream = this.txtstream.getText();
/* 1212 */         int trm = Integer.parseInt((String)this.txttrm.getSelectedItem());
/* 1213 */         int yr = Integer.parseInt(this.txtyr.getText());
/* 1214 */         int no = Integer.parseInt(this.txtexamno.getText());
/* 1215 */         int ent = Integer.parseInt(this.txtentry.getText());
/*      */ 
/* 1218 */         Class.forName("com.mysql.jdbc.Driver");
/* 1219 */         Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/* 1220 */         PreparedStatement stmt = conn.prepareStatement("INSERT into exam values(?,?,?,?,?,?,?)");
/*      */ 
/* 1222 */         stmt.setString(1, exam);
/* 1223 */         stmt.setInt(2, clas);
/* 1224 */         stmt.setString(3, stream);
/* 1225 */         stmt.setInt(4, trm);
/* 1226 */         stmt.setInt(5, yr);
/* 1227 */         stmt.setInt(6, no);
/* 1228 */         stmt.setInt(7, ent);
/* 1229 */         stmt.executeUpdate();
/*      */ 
/* 1231 */         Class.forName("com.mysql.jdbc.Driver");
/* 1232 */         Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/* 1233 */         String z = (String)this.txtexamtype.getSelectedItem();
/* 1234 */         String a = null;
/*      */ 
/* 1236 */         int admno = 0;
/* 1237 */         String e = null;
/* 1238 */         int examno = 0;
/*      */ 
/* 1240 */         int comp = 0; int eng = 0; int kis = 0; int math = 0; int bio = 0; int chem = 0; int phyc = 0; int histo = 0; int cre = 0; int geog = 0; int bstudies = 0; int agri = 0;
/* 1241 */         while (r < last) {
/* 1242 */           if (z.contains("Opener")) {
/* 1243 */             a = "" + this.openertbl.getValueAt(r, 1);
/*      */ 
/* 1245 */             admno = Integer.parseInt(a);
/* 1246 */             admno = Integer.parseInt(a);
/*      */ 
/* 1248 */             e = "" + this.openertbl.getValueAt(r, 0);
/* 1249 */             examno = Integer.parseInt(e);
/* 1250 */             String ag = (String)this.openertbl.getValueAt(r, 14);
/* 1251 */             String en = "" + this.openertbl.getValueAt(r, 3);
/* 1252 */             String ks = "" + this.openertbl.getValueAt(r, 4);
/* 1253 */             String mt = "" + this.openertbl.getValueAt(r, 5);
/* 1254 */             String bo = "" + this.openertbl.getValueAt(r, 6);
/* 1255 */             String cm = "" + this.openertbl.getValueAt(r, 7);
/* 1256 */             String ph = "" + this.openertbl.getValueAt(r, 8);
/* 1257 */             String hs = "" + this.openertbl.getValueAt(r, 9);
/* 1258 */             String cr = "" + this.openertbl.getValueAt(r, 10);
/* 1259 */             String go = "" + this.openertbl.getValueAt(r, 11);
/* 1260 */             String bs = "" + this.openertbl.getValueAt(r, 12);
/* 1261 */             String cmp = "" + this.openertbl.getValueAt(r, 13);
/*      */ 
/* 1263 */             System.err.println(ag);
/* 1264 */             if (en == null) { en = "0"; System.out.println(en); }
/* 1265 */             if (ks == null) { ks = "0"; System.out.println(ks); }
/* 1266 */             if (mt == null) { mt = "0"; System.out.println(mt); }
/* 1267 */             if (bo == null) { bo = "0"; System.out.println(bo); }
/* 1268 */             if (cm == null) { cm = "0"; System.out.println(cm); }
/* 1269 */             if (ph == null) { ph = "0"; System.out.println(ph); }
/* 1270 */             if (hs == null) { hs = "0"; System.out.println(hs); }
/* 1271 */             if (cr == null) { cr = "0"; System.out.println(cr); }
/* 1272 */             if (go == null) { go = "0"; System.out.println(go); }
/* 1273 */             if (bs == null) { bs = "0"; System.out.println(bs); }
/* 1274 */             if (cmp == null) { cmp = "0"; System.out.println(cmp); }
/* 1275 */             if (ag == null) { ag = "0"; System.out.println(ag);
/*      */             }
/*      */             try
/*      */             {
/* 1279 */               comp = Integer.parseInt(cmp); } catch (Exception y) { comp = 0; cmp = "0"; } try {
/* 1280 */               eng = Integer.parseInt(en); } catch (Exception y) { eng = 0; en = "0"; } try {
/* 1281 */               kis = Integer.parseInt(ks); } catch (Exception y) { kis = 0; ks = "0"; } try {
/* 1282 */               math = Integer.parseInt(mt); } catch (Exception y) { math = 0; mt = "0"; } try {
/* 1283 */               bio = Integer.parseInt(bo); } catch (Exception y) { bio = 0; bo = "0"; } try {
/* 1284 */               chem = Integer.parseInt(cm); } catch (Exception y) { chem = 0; cm = "0"; } try {
/* 1285 */               phyc = Integer.parseInt(ph); } catch (Exception y) { phyc = 0; ph = "0"; } try {
/* 1286 */               histo = Integer.parseInt(hs); } catch (Exception y) { histo = 0; hs = "0"; } try {
/* 1287 */               cre = Integer.parseInt(cr); } catch (Exception y) { cre = 0; cr = "0"; } try {
/* 1288 */               geog = Integer.parseInt(go); } catch (Exception y) { geog = 0; go = "0"; } try {
/* 1289 */               bstudies = Integer.parseInt(bs); } catch (Exception y) { bstudies = 0; bs = "0"; } try {
/* 1290 */               agri = Integer.parseInt(ag); } catch (Exception y) { agri = 0; ag = "0";
/*      */             }
/* 1292 */             add(en, ks, mt, bo, cm, ph, hs, cr, go, bs, cmp, ag);
/* 1293 */             grde(e, a, en, ks, mt, bo, cm, ph, hs, cr, go, bs, cmp, ag);
/*      */ 
/* 1295 */             if ((eng > 100) || (eng < 0)) eng = Integer.parseInt("XX");
/* 1296 */             if ((kis > 100) || (kis < 0)) kis = Integer.parseInt("XX");
/* 1297 */             if ((math > 100) || (math < 0)) math = Integer.parseInt("XX");
/* 1298 */             if ((bio > 100) || (bio < 0)) bio = Integer.parseInt("XX");
/* 1299 */             if ((chem > 100) || (chem < 0)) chem = Integer.parseInt("XX");
/* 1300 */             if ((phyc > 100) || (phyc < 0)) phyc = Integer.parseInt("XX");
/* 1301 */             if ((histo > 100) || (histo < 0)) histo = Integer.parseInt("XX");
/* 1302 */             if ((cre > 100) || (cre < 0)) cre = Integer.parseInt("XX");
/* 1303 */             if ((geog > 100) || (geog < 0)) geog = Integer.parseInt("XX");
/* 1304 */             if ((bstudies > 100) || (bstudies < 0)) bstudies = Integer.parseInt("XX");
/* 1305 */             if ((comp > 100) || (comp < 0)) comp = Integer.parseInt("XX");
/* 1306 */             if ((agri > 100) || (agri < 0)) agri = Integer.parseInt("XX");
/*      */           }
/* 1308 */           else if (z.contains("Midterm"))
/*      */           {
/* 1311 */             a = "" + this.midtbl.getValueAt(r, 1);
/*      */ 
/* 1313 */             admno = Integer.parseInt(a);
/* 1314 */             e = "" + this.midtbl.getValueAt(r, 0);
/* 1315 */             examno = Integer.parseInt(e);
/*      */ 
/* 1317 */             String en = "" + this.midtbl.getValueAt(r, 3);
/* 1318 */             String ks = "" + this.midtbl.getValueAt(r, 4);
/* 1319 */             String mt = "" + this.midtbl.getValueAt(r, 5);
/* 1320 */             String bo = "" + this.midtbl.getValueAt(r, 6);
/* 1321 */             String cm = "" + this.midtbl.getValueAt(r, 7);
/* 1322 */             String ph = "" + this.midtbl.getValueAt(r, 8);
/* 1323 */             String hs = "" + this.midtbl.getValueAt(r, 9);
/* 1324 */             String cr = "" + this.midtbl.getValueAt(r, 10);
/* 1325 */             String go = "" + this.midtbl.getValueAt(r, 11);
/* 1326 */             String bs = "" + this.midtbl.getValueAt(r, 12);
/* 1327 */             String cmp = "" + this.midtbl.getValueAt(r, 13);
/* 1328 */             String ag = "" + this.midtbl.getValueAt(r, 14);
/* 1329 */             if (en == null) en = "0";
/* 1330 */             if (ks == null) ks = "0";
/* 1331 */             if (mt == null) mt = "0";
/* 1332 */             if (bo == null) bo = "0";
/* 1333 */             if (cm == null) cm = "0";
/* 1334 */             if (ph == null) ph = "0";
/* 1335 */             if (hs == null) hs = "0";
/* 1336 */             if (cr == null) cr = "0";
/* 1337 */             if (go == null) go = "0";
/* 1338 */             if (bs == null) bs = "0";
/* 1339 */             if (cmp == null) cmp = "0";
/* 1340 */             if (ag == null) ag = "0"; try {
/* 1341 */               comp = Integer.parseInt(cmp); } catch (Exception y) { comp = 0; } try {
/* 1342 */               eng = Integer.parseInt(en); } catch (Exception y) { eng = 0; } try {
/* 1343 */               kis = Integer.parseInt(ks); } catch (Exception y) { kis = 0; } try {
/* 1344 */               math = Integer.parseInt(mt); } catch (Exception y) { math = 0; } try {
/* 1345 */               bio = Integer.parseInt(bo); } catch (Exception y) { bio = 0; } try {
/* 1346 */               chem = Integer.parseInt(cm); } catch (Exception y) { chem = 0; } try {
/* 1347 */               phyc = Integer.parseInt(ph); } catch (Exception y) { phyc = 0; } try {
/* 1348 */               histo = Integer.parseInt(hs); } catch (Exception y) { histo = 0; } try {
/* 1349 */               cre = Integer.parseInt(cr); } catch (Exception y) { cre = 0; } try {
/* 1350 */               geog = Integer.parseInt(go); } catch (Exception y) { geog = 0; } try {
/* 1351 */               bstudies = Integer.parseInt(bs); } catch (Exception y) { bstudies = 0; } try {
/* 1352 */               agri = Integer.parseInt(ag); } catch (Exception y) { agri = 0; }
/*      */ 
/* 1354 */             add(en, ks, mt, bo, cm, ph, hs, cr, go, bs, cmp, ag);
/* 1355 */             grde(e, a, en, ks, mt, bo, cm, ph, hs, cr, go, bs, cmp, ag);
/*      */ 
/* 1357 */             if ((eng > 100) || (eng < 0)) eng = Integer.parseInt("XX");
/* 1358 */             if ((kis > 100) || (kis < 0)) kis = Integer.parseInt("XX");
/* 1359 */             if ((math > 100) || (math < 0)) math = Integer.parseInt("XX");
/* 1360 */             if ((bio > 100) || (bio < 0)) bio = Integer.parseInt("XX");
/* 1361 */             if ((chem > 100) || (chem < 0)) chem = Integer.parseInt("XX");
/* 1362 */             if ((phyc > 100) || (phyc < 0)) phyc = Integer.parseInt("XX");
/* 1363 */             if ((histo > 100) || (histo < 0)) histo = Integer.parseInt("XX");
/* 1364 */             if ((cre > 100) || (cre < 0)) cre = Integer.parseInt("XX");
/* 1365 */             if ((geog > 100) || (geog < 0)) geog = Integer.parseInt("XX");
/* 1366 */             if ((bstudies > 100) || (bstudies < 0)) bstudies = Integer.parseInt("XX");
/* 1367 */             if ((comp > 100) || (comp < 0)) comp = Integer.parseInt("XX");
/* 1368 */             if ((agri > 100) || (agri < 0)) agri = Integer.parseInt("XX");
/*      */           }
/* 1370 */           else if (z.contains("Endterm"))
/*      */           {
/* 1372 */             a = "" + this.endtbl.getValueAt(r, 1);
/*      */ 
/* 1374 */             admno = Integer.parseInt(a);
/* 1375 */             e = "" + this.endtbl.getValueAt(r, 0);
/* 1376 */             examno = Integer.parseInt(e);
/* 1377 */             String en = "" + this.endtbl.getValueAt(r, 3);
/* 1378 */             String ks = "" + this.endtbl.getValueAt(r, 4);
/* 1379 */             String mt = "" + this.endtbl.getValueAt(r, 5);
/* 1380 */             String bo = "" + this.endtbl.getValueAt(r, 6);
/* 1381 */             String cm = "" + this.endtbl.getValueAt(r, 7);
/* 1382 */             String ph = "" + this.endtbl.getValueAt(r, 8);
/* 1383 */             String hs = "" + this.endtbl.getValueAt(r, 9);
/* 1384 */             String cr = "" + this.endtbl.getValueAt(r, 10);
/* 1385 */             String go = "" + this.endtbl.getValueAt(r, 11);
/* 1386 */             String bs = "" + this.endtbl.getValueAt(r, 12);
/* 1387 */             String cmp = "" + this.endtbl.getValueAt(r, 13);
/* 1388 */             String ag = "" + this.endtbl.getValueAt(r, 14);
/* 1389 */             if (en == null) en = "0";
/* 1390 */             if (ks == null) ks = "0";
/* 1391 */             if (mt == null) mt = "0";
/* 1392 */             if (bo == null) bo = "0";
/* 1393 */             if (cm == null) cm = "0";
/* 1394 */             if (ph == null) ph = "0";
/* 1395 */             if (hs == null) hs = "0";
/* 1396 */             if (cr == null) cr = "0";
/* 1397 */             if (go == null) go = "0";
/* 1398 */             if (bs == null) bs = "0";
/* 1399 */             if (cmp == null) cmp = "0";
/* 1400 */             if (ag == null) ag = "0";
/* 1401 */             admno = Integer.parseInt(a);
/* 1402 */             examno = Integer.parseInt(e);
/*      */             try {
/* 1404 */               comp = Integer.parseInt(cmp); } catch (Exception y) { comp = 0; } try {
/* 1405 */               eng = Integer.parseInt(en); } catch (Exception y) { eng = 0; } try {
/* 1406 */               kis = Integer.parseInt(ks); } catch (Exception y) { kis = 0; } try {
/* 1407 */               math = Integer.parseInt(mt); } catch (Exception y) { math = 0; } try {
/* 1408 */               bio = Integer.parseInt(bo); } catch (Exception y) { bio = 0; } try {
/* 1409 */               chem = Integer.parseInt(cm); } catch (Exception y) { chem = 0; } try {
/* 1410 */               phyc = Integer.parseInt(ph); } catch (Exception y) { phyc = 0; } try {
/* 1411 */               histo = Integer.parseInt(hs); } catch (Exception y) { histo = 0; } try {
/* 1412 */               cre = Integer.parseInt(cr); } catch (Exception y) { cre = 0; } try {
/* 1413 */               geog = Integer.parseInt(go); } catch (Exception y) { geog = 0; } try {
/* 1414 */               bstudies = Integer.parseInt(bs); } catch (Exception y) { bstudies = 0; } try {
/* 1415 */               agri = Integer.parseInt(ag); } catch (Exception y) { agri = 0; }
/* 1416 */             add(en, ks, mt, bo, cm, ph, hs, cr, go, bs, cmp, ag);
/* 1417 */             grde(e, a, en, ks, mt, bo, cm, ph, hs, cr, go, bs, cmp, ag);
/*      */ 
/* 1419 */             if ((eng > 100) || (eng < 0)) eng = Integer.parseInt("XX");
/* 1420 */             if ((kis > 100) || (kis < 0)) kis = Integer.parseInt("XX");
/* 1421 */             if ((math > 100) || (math < 0)) math = Integer.parseInt("XX");
/* 1422 */             if ((bio > 100) || (bio < 0)) bio = Integer.parseInt("XX");
/* 1423 */             if ((chem > 100) || (chem < 0)) chem = Integer.parseInt("XX");
/* 1424 */             if ((phyc > 100) || (phyc < 0)) phyc = Integer.parseInt("XX");
/* 1425 */             if ((histo > 100) || (histo < 0)) histo = Integer.parseInt("XX");
/* 1426 */             if ((cre > 100) || (cre < 0)) cre = Integer.parseInt("XX");
/* 1427 */             if ((geog > 100) || (geog < 0)) geog = Integer.parseInt("XX");
/* 1428 */             if ((bstudies > 100) || (bstudies < 0)) bstudies = Integer.parseInt("XX");
/* 1429 */             if ((comp > 100) || (comp < 0)) comp = Integer.parseInt("XX");
/* 1430 */             if ((agri > 100) || (agri < 0)) agri = Integer.parseInt("XX");
/*      */ 
/*      */           }
/* 1433 */           else if (z.contains("Other"))
/*      */           {
/* 1435 */             a = "" + this.othertbl.getValueAt(r, 1);
/* 1436 */             admno = Integer.parseInt(a);
/* 1437 */             e = "" + this.othertbl.getValueAt(r, 0);
/* 1438 */             examno = Integer.parseInt(e);
/* 1439 */             String en = "" + this.othertbl.getValueAt(r, 3);
/* 1440 */             String ks = "" + this.othertbl.getValueAt(r, 4);
/* 1441 */             String mt = "" + this.othertbl.getValueAt(r, 5);
/* 1442 */             String bo = "" + this.othertbl.getValueAt(r, 6);
/* 1443 */             String cm = "" + this.othertbl.getValueAt(r, 7);
/* 1444 */             String ph = "" + this.othertbl.getValueAt(r, 8);
/* 1445 */             String hs = "" + this.othertbl.getValueAt(r, 9);
/* 1446 */             String cr = "" + this.othertbl.getValueAt(r, 10);
/* 1447 */             String go = "" + this.othertbl.getValueAt(r, 11);
/* 1448 */             String bs = "" + this.othertbl.getValueAt(r, 12);
/* 1449 */             String cmp = "" + this.othertbl.getValueAt(r, 13);
/* 1450 */             String ag = "" + this.othertbl.getValueAt(r, 14);
/* 1451 */             if (en == null) en = "0";
/* 1452 */             if (ks == null) ks = "0";
/* 1453 */             if (mt == null) mt = "0";
/* 1454 */             if (bo == null) bo = "0";
/* 1455 */             if (cm == null) cm = "0";
/* 1456 */             if (ph == null) ph = "0";
/* 1457 */             if (hs == null) hs = "0";
/* 1458 */             if (cr == null) cr = "0";
/* 1459 */             if (go == null) go = "0";
/* 1460 */             if (bs == null) bs = "0";
/* 1461 */             if (cmp == null) cmp = "0";
/* 1462 */             if (ag == null) ag = "0";
/* 1463 */             admno = Integer.parseInt(a);
/* 1464 */             examno = Integer.parseInt(e);
/*      */             try { comp = Integer.parseInt(cmp); } catch (Exception y) { comp = 0; } try {
/* 1466 */               eng = Integer.parseInt(en); } catch (Exception y) { eng = 0; } try {
/* 1467 */               kis = Integer.parseInt(ks); } catch (Exception y) { kis = 0; } try {
/* 1468 */               math = Integer.parseInt(mt); } catch (Exception y) { math = 0; } try {
/* 1469 */               bio = Integer.parseInt(bo); } catch (Exception y) { bio = 0; } try {
/* 1470 */               chem = Integer.parseInt(cm); } catch (Exception y) { chem = 0; } try {
/* 1471 */               phyc = Integer.parseInt(ph); } catch (Exception y) { phyc = 0; } try {
/* 1472 */               histo = Integer.parseInt(hs); } catch (Exception y) { histo = 0; } try {
/* 1473 */               cre = Integer.parseInt(cr); } catch (Exception y) { cre = 0; } try {
/* 1474 */               geog = Integer.parseInt(go); } catch (Exception y) { geog = 0; } try {
/* 1475 */               bstudies = Integer.parseInt(bs); } catch (Exception y) { bstudies = 0; } try {
/* 1476 */               agri = Integer.parseInt(ag); } catch (Exception y) { agri = 0; }
/* 1477 */             add(en, ks, mt, bo, cm, ph, hs, cr, go, bs, cmp, ag);
/*      */ 
/* 1479 */             grde(e, a, en, ks, mt, bo, cm, ph, hs, cr, go, bs, cmp, ag);
/*      */ 
/* 1481 */             if ((eng > 100) || (eng < 0)) eng = Integer.parseInt("XX");
/* 1482 */             if ((kis > 100) || (kis < 0)) kis = Integer.parseInt("XX");
/* 1483 */             if ((math > 100) || (math < 0)) math = Integer.parseInt("XX");
/* 1484 */             if ((bio > 100) || (bio < 0)) bio = Integer.parseInt("XX");
/* 1485 */             if ((chem > 100) || (chem < 0)) chem = Integer.parseInt("XX");
/* 1486 */             if ((phyc > 100) || (phyc < 0)) phyc = Integer.parseInt("XX");
/* 1487 */             if ((histo > 100) || (histo < 0)) histo = Integer.parseInt("XX");
/* 1488 */             if ((cre > 100) || (cre < 0)) cre = Integer.parseInt("XX");
/* 1489 */             if ((geog > 100) || (geog < 0)) geog = Integer.parseInt("XX");
/* 1490 */             if ((bstudies > 100) || (bstudies < 0)) bstudies = Integer.parseInt("XX");
/* 1491 */             if ((comp > 100) || (comp < 0)) comp = Integer.parseInt("XX");
/* 1492 */             if ((agri > 100) || (agri < 0)) agri = Integer.parseInt("XX");
/*      */ 
/*      */           }
/*      */ 
/* 1496 */           PreparedStatement stmtt = mycon.prepareStatement("INSERT into score values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
/*      */ 
/* 1498 */           stmtt.setInt(1, admno);
/* 1499 */           stmtt.setInt(2, examno);
/* 1500 */           stmtt.setInt(3, eng);
/* 1501 */           stmtt.setInt(4, kis);
/* 1502 */           stmtt.setInt(5, math);
/* 1503 */           stmtt.setInt(6, bio);
/* 1504 */           stmtt.setInt(7, chem);
/* 1505 */           stmtt.setInt(8, phyc);
/* 1506 */           stmtt.setInt(9, histo);
/* 1507 */           stmtt.setInt(10, cre);
/* 1508 */           stmtt.setInt(11, geog);
/* 1509 */           stmtt.setInt(12, bstudies);
/* 1510 */           stmtt.setInt(13, comp);
/* 1511 */           stmtt.setInt(14, agri);
/* 1512 */           stmtt.executeUpdate();
/*      */ 
/* 1514 */           r++;
/*      */         }
/* 1516 */         JOptionPane.showMessageDialog(null, "Save operation successfull");
/*      */       } catch (Exception e) {
/* 1518 */         e.printStackTrace();
/* 1519 */         JOptionPane.showMessageDialog(null, "Save operation unsuccessfull please try again because\n" + e.getMessage() + "\n Please check all your input to ensure it is correct");
/*      */       }
/*      */     }
/*      */     catch (Exception lang)
/*      */     {
/* 1524 */       lang.printStackTrace();
/* 1525 */       JOptionPane.showMessageDialog(null, "Save operation unsuccessfull please try again because\n" + lang.getMessage() + "\n Please check all your input to ensure it is correct");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void txtyearActionPerformed(ActionEvent evt)
/*      */   {
/*      */   }
/*      */ 
/*      */   private void bttnewActionPerformed(ActionEvent evt)
/*      */   {
/* 1536 */     this.openertbl.selectAll();
/* 1537 */     this.openertbl.clearSelection();
/* 1538 */     this.midtbl.selectAll();
/* 1539 */     this.midtbl.clearSelection();
/* 1540 */     this.endtbl.selectAll();
/* 1541 */     this.endtbl.clearSelection();
/* 1542 */     this.othertbl.selectAll();
/* 1543 */     this.othertbl.clearSelection();
/* 1544 */     this.txtexamtype.setSelectedItem("");
/* 1545 */     this.txtclass.setSelectedItem("");
/* 1546 */     this.txtstream.setText("");
/* 1547 */     this.txttrm.setSelectedItem("");
/* 1548 */     this.txtyr.setText("");
/* 1549 */     populate();
/* 1550 */     this.txtexamno.setText("");
/*      */   }
/*      */ 
/*      */   private void formInternalFrameClosing(InternalFrameEvent evt)
/*      */   {
/* 1556 */     this.fm.add();
/* 1557 */     dispose();
/*      */   }
/*      */ 
/*      */   private void btnfindallActionPerformed(ActionEvent evt)
/*      */   {
/*      */     try {
/* 1563 */       int examno = Integer.parseInt(this.txtyear.getText());
/*      */ 
/* 1565 */       Class.forName("com.mysql.jdbc.Driver");
/* 1566 */       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*      */ 
/* 1568 */       Statement st = con.createStatement();
/*      */ 
/* 1570 */       String sql = "Select * from exam, score where score.examno=exam.examno and exam.examno = ?";
/*      */ 
/* 1573 */       PreparedStatement pstmnt = con.prepareStatement(sql);
/* 1574 */       pstmnt.setInt(1, examno);
/* 1575 */       ResultSet rs = pstmnt.executeQuery();
/* 1576 */       rs.next();
/* 1577 */       this.txtexamtype.setSelectedItem(rs.getString("examtype"));
/* 1578 */       this.txtclass.setSelectedItem("" + rs.getInt("class"));
/* 1579 */       this.txtstream.setText("" + rs.getString("stream"));
/* 1580 */       this.txttrm.setSelectedItem("" + rs.getInt("term"));
/* 1581 */       this.txtyr.setText("" + rs.getInt("yearofadm"));
/* 1582 */       this.txtexamno.setText("" + rs.getInt("examno"));
/* 1583 */       this.txtentry.setText("" + rs.getInt("entry"));
/*      */ 
/* 1586 */       populate();
/*      */ 
/* 1588 */       JOptionPane.showMessageDialog(null, "Record Found");
/*      */     }
/*      */     catch (SQLException ex) {
/* 1591 */       JOptionPane.showMessageDialog(null, "Record not found please try again \n Hint: you can search from the search window using admno if you cant recall the examno ");
/*      */     } catch (ClassNotFoundException ex) {
/* 1593 */       Logger.getLogger(examstud.class.getName()).log(Level.SEVERE, null, ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void jButton1ActionPerformed(ActionEvent evt)
/*      */   {
/* 1599 */     int r = 0;
/* 1600 */     int last = 0;
/*      */     try
/*      */     {
/*      */       try
/*      */       {
/* 1607 */         int examn = Integer.parseInt(this.txtyear.getText());
/*      */ 
/* 1609 */         last = Integer.parseInt(this.txtentry.getText());
/* 1610 */         String exam = (String)this.txtexamtype.getSelectedItem();
/* 1611 */         int clas = Integer.parseInt((String)this.txtclass.getSelectedItem());
/* 1612 */         String stream = this.txtstream.getText();
/* 1613 */         int trm = Integer.parseInt((String)this.txttrm.getSelectedItem());
/* 1614 */         int yr = Integer.parseInt(this.txtyr.getText());
/* 1615 */         int no = Integer.parseInt(this.txtexamno.getText());
/* 1616 */         int ent = Integer.parseInt(this.txtentry.getText());
/*      */ 
/* 1619 */         Class.forName("com.mysql.jdbc.Driver");
/* 1620 */         Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/* 1621 */         PreparedStatement stmt = conn.prepareStatement("Update exam set examtype=?,class=?,stream=?,term=?,yearofadm=?,examno=?,entry=? where examno=" + examn);
/*      */ 
/* 1623 */         stmt.setString(1, exam);
/* 1624 */         stmt.setInt(2, clas);
/* 1625 */         stmt.setString(3, stream);
/* 1626 */         stmt.setInt(4, trm);
/* 1627 */         stmt.setInt(5, yr);
/* 1628 */         stmt.setInt(6, no);
/* 1629 */         stmt.setInt(7, ent);
/* 1630 */         stmt.executeUpdate();
/*      */ 
/* 1632 */         Class.forName("com.mysql.jdbc.Driver");
/* 1633 */         Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/* 1634 */         String z = (String)this.txtexamtype.getSelectedItem();
/* 1635 */         String a = null;
/*      */ 
/* 1637 */         int admno = 0;
/* 1638 */         String e = null;
/* 1639 */         int examno = 0;
/*      */ 
/* 1641 */         int comp = 0; int eng = 0; int kis = 0; int math = 0; int bio = 0; int chem = 0; int phyc = 0; int histo = 0; int cre = 0; int geog = 0; int bstudies = 0; int agri = 0;
/* 1642 */         while (r < last) {
/* 1643 */           if (z.contains("Opener")) {
/* 1644 */             a = "" + this.openertbl.getValueAt(r, 1);
/* 1645 */             admno = Integer.parseInt(a);
/* 1646 */             e = "" + this.openertbl.getValueAt(r, 0);
/* 1647 */             examno = Integer.parseInt(e);
/*      */ 
/* 1650 */             String en = "" + this.openertbl.getValueAt(r, 3);
/* 1651 */             String ks = "" + this.openertbl.getValueAt(r, 4);
/* 1652 */             String mt = "" + this.openertbl.getValueAt(r, 5);
/* 1653 */             String bo = "" + this.openertbl.getValueAt(r, 6);
/* 1654 */             String cm = "" + this.openertbl.getValueAt(r, 7);
/* 1655 */             String ph = "" + this.openertbl.getValueAt(r, 8);
/* 1656 */             String hs = "" + this.openertbl.getValueAt(r, 9);
/* 1657 */             String cr = "" + this.openertbl.getValueAt(r, 10);
/* 1658 */             String go = "" + this.openertbl.getValueAt(r, 11);
/* 1659 */             String bs = "" + this.openertbl.getValueAt(r, 12);
/* 1660 */             String cmp = "" + this.openertbl.getValueAt(r, 13);
/* 1661 */             String ag = "" + this.openertbl.getValueAt(r, 14);
/* 1662 */             if (en == null) en = "0";
/* 1663 */             if (ks == null) ks = "0";
/* 1664 */             if (mt == null) mt = "0";
/* 1665 */             if (bo == null) bo = "0";
/* 1666 */             if (cm == null) cm = "0";
/* 1667 */             if (ph == null) ph = "0";
/* 1668 */             if (hs == null) hs = "0";
/* 1669 */             if (cr == null) cr = "0";
/* 1670 */             if (go == null) go = "0";
/* 1671 */             if (bs == null) bs = "0";
/* 1672 */             if (cmp == null) cmp = "0";
/* 1673 */             if (ag == null) ag = "0";
/*      */ 
/*      */             try
/*      */             {
/* 1677 */               comp = Integer.parseInt(cmp); } catch (Exception y) { comp = 0; } try {
/* 1678 */               eng = Integer.parseInt(en); } catch (Exception y) { eng = 0; } try {
/* 1679 */               kis = Integer.parseInt(ks); } catch (Exception y) { kis = 0; } try {
/* 1680 */               math = Integer.parseInt(mt); } catch (Exception y) { math = 0; } try {
/* 1681 */               bio = Integer.parseInt(bo); } catch (Exception y) { bio = 0; } try {
/* 1682 */               chem = Integer.parseInt(cm); } catch (Exception y) { chem = 0; } try {
/* 1683 */               phyc = Integer.parseInt(ph); } catch (Exception y) { phyc = 0; } try {
/* 1684 */               histo = Integer.parseInt(hs); } catch (Exception y) { histo = 0; } try {
/* 1685 */               cre = Integer.parseInt(cr); } catch (Exception y) { cre = 0; } try {
/* 1686 */               geog = Integer.parseInt(go); } catch (Exception y) { geog = 0; } try {
/* 1687 */               bstudies = Integer.parseInt(bs); } catch (Exception y) { bstudies = 0; } try {
/* 1688 */               agri = Integer.parseInt(ag); } catch (Exception y) { agri = 0; }
/* 1689 */             add(en, ks, mt, bo, cm, ph, hs, cr, go, bs, cmp, ag);
/* 1690 */             grde(e, a, en, ks, mt, bo, cm, ph, hs, cr, go, bs, cmp, ag);
/* 1691 */             if ((eng > 100) || (eng < 0)) eng = Integer.parseInt("XX");
/* 1692 */             if ((kis > 100) || (kis < 0)) kis = Integer.parseInt("XX");
/* 1693 */             if ((math > 100) || (math < 0)) math = Integer.parseInt("XX");
/* 1694 */             if ((bio > 100) || (bio < 0)) bio = Integer.parseInt("XX");
/* 1695 */             if ((chem > 100) || (chem < 0)) chem = Integer.parseInt("XX");
/* 1696 */             if ((phyc > 100) || (phyc < 0)) phyc = Integer.parseInt("XX");
/* 1697 */             if ((histo > 100) || (histo < 0)) histo = Integer.parseInt("XX");
/* 1698 */             if ((cre > 100) || (cre < 0)) cre = Integer.parseInt("XX");
/* 1699 */             if ((geog > 100) || (geog < 0)) geog = Integer.parseInt("XX");
/* 1700 */             if ((bstudies > 100) || (bstudies < 0)) bstudies = Integer.parseInt("XX");
/* 1701 */             if ((comp > 100) || (comp < 0)) comp = Integer.parseInt("XX");
/* 1702 */             if ((agri > 100) || (agri < 0)) agri = Integer.parseInt("XX");
/*      */           }
/* 1704 */           else if (z.contains("Midterm"))
/*      */           {
/* 1707 */             a = "" + this.midtbl.getValueAt(r, 1);
/* 1708 */             admno = Integer.parseInt(a);
/* 1709 */             e = "" + this.midtbl.getValueAt(r, 0);
/* 1710 */             examno = Integer.parseInt(e);
/*      */ 
/* 1712 */             String en = "" + this.midtbl.getValueAt(r, 3);
/* 1713 */             String ks = "" + this.midtbl.getValueAt(r, 4);
/*      */ 
/* 1715 */             String mt = "" + this.midtbl.getValueAt(r, 5);
/* 1716 */             String bo = "" + this.midtbl.getValueAt(r, 6);
/* 1717 */             String cm = "" + this.midtbl.getValueAt(r, 7);
/* 1718 */             String ph = "" + this.midtbl.getValueAt(r, 8);
/* 1719 */             String hs = "" + this.midtbl.getValueAt(r, 9);
/* 1720 */             String cr = "" + this.midtbl.getValueAt(r, 10);
/* 1721 */             String go = "" + this.midtbl.getValueAt(r, 11);
/* 1722 */             String bs = "" + this.midtbl.getValueAt(r, 12);
/* 1723 */             String cmp = "" + this.midtbl.getValueAt(r, 13);
/* 1724 */             String ag = "" + this.midtbl.getValueAt(r, 14);
/* 1725 */             if (en == null) en = "0";
/* 1726 */             if (ks == null) ks = "0";
/* 1727 */             if (mt == null) mt = "0";
/* 1728 */             if (bo == null) bo = "0";
/* 1729 */             if (cm == null) cm = "0";
/* 1730 */             if (ph == null) ph = "0";
/* 1731 */             if (hs == null) hs = "0";
/* 1732 */             if (cr == null) cr = "0";
/* 1733 */             if (go == null) go = "0";
/* 1734 */             if (bs == null) bs = "0";
/* 1735 */             if (cmp == null) cmp = "0";
/* 1736 */             if (ag == null) ag = "0";
/*      */ 
/* 1739 */             admno = Integer.parseInt(a);
/* 1740 */             examno = Integer.parseInt(e);
/*      */             try { comp = Integer.parseInt(cmp); } catch (Exception y) { comp = 0; } try {
/* 1742 */               eng = Integer.parseInt(en); } catch (Exception y) { eng = 0; } try {
/* 1743 */               kis = Integer.parseInt(ks); } catch (Exception y) { kis = 0; } try {
/* 1744 */               math = Integer.parseInt(mt); } catch (Exception y) { math = 0; } try {
/* 1745 */               bio = Integer.parseInt(bo); } catch (Exception y) { bio = 0; } try {
/* 1746 */               chem = Integer.parseInt(cm); } catch (Exception y) { chem = 0; } try {
/* 1747 */               phyc = Integer.parseInt(ph); } catch (Exception y) { phyc = 0; } try {
/* 1748 */               histo = Integer.parseInt(hs); } catch (Exception y) { histo = 0; } try {
/* 1749 */               cre = Integer.parseInt(cr); } catch (Exception y) { cre = 0; } try {
/* 1750 */               geog = Integer.parseInt(go); } catch (Exception y) { geog = 0; } try {
/* 1751 */               bstudies = Integer.parseInt(bs); } catch (Exception y) { bstudies = 0; } try {
/* 1752 */               agri = Integer.parseInt(ag); } catch (Exception y) { agri = 0; }
/* 1753 */             add(en, ks, mt, bo, cm, ph, hs, cr, go, bs, cmp, ag);
/* 1754 */             grde(e, a, en, ks, mt, bo, cm, ph, hs, cr, go, bs, cmp, ag);
/* 1755 */             if ((eng > 100) || (eng < 0)) eng = Integer.parseInt("XX");
/* 1756 */             if ((kis > 100) || (kis < 0)) kis = Integer.parseInt("XX");
/* 1757 */             if ((math > 100) || (math < 0)) math = Integer.parseInt("XX");
/* 1758 */             if ((bio > 100) || (bio < 0)) bio = Integer.parseInt("XX");
/* 1759 */             if ((chem > 100) || (chem < 0)) chem = Integer.parseInt("XX");
/* 1760 */             if ((phyc > 100) || (phyc < 0)) phyc = Integer.parseInt("XX");
/* 1761 */             if ((histo > 100) || (histo < 0)) histo = Integer.parseInt("XX");
/* 1762 */             if ((cre > 100) || (cre < 0)) cre = Integer.parseInt("XX");
/* 1763 */             if ((geog > 100) || (geog < 0)) geog = Integer.parseInt("XX");
/* 1764 */             if ((bstudies > 100) || (bstudies < 0)) bstudies = Integer.parseInt("XX");
/* 1765 */             if ((comp > 100) || (comp < 0)) comp = Integer.parseInt("XX");
/* 1766 */             if ((agri > 100) || (agri < 0)) agri = Integer.parseInt("XX");
/*      */           }
/* 1768 */           else if (z.contains("Endterm"))
/*      */           {
/* 1770 */             a = "" + this.endtbl.getValueAt(r, 1);
/* 1771 */             admno = Integer.parseInt(a);
/* 1772 */             e = "" + this.endtbl.getValueAt(r, 0);
/* 1773 */             examno = Integer.parseInt(e);
/* 1774 */             String en = "" + this.endtbl.getValueAt(r, 3);
/* 1775 */             String ks = "" + this.endtbl.getValueAt(r, 4);
/* 1776 */             String mt = "" + this.endtbl.getValueAt(r, 5);
/* 1777 */             String bo = "" + this.endtbl.getValueAt(r, 6);
/* 1778 */             String cm = "" + this.endtbl.getValueAt(r, 7);
/* 1779 */             String ph = "" + this.endtbl.getValueAt(r, 8);
/* 1780 */             String hs = "" + this.endtbl.getValueAt(r, 9);
/* 1781 */             String cr = "" + this.endtbl.getValueAt(r, 10);
/* 1782 */             String go = "" + this.endtbl.getValueAt(r, 11);
/* 1783 */             String bs = "" + this.endtbl.getValueAt(r, 12);
/* 1784 */             String cmp = "" + this.endtbl.getValueAt(r, 13);
/* 1785 */             String ag = "" + this.endtbl.getValueAt(r, 14);
/* 1786 */             if (en == null) en = "0";
/* 1787 */             if (ks == null) ks = "0";
/* 1788 */             if (mt == null) mt = "0";
/* 1789 */             if (bo == null) bo = "0";
/* 1790 */             if (cm == null) cm = "0";
/* 1791 */             if (ph == null) ph = "0";
/* 1792 */             if (hs == null) hs = "0";
/* 1793 */             if (cr == null) cr = "0";
/* 1794 */             if (go == null) go = "0";
/* 1795 */             if (bs == null) bs = "0";
/* 1796 */             if (cmp == null) cmp = "0";
/* 1797 */             if (ag == null) ag = "0";
/* 1798 */             admno = Integer.parseInt(a);
/* 1799 */             examno = Integer.parseInt(e);
/*      */             try { comp = Integer.parseInt(cmp); } catch (Exception y) { comp = 0; } try {
/* 1801 */               eng = Integer.parseInt(en); } catch (Exception y) { eng = 0; } try {
/* 1802 */               kis = Integer.parseInt(ks); } catch (Exception y) { kis = 0; } try {
/* 1803 */               math = Integer.parseInt(mt); } catch (Exception y) { math = 0; } try {
/* 1804 */               bio = Integer.parseInt(bo); } catch (Exception y) { bio = 0; } try {
/* 1805 */               chem = Integer.parseInt(cm); } catch (Exception y) { chem = 0; } try {
/* 1806 */               phyc = Integer.parseInt(ph); } catch (Exception y) { phyc = 0; } try {
/* 1807 */               histo = Integer.parseInt(hs); } catch (Exception y) { histo = 0; } try {
/* 1808 */               cre = Integer.parseInt(cr); } catch (Exception y) { cre = 0; } try {
/* 1809 */               geog = Integer.parseInt(go); } catch (Exception y) { geog = 0; } try {
/* 1810 */               bstudies = Integer.parseInt(bs); } catch (Exception y) { bstudies = 0; } try {
/* 1811 */               agri = Integer.parseInt(ag); } catch (Exception y) { agri = 0; }
/*      */ 
/* 1813 */             add(en, ks, mt, bo, cm, ph, hs, cr, go, bs, cmp, ag);
/* 1814 */             grde(e, a, en, ks, mt, bo, cm, ph, hs, cr, go, bs, cmp, ag);
/* 1815 */             if ((eng > 100) || (eng < 0)) eng = Integer.parseInt("XX");
/* 1816 */             if ((kis > 100) || (kis < 0)) kis = Integer.parseInt("XX");
/* 1817 */             if ((math > 100) || (math < 0)) math = Integer.parseInt("XX");
/* 1818 */             if ((bio > 100) || (bio < 0)) bio = Integer.parseInt("XX");
/* 1819 */             if ((chem > 100) || (chem < 0)) chem = Integer.parseInt("XX");
/* 1820 */             if ((phyc > 100) || (phyc < 0)) phyc = Integer.parseInt("XX");
/* 1821 */             if ((histo > 100) || (histo < 0)) histo = Integer.parseInt("XX");
/* 1822 */             if ((cre > 100) || (cre < 0)) cre = Integer.parseInt("XX");
/* 1823 */             if ((geog > 100) || (geog < 0)) geog = Integer.parseInt("XX");
/* 1824 */             if ((bstudies > 100) || (bstudies < 0)) bstudies = Integer.parseInt("XX");
/* 1825 */             if ((comp > 100) || (comp < 0)) comp = Integer.parseInt("XX");
/* 1826 */             if ((agri > 100) || (agri < 0)) agri = Integer.parseInt("XX");
/*      */ 
/*      */           }
/* 1829 */           else if (z.contains("Other")) {
/* 1830 */             a = "" + this.othertbl.getValueAt(r, 1);
/* 1831 */             admno = Integer.parseInt(a);
/* 1832 */             e = "" + this.othertbl.getValueAt(r, 0);
/* 1833 */             examno = Integer.parseInt(e);
/* 1834 */             String en = "" + this.othertbl.getValueAt(r, 3);
/* 1835 */             String ks = "" + this.othertbl.getValueAt(r, 4);
/* 1836 */             String mt = "" + this.othertbl.getValueAt(r, 5);
/* 1837 */             String bo = "" + this.othertbl.getValueAt(r, 6);
/* 1838 */             String cm = "" + this.othertbl.getValueAt(r, 7);
/* 1839 */             String ph = "" + this.othertbl.getValueAt(r, 8);
/* 1840 */             String hs = "" + this.othertbl.getValueAt(r, 9);
/* 1841 */             String cr = "" + this.othertbl.getValueAt(r, 10);
/* 1842 */             String go = "" + this.othertbl.getValueAt(r, 11);
/* 1843 */             String bs = "" + this.othertbl.getValueAt(r, 12);
/* 1844 */             String cmp = "" + this.othertbl.getValueAt(r, 13);
/* 1845 */             String ag = "" + this.othertbl.getValueAt(r, 14);
/* 1846 */             if (en == null) en = "0";
/* 1847 */             if (ks == null) ks = "0";
/* 1848 */             if (mt == null) mt = "0";
/* 1849 */             if (bo == null) bo = "0";
/* 1850 */             if (cm == null) cm = "0";
/* 1851 */             if (ph == null) ph = "0";
/* 1852 */             if (hs == null) hs = "0";
/* 1853 */             if (cr == null) cr = "0";
/* 1854 */             if (go == null) go = "0";
/* 1855 */             if (bs == null) bs = "0";
/* 1856 */             if (cmp == null) cmp = "0";
/* 1857 */             if (ag == null) ag = "0";
/*      */ 
/* 1860 */             admno = Integer.parseInt(a);
/* 1861 */             examno = Integer.parseInt(e);
/*      */             try { comp = Integer.parseInt(cmp); } catch (Exception y) { comp = 0; } try {
/* 1863 */               eng = Integer.parseInt(en); } catch (Exception y) { eng = 0; } try {
/* 1864 */               kis = Integer.parseInt(ks); } catch (Exception y) { kis = 0; } try {
/* 1865 */               math = Integer.parseInt(mt); } catch (Exception y) { math = 0; } try {
/* 1866 */               bio = Integer.parseInt(bo); } catch (Exception y) { bio = 0; } try {
/* 1867 */               chem = Integer.parseInt(cm); } catch (Exception y) { chem = 0; } try {
/* 1868 */               phyc = Integer.parseInt(ph); } catch (Exception y) { phyc = 0; } try {
/* 1869 */               histo = Integer.parseInt(hs); } catch (Exception y) { histo = 0; } try {
/* 1870 */               cre = Integer.parseInt(cr); } catch (Exception y) { cre = 0; } try {
/* 1871 */               geog = Integer.parseInt(go); } catch (Exception y) { geog = 0; } try {
/* 1872 */               bstudies = Integer.parseInt(bs); } catch (Exception y) { bstudies = 0; } try {
/* 1873 */               agri = Integer.parseInt(ag); } catch (Exception y) { agri = 0; }
/* 1874 */             add(en, ks, mt, bo, cm, ph, hs, cr, go, bs, cmp, ag);
/* 1875 */             grde(e, a, en, ks, mt, bo, cm, ph, hs, cr, go, bs, cmp, ag);
/* 1876 */             if ((eng > 100) || (eng < 0)) eng = Integer.parseInt("XX");
/* 1877 */             if ((kis > 100) || (kis < 0)) kis = Integer.parseInt("XX");
/* 1878 */             if ((math > 100) || (math < 0)) math = Integer.parseInt("XX");
/* 1879 */             if ((bio > 100) || (bio < 0)) bio = Integer.parseInt("XX");
/* 1880 */             if ((chem > 100) || (chem < 0)) chem = Integer.parseInt("XX");
/* 1881 */             if ((phyc > 100) || (phyc < 0)) phyc = Integer.parseInt("XX");
/* 1882 */             if ((histo > 100) || (histo < 0)) histo = Integer.parseInt("XX");
/* 1883 */             if ((cre > 100) || (cre < 0)) cre = Integer.parseInt("XX");
/* 1884 */             if ((geog > 100) || (geog < 0)) geog = Integer.parseInt("XX");
/* 1885 */             if ((bstudies > 100) || (bstudies < 0)) bstudies = Integer.parseInt("XX");
/* 1886 */             if ((comp > 100) || (comp < 0)) comp = Integer.parseInt("XX");
/* 1887 */             if ((agri > 100) || (agri < 0)) agri = Integer.parseInt("XX");
/*      */ 
/*      */           }
/*      */ 
/* 1892 */           PreparedStatement stmtt = mycon.prepareStatement("update score set admno=?,examno=?,exam=?,exam1=?,exam2=?,exam3=?,exam4=?,exam5=?,exam6=?,exam7=?,exam8=?,exam9=?,exam10=?,exam11=? where examno ='" + examn + "'and admno=" + admno);
/*      */ 
/* 1894 */           stmtt.setInt(1, admno);
/* 1895 */           stmtt.setInt(2, examno);
/* 1896 */           stmtt.setInt(3, eng);
/* 1897 */           stmtt.setInt(4, kis);
/* 1898 */           stmtt.setInt(5, math);
/* 1899 */           stmtt.setInt(6, bio);
/* 1900 */           stmtt.setInt(7, chem);
/* 1901 */           stmtt.setInt(8, phyc);
/* 1902 */           stmtt.setInt(9, histo);
/* 1903 */           stmtt.setInt(10, cre);
/* 1904 */           stmtt.setInt(11, geog);
/* 1905 */           stmtt.setInt(12, bstudies);
/* 1906 */           stmtt.setInt(13, comp);
/* 1907 */           stmtt.setInt(14, agri);
/* 1908 */           stmtt.executeUpdate();
/*      */ 
/* 1910 */           r++;
/*      */         }
/* 1912 */         JOptionPane.showMessageDialog(null, "Changes successfully updated");
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/* 1916 */         e.printStackTrace();
/* 1917 */         JOptionPane.showMessageDialog(null, "Update operation unsuccessfull because\n" + e.getMessage() + "\n Please check all your input to ensure it is correct");
/*      */       }
/*      */     }
/*      */     catch (Exception lang)
/*      */     {
/* 1922 */       JOptionPane.showMessageDialog(null, "Please Input a valid number of students who took the exam before you can proceed");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void txtstreamActionPerformed(ActionEvent evt)
/*      */   {
/*      */     try {
/* 1929 */       spop();
/*      */     } catch (Exception e) {
/* 1931 */       JOptionPane.showMessageDialog(null, " Please Input the class of the student correctly before you can proceed");
/* 1932 */       this.txtclass.setEditor(this.txtclass.getEditor());
/* 1933 */       this.txtstream.setText("");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void txtclassActionPerformed(ActionEvent evt)
/*      */   {
/*      */   }
/*      */ 
/*      */   private void jButton1StateChanged(ChangeEvent evt)
/*      */   {
/*      */   }
/*      */ 
/*      */   private void btnsaveStateChanged(ChangeEvent evt)
/*      */   {
/*      */   }
/*      */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.examstud
 * JD-Core Version:    0.6.2
 */