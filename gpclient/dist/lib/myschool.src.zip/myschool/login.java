/*     */ package myschool;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPasswordField;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.event.InternalFrameEvent;
/*     */ import javax.swing.event.InternalFrameListener;
/*     */ 
/*     */ public class login extends JInternalFrame
/*     */ {
/*     */   public static String name;
/*     */   public static String status;
/*     */   public static String cred;
/*     */   mymain mf;
/*     */   welcomes wm;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel3;
/*     */   private JLabel lblflatname5;
/*     */   private JLabel lblflatname6;
/*     */   private JLabel lblhint;
/*     */   private JPasswordField txtpass;
/*     */   private JTextField txtuser;
/*     */ 
/*     */   public login(mymain in)
/*     */   {
/*  23 */     initComponents();
/*  24 */     this.mf = in;
/*     */   }
/*     */ 
/*     */   public login(welcomes aThis)
/*     */   {
/*  30 */     this.wm = aThis;
/*     */   }
/*     */ 
/*     */   public void wel() {
/*  34 */     String n = name;
/*  35 */     System.out.println(n);
/*     */     int lt;
/*     */     try {
/*  40 */       lt = n.length();
/*     */     }
/*     */     catch (Exception e) {
/*  43 */       lt = 0;
/*     */     }
/*  45 */     if (lt > 0)
/*  46 */       welcomes.lblwelcome.setText(welcomes.lblwelcome.getText() + n);
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  54 */     this.txtuser = new JTextField();
/*  55 */     this.lblflatname5 = new JLabel();
/*  56 */     this.lblflatname6 = new JLabel();
/*  57 */     this.txtpass = new JPasswordField();
/*  58 */     this.jLabel1 = new JLabel();
/*  59 */     this.jLabel3 = new JLabel();
/*  60 */     this.lblhint = new JLabel();
/*     */ 
/*  62 */     setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(102, 102, 255)));
/*  63 */     setClosable(true);
/*  64 */     setIconifiable(true);
/*  65 */     setMaximizable(true);
/*  66 */     setTitle("Welcome Please Enter Your Login Credentials");
/*  67 */     setToolTipText("Login");
/*  68 */     addInternalFrameListener(new InternalFrameListener() {
/*     */       public void internalFrameActivated(InternalFrameEvent evt) {
/*     */       }
/*     */       public void internalFrameClosed(InternalFrameEvent evt) {
/*     */       }
/*     */       public void internalFrameClosing(InternalFrameEvent evt) {
/*  74 */         login.this.formInternalFrameClosing(evt);
/*     */       }
/*     */ 
/*     */       public void internalFrameDeactivated(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameDeiconified(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameIconified(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void internalFrameOpened(InternalFrameEvent evt)
/*     */       {
/*     */       }
/*     */     });
/*  86 */     this.txtuser.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  88 */         login.this.txtuserActionPerformed(evt);
/*     */       }
/*     */     });
/*  92 */     this.lblflatname5.setFont(new Font("Traditional Arabic", 0, 18));
/*  93 */     this.lblflatname5.setText("User Name");
/*  94 */     this.lblflatname5.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/*  96 */     this.lblflatname6.setFont(new Font("Traditional Arabic", 0, 18));
/*  97 */     this.lblflatname6.setText("Password");
/*  98 */     this.lblflatname6.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */ 
/* 100 */     this.txtpass.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 102 */         login.this.txtpassActionPerformed(evt);
/*     */       }
/*     */     });
/* 106 */     this.jLabel1.setFont(new Font("Traditional Arabic", 1, 18));
/* 107 */     this.jLabel1.setIcon(new ImageIcon(getClass().getResource("/myschool/resources/Close-2-icon.png")));
/* 108 */     this.jLabel1.setText("Exit");
/* 109 */     this.jLabel1.setBorder(BorderFactory.createBevelBorder(0, Color.darkGray, null, Color.darkGray, new Color(51, 51, 51)));
/* 110 */     this.jLabel1.addMouseListener(new MouseAdapter() {
/*     */       public void mouseClicked(MouseEvent evt) {
/* 112 */         login.this.jLabel1MouseClicked(evt);
/*     */       }
/*     */     });
/* 116 */     this.jLabel3.setFont(new Font("Traditional Arabic", 1, 18));
/* 117 */     this.jLabel3.setIcon(new ImageIcon(getClass().getResource("/myschool/resources/Check-icon.png")));
/* 118 */     this.jLabel3.setText("Login");
/* 119 */     this.jLabel3.setBorder(BorderFactory.createBevelBorder(0, Color.green, null, Color.green, Color.green));
/* 120 */     this.jLabel3.addMouseListener(new MouseAdapter() {
/*     */       public void mouseClicked(MouseEvent evt) {
/* 122 */         login.this.jLabel3MouseClicked(evt);
/*     */       }
/*     */     });
/* 126 */     this.lblhint.setFont(new Font("Monotype Corsiva", 0, 14));
/*     */ 
/* 128 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 129 */     getContentPane().setLayout(layout);
/* 130 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.lblflatname5, -2, 122, -2).addComponent(this.lblflatname6, -2, 122, -2)).addGap(18, 18, 18).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.txtpass).addComponent(this.txtuser, -1, 228, 32767)).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addComponent(this.jLabel3, -2, 122, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jLabel1, -2, 113, -2)).addComponent(this.lblhint, GroupLayout.Alignment.TRAILING, -2, 150, -2)).addContainerGap()));
/*     */ 
/* 149 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.lblflatname5, -2, 22, -2).addComponent(this.txtuser, -2, -1, -2)).addGap(27, 27, 27).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.lblflatname6, -2, 22, -2).addComponent(this.txtpass, -2, -1, -2)).addGap(5, 5, 5).addComponent(this.lblhint, -2, 14, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel1, -1, -1, 32767).addComponent(this.jLabel3, -1, -1, 32767)).addGap(37, 37, 37)));
/*     */ 
/* 169 */     pack();
/*     */   }
/*     */ 
/*     */   private void txtuserActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void txtpassActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void jLabel3MouseClicked(MouseEvent evt) {
/*     */     try {
/* 182 */       String user = this.txtuser.getText();
/* 183 */       String pass = this.txtpass.getText();
/* 184 */       Class.forName("com.mysql.jdbc.Driver");
/* 185 */       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool", "root", "muteti");
/*     */ 
/* 187 */       Statement stmnt = con.createStatement();
/* 188 */       String sql = "Select * from user where username='" + user + "'";
/* 189 */       ResultSet rs = stmnt.executeQuery(sql);
/*     */ 
/* 192 */       if (rs.next()) {
/* 193 */         if ((pass.equals("1234")) && (pass.equals(rs.getString("password")))) {
/* 194 */           JOptionPane.showMessageDialog(null, "New users must login thorugh the new user login window for the first time  ");
/*     */         }
/* 197 */         else if (pass.equals(rs.getString("password")))
/*     */         {
/* 199 */           JOptionPane.showMessageDialog(null, "\nLogin Successfull");
/*     */ 
/* 203 */           name = rs.getString("fullname");
/* 204 */           System.out.println(name);
/* 205 */           status = name;
/*     */ 
/* 208 */           cred = rs.getString("credentials");
/*     */ 
/* 214 */           dispose();
/* 215 */           mymain.lblstatus.setText(name + " Logged in as " + cred);
/* 216 */           this.mf.add();
/*     */         }
/*     */         else
/*     */         {
/* 221 */           JOptionPane.showMessageDialog(null, "Wrong Password please try again");
/* 222 */           this.lblhint.setText("Password hint:" + rs.getString("hint"));
/*     */         }
/*     */       }
/*     */       else
/* 226 */         JOptionPane.showMessageDialog(null, "Wrong Username try again ");
/*     */     }
/*     */     catch (SQLException ex)
/*     */     {
/* 230 */       Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } catch (ClassNotFoundException ex) {
/* 232 */       Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void jLabel1MouseClicked(MouseEvent evt)
/*     */   {
/* 238 */     dispose();
/*     */   }
/*     */ 
/*     */   private void formInternalFrameClosing(InternalFrameEvent evt)
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     myschool.login
 * JD-Core Version:    0.6.2
 */