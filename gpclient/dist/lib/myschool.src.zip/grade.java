/*    */ public class grade
/*    */ {
/*    */   int mark;
/*    */ 
/*    */   public String grading(int mark)
/*    */   {
/*  5 */     if ((mark > 0) && (mark <= 20)) {
/*  6 */       return "A";
/*    */     }
/*  8 */     if ((mark > 0) && (mark <= 20)) {
/*  9 */       return "A";
/*    */     }
/*    */ 
/* 12 */     if ((mark > 0) && (mark <= 20)) {
/* 13 */       return "A";
/*    */     }
/*    */ 
/* 16 */     if ((mark > 0) && (mark <= 20)) {
/* 17 */       return "A";
/*    */     }
/*    */ 
/* 20 */     if ((mark > 0) && (mark <= 20)) {
/* 21 */       return "A";
/*    */     }
/*    */ 
/* 24 */     if ((mark > 0) && (mark <= 20)) {
/* 25 */       return "A";
/*    */     }
/* 27 */     if ((mark > 0) && (mark <= 20)) {
/* 28 */       return "A";
/*    */     }
/*    */ 
/* 31 */     if ((mark > 0) && (mark <= 20)) {
/* 32 */       return "A";
/*    */     }
/*    */ 
/* 35 */     if ((mark > 0) && (mark <= 20)) {
/* 36 */       return "E";
/*    */     }
/*    */ 
/* 39 */     if ((mark > 20) && (mark <= 27)) {
/* 40 */       return "D-";
/*    */     }
/*    */ 
/* 43 */     if ((mark > 27) && (mark <= 34)) {
/* 44 */       return "D";
/*    */     }
/*    */ 
/* 47 */     if ((mark > 34) && (mark <= 41)) {
/* 48 */       return "D+";
/*    */     }
/*    */ 
/* 51 */     if ((mark > 41) && (mark <= 48)) {
/* 52 */       return "C-";
/*    */     }
/*    */ 
/* 55 */     if ((mark > 48) && (mark <= 55)) {
/* 56 */       return "C";
/*    */     }
/*    */ 
/* 59 */     if ((mark > 55) && (mark <= 62)) {
/* 60 */       return "C+";
/*    */     }
/*    */ 
/* 63 */     if ((mark > 62) && (mark <= 69)) {
/* 64 */       return "B-";
/*    */     }
/*    */ 
/* 67 */     if ((mark > 69) && (mark <= 76)) {
/* 68 */       return "B";
/*    */     }
/*    */ 
/* 71 */     if ((mark > 76) && (mark <= 83)) {
/* 72 */       return "B+";
/*    */     }
/*    */ 
/* 75 */     if ((mark > 83) && (mark <= 90)) {
/* 76 */       return "A-";
/*    */     }
/*    */ 
/* 79 */     if ((mark > 90) && (mark <= 100)) {
/* 80 */       return "A";
/*    */     }
/* 82 */     return "M";
/*    */   }
/*    */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     grade
 * JD-Core Version:    0.6.2
 */