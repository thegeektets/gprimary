/*    */ package org.w3c.tools.codec;
/*    */ 
/*    */ public class Base64FormatException extends Exception
/*    */ {
/*    */   public Base64FormatException(String msg)
/*    */   {
/* 21 */     super(msg);
/*    */   }
/*    */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     org.w3c.tools.codec.Base64FormatException
 * JD-Core Version:    0.6.2
 */