/*     */ package org.w3c.tools.codec;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ 
/*     */ public class Base64Encoder
/*     */ {
/*     */   private static final int BUFFER_SIZE = 1024;
/*  26 */   private static byte[] encoding = { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47, 61 };
/*     */ 
/*  39 */   InputStream in = null;
/*  40 */   OutputStream out = null;
/*  41 */   boolean stringp = false;
/*     */ 
/*     */   private final int get1(byte[] buf, int off)
/*     */   {
/*  45 */     return (buf[off] & 0xFC) >> 2;
/*     */   }
/*     */ 
/*     */   private final int get2(byte[] buf, int off)
/*     */   {
/*  50 */     return (buf[off] & 0x3) << 4 | (buf[(off + 1)] & 0xF0) >>> 4;
/*     */   }
/*     */ 
/*     */   private final int get3(byte[] buf, int off)
/*     */   {
/*  55 */     return (buf[(off + 1)] & 0xF) << 2 | (buf[(off + 2)] & 0xC0) >>> 6;
/*     */   }
/*     */ 
/*     */   private static final int get4(byte[] buf, int off)
/*     */   {
/*  60 */     return buf[(off + 2)] & 0x3F;
/*     */   }
/*     */ 
/*     */   public void process()
/*     */     throws IOException
/*     */   {
/*  72 */     byte[] buffer = new byte[1024];
/*  73 */     int got = -1;
/*  74 */     int off = 0;
/*  75 */     int count = 0;
/*  76 */     while ((got = this.in.read(buffer, off, 1024 - off)) > 0)
/*     */     {
/*  78 */       if (got >= 3)
/*     */       {
/*  80 */         got += off;
/*  81 */         off = 0;
/*  82 */         while (off + 3 <= got)
/*     */         {
/*  84 */           int c1 = get1(buffer, off);
/*  85 */           int c2 = get2(buffer, off);
/*  86 */           int c3 = get3(buffer, off);
/*  87 */           int c4 = get4(buffer, off);
/*  88 */           switch (count)
/*     */           {
/*     */           case 73:
/*  91 */             this.out.write(encoding[c1]);
/*  92 */             this.out.write(encoding[c2]);
/*  93 */             this.out.write(encoding[c3]);
/*  94 */             this.out.write(10);
/*  95 */             this.out.write(encoding[c4]);
/*  96 */             count = 1;
/*  97 */             break;
/*     */           case 74:
/*  99 */             this.out.write(encoding[c1]);
/* 100 */             this.out.write(encoding[c2]);
/* 101 */             this.out.write(10);
/* 102 */             this.out.write(encoding[c3]);
/* 103 */             this.out.write(encoding[c4]);
/* 104 */             count = 2;
/* 105 */             break;
/*     */           case 75:
/* 107 */             this.out.write(encoding[c1]);
/* 108 */             this.out.write(10);
/* 109 */             this.out.write(encoding[c2]);
/* 110 */             this.out.write(encoding[c3]);
/* 111 */             this.out.write(encoding[c4]);
/* 112 */             count = 3;
/* 113 */             break;
/*     */           case 76:
/* 115 */             this.out.write(10);
/* 116 */             this.out.write(encoding[c1]);
/* 117 */             this.out.write(encoding[c2]);
/* 118 */             this.out.write(encoding[c3]);
/* 119 */             this.out.write(encoding[c4]);
/* 120 */             count = 4;
/* 121 */             break;
/*     */           default:
/* 123 */             this.out.write(encoding[c1]);
/* 124 */             this.out.write(encoding[c2]);
/* 125 */             this.out.write(encoding[c3]);
/* 126 */             this.out.write(encoding[c4]);
/* 127 */             count += 4;
/*     */           }
/*     */ 
/* 130 */           off += 3;
/*     */         }
/*     */ 
/* 133 */         for (int i = 0; i < 3; i++)
/*     */         {
/* 135 */           buffer[i] = (i < got - off ? buffer[(off + i)] : 0);
/*     */         }
/* 137 */         off = got - off;
/*     */       }
/*     */       else
/*     */       {
/* 142 */         off += got;
/*     */       }
/*     */     }
/*     */ 
/* 146 */     switch (off)
/*     */     {
/*     */     case 1:
/* 149 */       this.out.write(encoding[get1(buffer, 0)]);
/* 150 */       this.out.write(encoding[get2(buffer, 0)]);
/* 151 */       this.out.write(61);
/* 152 */       this.out.write(61);
/* 153 */       break;
/*     */     case 2:
/* 155 */       this.out.write(encoding[get1(buffer, 0)]);
/* 156 */       this.out.write(encoding[get2(buffer, 0)]);
/* 157 */       this.out.write(encoding[get3(buffer, 0)]);
/* 158 */       this.out.write(61);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String processString()
/*     */   {
/* 171 */     if (!this.stringp)
/*     */     {
/* 173 */       throw new RuntimeException(getClass().getName() + "[processString]" + "invalid call (not a String)");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 180 */       process();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/* 185 */     return ((ByteArrayOutputStream)this.out).toString();
/*     */   }
/*     */ 
/*     */   public Base64Encoder(String input)
/*     */   {
/*     */     byte[] bytes;
/*     */     try
/*     */     {
/* 197 */       bytes = input.getBytes("ISO-8859-1");
/*     */     }
/*     */     catch (UnsupportedEncodingException ex)
/*     */     {
/* 201 */       throw new RuntimeException(getClass().getName() + "[Constructor] Unable to convert" + "properly char to bytes");
/*     */     }
/*     */ 
/* 206 */     this.stringp = true;
/* 207 */     this.in = new ByteArrayInputStream(bytes);
/* 208 */     this.out = new ByteArrayOutputStream();
/*     */   }
/*     */ 
/*     */   public Base64Encoder(InputStream in, OutputStream out)
/*     */   {
/* 218 */     this.in = in;
/* 219 */     this.out = out;
/* 220 */     this.stringp = false;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 229 */     if (args.length != 1)
/*     */     {
/* 231 */       System.out.println("Base64Encoder <string>");
/* 232 */       System.exit(0);
/*     */     }
/* 234 */     Base64Encoder b = new Base64Encoder(args[0]);
/* 235 */     System.out.println("[" + b.processString() + "]");
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     org.w3c.tools.codec.Base64Encoder
 * JD-Core Version:    0.6.2
 */