/*     */ package org.w3c.tools.codec;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ 
/*     */ public class Base64Decoder
/*     */ {
/*     */   private static final int BUFFER_SIZE = 1024;
/*  26 */   InputStream in = null;
/*  27 */   OutputStream out = null;
/*  28 */   boolean stringp = false;
/*     */ 
/*     */   private void printHex(int x)
/*     */   {
/*  32 */     int h = (x & 0xF0) >> 4;
/*  33 */     int l = x & 0xF;
/*  34 */     System.out.print(new StringBuilder().append(new Character((char)(h > 9 ? 65 + h - 10 : 48 + h)).toString()).append(new Character((char)(l > 9 ? 65 + l - 10 : 48 + l)).toString()).toString());
/*     */   }
/*     */ 
/*     */   private void printHex(byte[] buf, int off, int len)
/*     */   {
/*  43 */     while (off < len)
/*     */     {
/*  45 */       printHex(buf[(off++)]);
/*  46 */       System.out.print(" ");
/*     */     }
/*  48 */     System.out.println("");
/*     */   }
/*     */ 
/*     */   private void printHex(String s)
/*     */   {
/*     */     byte[] bytes;
/*     */     try
/*     */     {
/*  56 */       bytes = s.getBytes("ISO-8859-1");
/*     */     }
/*     */     catch (UnsupportedEncodingException ex)
/*     */     {
/*  60 */       throw new RuntimeException(new StringBuilder().append(getClass().getName()).append("[printHex] Unable to convert").append("properly char to bytes").toString());
/*     */     }
/*     */ 
/*  65 */     printHex(bytes, 0, bytes.length);
/*     */   }
/*     */ 
/*     */   private final int get1(byte[] buf, int off)
/*     */   {
/*  70 */     return (buf[off] & 0x3F) << 2 | (buf[(off + 1)] & 0x30) >>> 4;
/*     */   }
/*     */ 
/*     */   private final int get2(byte[] buf, int off)
/*     */   {
/*  75 */     return (buf[(off + 1)] & 0xF) << 4 | (buf[(off + 2)] & 0x3C) >>> 2;
/*     */   }
/*     */ 
/*     */   private final int get3(byte[] buf, int off)
/*     */   {
/*  80 */     return (buf[(off + 2)] & 0x3) << 6 | buf[(off + 3)] & 0x3F;
/*     */   }
/*     */ 
/*     */   private final int check(int ch)
/*     */   {
/*  85 */     if ((ch >= 65) && (ch <= 90))
/*     */     {
/*  87 */       return ch - 65;
/*     */     }
/*  89 */     if ((ch >= 97) && (ch <= 122))
/*     */     {
/*  91 */       return ch - 97 + 26;
/*     */     }
/*  93 */     if ((ch >= 48) && (ch <= 57))
/*     */     {
/*  95 */       return ch - 48 + 52;
/*     */     }
/*     */ 
/*  99 */     switch (ch)
/*     */     {
/*     */     case 61:
/* 102 */       return 65;
/*     */     case 43:
/* 104 */       return 62;
/*     */     case 47:
/* 106 */       return 63;
/*     */     }
/* 108 */     return -1;
/*     */   }
/*     */ 
/*     */   public void process()
/*     */     throws IOException, Base64FormatException
/*     */   {
/* 123 */     byte[] buffer = new byte[1024];
/* 124 */     byte[] chunk = new byte[4];
/* 125 */     int got = -1;
/* 126 */     int ready = 0;
/*     */ 
/* 128 */     label185: while ((got = this.in.read(buffer)) > 0)
/*     */     {
/* 130 */       int skiped = 0;
/*     */       while (true) { if (skiped >= got)
/*     */           break label185;
/*     */         while (true) {
/* 134 */           if (ready >= 4)
/*     */             break label83;
/* 136 */           if (skiped >= got)
/*     */           {
/*     */             break;
/*     */           }
/* 140 */           int ch = check(buffer[(skiped++)]);
/* 141 */           if (ch >= 0)
/*     */           {
/* 143 */             chunk[(ready++)] = ((byte)ch);
/*     */           }
/*     */         }
/* 146 */         label83: if (chunk[2] == 65)
/*     */         {
/* 148 */           this.out.write(get1(chunk, 0));
/* 149 */           return;
/*     */         }
/* 151 */         if (chunk[3] == 65)
/*     */         {
/* 153 */           this.out.write(get1(chunk, 0));
/* 154 */           this.out.write(get2(chunk, 0));
/* 155 */           return;
/*     */         }
/*     */ 
/* 159 */         this.out.write(get1(chunk, 0));
/* 160 */         this.out.write(get2(chunk, 0));
/* 161 */         this.out.write(get3(chunk, 0));
/*     */ 
/* 163 */         ready = 0;
/*     */       }
/*     */     }
/* 166 */     if (ready != 0)
/*     */     {
/* 168 */       throw new Base64FormatException("Invalid length.");
/*     */     }
/* 170 */     this.out.flush();
/*     */   }
/*     */ 
/*     */   public String processString()
/*     */     throws Base64FormatException
/*     */   {
/* 185 */     if (!this.stringp)
/*     */     {
/* 187 */       throw new RuntimeException(new StringBuilder().append(getClass().getName()).append("[processString]").append("invalid call (not a String)").toString());
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 194 */       process();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/*     */     String s;
/*     */     try
/*     */     {
/* 202 */       s = ((ByteArrayOutputStream)this.out).toString("ISO-8859-1");
/*     */     }
/*     */     catch (UnsupportedEncodingException ex)
/*     */     {
/* 206 */       throw new RuntimeException(new StringBuilder().append(getClass().getName()).append("[processString] Unable to convert").append("properly char to bytes").toString());
/*     */     }
/*     */ 
/* 211 */     return s;
/*     */   }
/*     */ 
/*     */   public Base64Decoder(String input)
/*     */   {
/*     */     byte[] bytes;
/*     */     try
/*     */     {
/* 223 */       bytes = input.getBytes("ISO-8859-1");
/*     */     }
/*     */     catch (UnsupportedEncodingException ex)
/*     */     {
/* 227 */       throw new RuntimeException(new StringBuilder().append(getClass().getName()).append("[Constructor] Unable to convert").append("properly char to bytes").toString());
/*     */     }
/*     */ 
/* 232 */     this.stringp = true;
/* 233 */     this.in = new ByteArrayInputStream(bytes);
/* 234 */     this.out = new ByteArrayOutputStream();
/*     */   }
/*     */ 
/*     */   public Base64Decoder(InputStream in, OutputStream out)
/*     */   {
/* 244 */     this.in = in;
/* 245 */     this.out = out;
/* 246 */     this.stringp = false;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 256 */     if (args.length == 1)
/*     */     {
/*     */       try
/*     */       {
/* 260 */         Base64Decoder b = new Base64Decoder(args[0]);
/* 261 */         System.out.println(new StringBuilder().append("[").append(b.processString()).append("]").toString());
/*     */       }
/*     */       catch (Base64FormatException e)
/*     */       {
/* 265 */         System.out.println("Invalid Base64 format !");
/* 266 */         System.exit(1);
/*     */       }
/*     */     }
/* 269 */     else if ((args.length == 2) && (args[0].equals("-f")))
/*     */     {
/*     */       try
/*     */       {
/* 273 */         FileInputStream in = new FileInputStream(args[1]);
/* 274 */         Base64Decoder b = new Base64Decoder(in, System.out);
/* 275 */         b.process();
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 279 */         System.out.println(new StringBuilder().append("error: ").append(ex.getMessage()).toString());
/* 280 */         System.exit(1);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 285 */       System.out.println("Base64Decoder [strong] [-f file]");
/*     */     }
/* 287 */     System.exit(0);
/*     */   }
/*     */ }

/* Location:           C:\Users\Griffin M\Desktop\High school Manager\myschool.jar
 * Qualified Name:     org.w3c.tools.codec.Base64Decoder
 * JD-Core Version:    0.6.2
 */